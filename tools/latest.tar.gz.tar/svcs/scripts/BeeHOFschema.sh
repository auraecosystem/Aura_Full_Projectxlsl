#!/bin/bash
########################################################################
#   $Name: ORG-TEST $, $Id: BeeHOFschema.sh,v 1.2 2002/11/25 17:50:49 leed Exp $
##------------------+---------------------------------------------------
## Copyright (C) 2002 Affero, Inc.

## This file is part of The Affero Project.

## The Affero Project is free software# you can redistribute it and/or
## modify it under the terms of the Affero General Public License as
## published by Affero, Inc.# either version 1 of the License, or
## (at your option) any later version.

## The Affero Project is distributed in the hope that it will be
## useful,but WITHOUT ANY WARRANTY# without even the implied warranty
## of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## Affero General Public License for more details.

## You should have received a copy of the Affero General Public
## License in the COPYING file that comes with The Affero Project# if
## not, write to Affero, Inc., 510 Third Street, Suite 225, San
## Francisco, CA 94107 USA.
########################################################################
#TODO modify 'text' attributes as appropriate to 'char' or 'varchar'
########################################################################
#  options are chose to be similar to psql except that they default
#  to 'allseer'.
#-----------------------------------------------------------------------
#   get arguments from the environment then replace with command
#   line overrides
echo "------------------------------------------------------------------------"
usage="Usage $0: [-d dbname] [-U user]"

t=${AFFERO_DBNAME:="allseer"}
t=${AFFERO_USER:="allseer"}

while getopts ":d:U:" opt; do
	case $opt in
		d) AFFERO_DBNAME=$OPTARG;;
		U) AFFERO_USER=$OPTARG;;
		?) echo usage; exit1;;
	esac
done
shift $(($OPTIND - 1))

echo "$0: \$AFFERO_DBNAME is $AFFERO_DBNAME"
echo "$0: \$AFFERO_USER is $AFFERO_USER"



########################################################################
#							A S _ B P C T                              #
########################################################################
echo "------------------------------------------------------------------------"
echo "Creating and initializing as_bpct"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	
	drop table as_bpct;
	drop sequence as_bpct_bpct_id_seq;

	\set ON_ERROR_STOP 1

	create table as_bpct (
		bpct_id serial PRIMARY KEY,
		bpct_tip int references as_tips NOT NULL,
		bpct_foundation int references as_foundations NOT NULL,
		bpct_percent int,
		created timestamp,
		modified timestamp default now());

	grant all on as_bpct to public;

	insert into as_bpct
		(bpct_tip, bpct_foundation, bpct_percent, created)
	select
		t.tip_id,
		p.ppd_found,
		p.ppd_percent,
		now()
	from
		as_tips t,
		as_pprof_details p
	where
		t.tip_amt <> 0 and
		p.ppd_prof = t.tip_profile_id;
EOF


