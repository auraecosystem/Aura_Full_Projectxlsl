#!/bin/bash
########################################################################
#   $Name: ORG-TEST $, $Id: allseer-init.sh,v 1.13 2002/03/19 03:09:32 leed Exp $
########################################################################
##------------------+---------------------------------------------------
## Copyright (C) 2002 Affero, Inc.

## This file is part of The Affero Project.

## The Affero Project is free software# you can redistribute it and/or
## modify it under the terms of the Affero General Public License as
## published by Affero, Inc.# either version 1 of the License, or
## (at your option) any later version.

## The Affero Project is distributed in the hope that it will be
## useful,but WITHOUT ANY WARRANTY# without even the implied warranty
## of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## Affero General Public License for more details.

## You should have received a copy of the Affero General Public
## License in the COPYING file that comes with The Affero Project# if
## not, write to Affero, Inc., 510 Third Street, Suite 225, San
## Francisco, CA 94107 USA.
##----------------------------------------------------------------------
#
#  inserts some stuff in the data base for a rating test
echo "------------------------------------------------------------------------"
usage="Usage $0: [-d dbname] [-U user]"

t=${AFFERO_DBNAME:="allseer"}
t=${AFFERO_USER:="allseer"}

while getopts ":d:U:" opt; do
	case $opt in
		d) AFFERO_DBNAME=$OPTARG;;
		U) AFFERO_USER=$OPTARG;;
		?) echo usage; exit1;;
	esac
done
shift $(($OPTIND - 1))

echo "$0: \$AFFERO_DBNAME is $AFFERO_DBNAME"
echo "$0: \$AFFERO_USER is $AFFERO_USER"

########################################################################
###  AS_USER_STATES            #########################################
########################################################################
echo "------------------------------------------------------------------------"
echo "AS_USER_STATES INITIAL DATA"
psql -U $AFFERO_USER $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	insert into as_user_states (ustt_state, created) values ('needs-auth', now());
	insert into as_user_states (ustt_state, created) values ('activated', now());
	insert into as_user_states (ustt_state, created) values ('inactivated', now());
EOF

########################################################################
###  AS_FOUNDATIONS            #########################################
########################################################################
echo "------------------------------------------------------------------------"
echo "AS_FOUNDATIONS INITIAL DATA"
psql -U $AFFERO_USER $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr", "created") 
		VALUES (2,'ISC Gen Fund - BIND','http://www.isc.org','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (3,'ISC Gen Fund - DHCP','http://www.isc.org','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (4,'ISC Gen Fund - INN','http://www.isc.org','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (5,'MAPS - Mail Abuse Prevention Systems','http://www.mail-abuse.org','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (6,'MAPS - Legal Defense Fund','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (7,'YAS - Yet Another Society Gen Fund','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (8,'YAS - Perl Development Grant Fund','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (9,'ASF - Apache Software Foundation','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (10,'Journal of Ecumenical Studies','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (11,'GDI - Global Dialogue Institute','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (12,'FSF - Free Software Foundation','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (13,'FSF Gen Fund - GNU Software','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (14,'FSF Gen Fund - Licensing & Legal','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (15,'FSF Gen Fund - Free Software Advocacy','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (16,'FSF Gen Fund - GCC','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (17,'FSF Gen Fund - Dot GNU','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (18,'FSF Gen Fund - Hurd','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (19,'GNOME Foundation','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (20,'ACLU Foundation','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (21,'Amnesty International','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (22,'Common Cause','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (23,'Marijuana Policy Project','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (25,'EFF - Electronic Frontier Foundation','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (26,'ISC - Internet Software Consortium','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (1,'Affero Software Project - Affero Corporation','http://www.affero.org','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (24,'Americans United for Separation of Church & State','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (27,'WCCI - West Coast Comperanos, Inc.','','',now());
	INSERT INTO "as_foundations" 
		("foundation_id","foundation_name","foundation_url","foundation_descr","created") 
		VALUES (28,'WCCI - Just Good Company','http://justgoodcompany.com','',now());

	SELECT setval ('"as_foundation_foundation_id_seq"', 29, 'f');
EOF

########################################################################
###  AS_COMPETENCIES           #########################################
########################################################################
echo "------------------------------------------------------------------------"
echo "AS_COMPETENCIES INITIAL DATA"
psql -U $AFFERO_USER $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Communications', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Desktop Environments', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Browsers', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Multimedia', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Office/Business', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Printing', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Text Editors', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Databases', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Internet', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Operating Systems', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Programming Languages', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Security', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Software Development', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Systems', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Terminals', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Arts', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Hobbies', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Business', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Humanities', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Computers', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('News', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Education', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('People', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Entertainment', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Sports', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Environment', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Travel', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Government', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Science', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Health', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Society', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Other', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Ports', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Requirements', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Installation', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Performance', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Configuration', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Maintenance', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Documentation', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Spam', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Translation', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Configuration', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Style Guide', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Spam', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Patron Preferences', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Volunteer Preferences', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Beneficiaries', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Emails', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Donations', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Terms of Service', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Privacy Policy', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Personal Email Links', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Spam', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Other', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Other', now());
	INSERT INTO "as_competencies" ("cmptcy_descr","created") VALUES ('Other', now());
EOF