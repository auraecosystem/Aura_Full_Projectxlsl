#!/bin/bash
########################################################################
#   $Name: ORG-TEST $, $Id: rateTest.sh,v 1.22 2002/03/19 03:09:32 leed Exp $
##------------------+---------------------------------------------------
## Copyright (C) 2002 Affero, Inc.

## This file is part of The Affero Project.

## The Affero Project is free software# you can redistribute it and/or
## modify it under the terms of the Affero General Public License as
## published by Affero, Inc.# either version 1 of the License, or
## (at your option) any later version.

## The Affero Project is distributed in the hope that it will be
## useful,but WITHOUT ANY WARRANTY# without even the implied warranty
## of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## Affero General Public License for more details.

## You should have received a copy of the Affero General Public
## License in the COPYING file that comes with The Affero Project# if
## not, write to Affero, Inc., 510 Third Street, Suite 225, San
## Francisco, CA 94107 USA.
########################################################################
#  inserts some stuff in the data base for a rating test
########################################################################
echo "------------------------------------------------------------------------"
usage="Usage $0: [-d dbname] [-U user]"

t=${AFFERO_DBNAME:="allseer"}
t=${AFFERO_USER:="allseer"}

while getopts ":d:U:" opt; do
	case $opt in
		d) AFFERO_DBNAME=$OPTARG;;
		U) AFFERO_USER=$OPTARG;;
		?) echo usage; exit1;;
	esac
done
shift $(($OPTIND - 1))

echo "$0: \$AFFERO_DBNAME is $AFFERO_DBNAME"
echo "$0: \$AFFERO_USER is $AFFERO_USER"

########################################################################
#  alseer// user
echo "------------------------------------------------------------------------"
echo "Creating alseer// user"
psql -U $AFFERO_USER $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	/* "default" user  */
	insert into as_user 
		(user_first_nm, user_last_nm, user_login, user_fwd_email, created)
		values ('lee', 'doolan', 'allseer//', 'allseer@email.com', now());

	insert into as_alt_email
		(amail_uid, amail_email, created)
		select u.user_id, 'allseer@email.com', now()
		from as_user u
		where u.user_fwd_email = 'allseer@email.com';
		
	/*  "default" expert  */
	insert into as_expert
		(expert_uid, expert_registered, created)
		select u.user_id, TRUE, now()
		from as_user u
		where u.user_fwd_email = 'allseer@email.com';

	/*  "default" client  */
	insert into as_client
		(client_uid, created)
		select u.user_id, now()
		from as_user u
		where u.user_fwd_email = 'allseer@email.com';
EOF

########################################################################
#  pay profiles
echo "------------------------------------------------------------------------"
echo "Creating pay profiles"
psql -U $AFFERO_USER $AFFERO_DBNAME <<-EOF || exit $?

    /*  these INSERTS depend on the fact that the allseer user is user #1  */
	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (1,1,'default',1,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (5,1,'.isc0',2,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (6,1,'.isc1',3,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (7,1,'.isc2',4,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (8,1,'.isc3',5,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (9,1,'.maps0',6,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (10,1,'.maps1',7,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (11,1,'.yas0',8,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (12,1,'.yas1',9,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (14,1,'.jes0',11,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (15,1,'.gdi0',12,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (16,1,'.fsf0',13,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (17,1,'.fsf1',14,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (18,1,'.fsf2',15,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (19,1,'.fsf3',16,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (20,1,'.fsf4',17,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (21,1,'.fsf5',18,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (22,1,'.fsf6',19,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (23,1,'.gnom0',20,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (24,1,'.aclu0',21,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (25,1,'.amne0',22,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (26,1,'.cc0',23,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (27,1,'.mpp0',24,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (28,1,'.eff0',25,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (29,1,'.affe0',26,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (30,1,'.ausc0',27,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (31,1,'.wcci0',28,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (32,1,'.wcci1',29,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (13,1,'.asf0',10,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (33,1,'doc',30,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (34,1,'lin',31,'t',now());

	INSERT INTO "as_pay_profiles" 
	("pprof_id","pprof_expert_id","pprof_name","pprof_xseq","pprof_active","created") 
	VALUES (35,1,'mem',32,'t',now());

	SELECT setval ('"as_pay_profiles_pprof_id_seq"', 36, 't');
EOF

########################################################################
#  pay profile details
echo "------------------------------------------------------------------------"
echo "Creating pay profile details"
psql -U $AFFERO_USER $AFFERO_DBNAME <<-EOF || exit $?

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (1,1,12,50,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (2,1,25,25,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (3,1,21,25,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (8,5,26,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (9,6,2,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (10,7,3,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (11,8,4,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (12,9,5,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (13,10,6,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (14,11,7,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (15,12,8,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (16,13,9,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (17,14,10,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (18,15,11,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (19,16,12,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (20,17,17,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (21,18,15,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (22,19,16,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (23,20,13,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (24,21,18,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (25,22,14,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (26,23,19,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (27,24,20,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (28,25,21,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (29,26,22,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (30,27,23,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (31,28,25,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (32,29,1,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (33,30,24,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (34,31,27,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (35,32,28,100,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (36,33,1,50,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (37,33,12,25,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (38,33,14,25,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (39,34,1,50,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (40,34,5,30,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (41,34,8,20,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (42,35,1,40,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (43,35,25,30,now());

	INSERT INTO "as_pprof_details" 
	("ppd_id","ppd_prof","ppd_found","ppd_percent","created") 
	VALUES (44,35,12,30,now());

	SELECT setval ('"as_pprof_details_ppd_id_seq"', 45, 'f');
EOF

########################################################################
#  mailing list table
echo "------------------------------------------------------------------------"
echo "Creating mailing list table"
psql -U $AFFERO_USER $AFFERO_DBNAME <<-EOF || exit $?

	INSERT INTO "as_mail_lists" 
	("mlist_id","mlist_name","mlist_descr","mlist_admin","created") 
	VALUES (1,'affero-members@lists.affero.net ','list for members of affero''s service',1,now());

	INSERT INTO "as_mail_lists" 
	("mlist_id","mlist_name","mlist_descr","mlist_admin","created") 
	VALUES (2,'affero-links@lists.affero.net ','list for developers of affero link inserter',1,now());

	INSERT INTO "as_mail_lists" 
	("mlist_id","mlist_name","mlist_descr","mlist_admin","created") 
	VALUES (3,'affero-docs@lists.affero.net ','list for those interested in affero documentation',1,now());

	SELECT setval ('"as_mail_lists_mlist_id_seq"', 4, 'f');
EOF

########################################################################
#  mailing list competencies
echo "------------------------------------------------------------------------"
echo "Creating mailing list competencies"
psql -U $AFFERO_USER $AFFERO_DBNAME <<-EOF || exit $?

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (1,1,45,now());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (2,1,46,now());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (3,1,47,now());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (4,1,48,now());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (5,1,49,now());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (6,1,50,now());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (7,1,51,NOW());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (8,1,52,NOW());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (9,1,53,NOW());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (10,2,33,NOW());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (11,2,34,NOW());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (12,2,35,NOW());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (13,2,36,NOW());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (14,2,37,NOW());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (15,2,38,NOW());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (16,2,39,NOW());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (17,2,40,NOW());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (18,3,41,NOW());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (19,3,42,NOW());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (20,3,43,NOW());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (21,3,44,NOW());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (22,1,54,NOW());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (23,2,55,NOW());

	INSERT INTO "as_mlist_comps" 
	("mc_id","mc_mid","mc_cid","created") 
	VALUES (24,3,56,NOW());

	SELECT setval ('"as_mlist_comps_mc_id_seq"', 25, 'f');
EOF
