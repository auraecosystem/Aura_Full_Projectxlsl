#!/bin/bash
########################################################################
#   $Name: ORG-TEST $, $Id: crtab1.sh,v 1.53 2002/11/25 17:50:49 leed Exp $
##------------------+---------------------------------------------------
## Copyright (C) 2002 Affero, Inc.

## This file is part of The Affero Project.

## The Affero Project is free software# you can redistribute it and/or
## modify it under the terms of the Affero General Public License as
## published by Affero, Inc.# either version 1 of the License, or
## (at your option) any later version.

## The Affero Project is distributed in the hope that it will be
## useful,but WITHOUT ANY WARRANTY# without even the implied warranty
## of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## Affero General Public License for more details.

## You should have received a copy of the Affero General Public
## License in the COPYING file that comes with The Affero Project# if
## not, write to Affero, Inc., 510 Third Street, Suite 225, San
## Francisco, CA 94107 USA.
########################################################################
#TODO modify 'text' attributes as appropriate to 'char' or 'varchar'
########################################################################
#  options are chose to be similar to psql except that they default
#  to 'allseer'.
#-----------------------------------------------------------------------
#   get arguments from the environment then replace with command
#   line overrides
echo "------------------------------------------------------------------------"
usage="Usage $0: [-d dbname] [-U user]"

t=${AFFERO_DBNAME:="allseer"}
t=${AFFERO_USER:="allseer"}

while getopts ":d:U:" opt; do
	case $opt in
		d) AFFERO_DBNAME=$OPTARG;;
		U) AFFERO_USER=$OPTARG;;
		?) echo usage; exit1;;
	esac
done
shift $(($OPTIND - 1))

echo "$0: \$AFFERO_DBNAME is $AFFERO_DBNAME"
echo "$0: \$AFFERO_USER is $AFFERO_USER"

########################################################################
########################################################################
if ! dropdb -U $AFFERO_USER  $AFFERO_DBNAME; then
	echo "SCRIPTERR: couldn't drop $AFFERO_DBNAME as user $AFFERO_USER"
fi

if ! createdb -U $AFFERO_USER  $AFFERO_DBNAME; then
	echo "SCRIPTERR: couldn't create $AFFERO_DBNAME as user $AFFERO_USER"
	exit 1
fi

#########################################################################
##  This little hummer shows all of the foreign keys on a table         #
#########################################################################
#psql -U "allseer"  $AFFERO_DBNAME <<-EOF
#   SELECT pt.tgargs, pt.tgnargs, pt.tgdeferrable, pt.tginitdeferred,
#	   pg_proc.proname, pg_proc_1.proname FROM pg_class pc,
#	   pg_proc pg_proc, pg_proc pg_proc_1, pg_trigger pg_trigger,
#	   pg_trigger pg_trigger_1, pg_proc pp, pg_trigger pt
#   WHERE  pt.tgrelid = pc.oid AND pp.oid = pt.tgfoid
#	   AND pg_trigger.tgconstrrelid = pc.oid
#	   AND pg_proc.oid = pg_trigger.tgfoid
#	   AND pg_trigger_1.tgfoid = pg_proc_1.oid
#	   AND pg_trigger_1.tgconstrrelid = pc.oid
#	   AND ((pc.relname= '<< TABLENAME >>>')       <<--# MODIFY THIS LINE
#	   AND (pp.proname LIKE '%%ins')
#	   AND (pg_proc.proname LIKE '%%upd')
#	   AND (pg_proc_1.proname LIKE '%%del')
#	   AND (pg_trigger.tgrelid=pt.tgconstrrelid)
#	   AND (pg_trigger_1.tgrelid = pt.tgconstrrelid));
#EOF

########################################################################
#				   A S _ A N O N _ U S E R _ S E Q					   #
########################################################################
#  this sequence is incremented every time a new anonymous user is
#  created in the database
echo "------------------------------------------------------------------------"
echo "Creating as_anon_user_seq"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	create sequence as_anon_user_seq;
EOF

########################################################################
#					A S _ C O M P E T E N C I E S					   #
########################################################################
echo "------------------------------------------------------------------------"
echo "Creating as_competencies"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	create table as_competencies (
		cmptcy_id serial PRIMARY KEY,
		cmptcy_descr text,
		cmptcy_active boolean default 'true',

		created timestamp,
		modified timestamp default now());

	grant all on as_competencies to public;
EOF

########################################################################
#					 A S _ F O U N D A T I O N S					   #
########################################################################
echo "------------------------------------------------------------------------"
echo "Creating as_foundations"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	create table as_foundations (
		foundation_id serial PRIMARY KEY,
		foundation_name text,
		foundation_url text,
		foundation_descr text,

		created timestamp,
		modified timestamp default now());

	grant all on as_foundations to public;

EOF

########################################################################
#					 A S _ U S E R  _ S T A T E S                      #
########################################################################
echo "------------------------------------------------------------------------"
echo "Creating as_user_states"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	create table as_user_states (
		ustt_state char(50) PRIMARY KEY,

		created timestamp,
		modified timestamp default now());

	grant all on as_user_states to public;

EOF

########################################################################
#							A S _ U S E R                              #
########################################################################
echo "------------------------------------------------------------------------"
echo "Creating as_user"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	create table as_user (
		user_id serial PRIMARY KEY,
		user_login char(25) UNIQUE,
		user_status char(50) references as_user_states DEFAULT 'needs-auth' NOT NULL ,
		user_passwd char(40),
		user_gui_lang char(25),
		user_last_prof char (10) not null default 'expert',

		/*-----------------------------------------------*/
		/*  'user_accept_tos' is an unused attribute.    */
		/*  once the user has passed activation req-     */
		/*  uirements, one of which is TOS acceptance,   */
		/*  then the 'user_status' attribute will        */
		/*  transition from 'needs-auth' to 'activated'  */
		user_accept_tos  char(10),

		/*-----------------------------------------------*/
		/*  these are residence fields                   */
		/*  they should be addressed with a foreign key  */
		/*  in another table sucha as as_user_residence  */
		user_res_country char(25),
		user_res_phone char(25),

		/*-----------------------------------------------*/
		/*  these are all billing info fields although   */
		/*  they are not so named; they really should be */
		/*  placed in another table, like maybe 		 */
		/*  as_user_billinfo.							 */
		user_first_nm char(100),
		user_last_nm char(100),
		user_fwd_email text UNIQUE,
		user_company char(100),
		user_address1 char(100),
		user_address2 char(100),
		user_city char(100),
		user_state_prov char(100),
		user_postal_cd char(25),
		user_country char(25),
		user_timezone char(10),
		user_phone char(25),
		user_fax char(25),

		created timestamp,
		modified timestamp default now());

	grant all on as_user to public;

	alter table as_user add check (lower(trim(user_last_prof)) in ('client', 'expert'));
EOF

########################################################################
#						  A S _ E X P E R T				  			   #
########################################################################
#  note that the user id references as_user, but an expert record can be
#  present in the database as a side effect of someone having been rated
#  by a client.  This case is reflected by a value of 'false' in the
#  expert_registered attribute.
echo "------------------------------------------------------------------------"
echo "Creating as_expert"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	create table as_expert (
		expert_id serial PRIMARY KEY,
		expert_uid int references as_user,

		expert_registered boolean default 'false',
		expert_public boolean default 'false',
		expert_rate_notify boolean default 'false',
		expert_tip_notify boolean default 'false',

		/*  default pay profile                           */
		expert_profile int,

		created timestamp,
		modified timestamp default now());

	grant all on as_expert to public;
EOF

########################################################################
#			 A S _ E X P E R T _ C O M P E T E N C I E S  			   #
########################################################################
echo "------------------------------------------------------------------------"
echo "Creating as_expert_competencies"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	create table as_expert_competencies (
		xcmp_id serial PRIMARY KEY,
		xcmp_expert int references as_expert,
		xcmp_cmptcy int references as_competencies,
		xcmp_level int,
		xcmp_note text,

		created timestamp,
		modified timestamp default now());

	grant all on as_expert_competencies to public;
EOF

########################################################################
#					  A S _ M A I L _ L I S T S						   #
########################################################################
echo "------------------------------------------------------------------------"
echo "Creating as_mail_lists"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	create table as_mail_lists (
		mlist_id serial PRIMARY KEY,
		/*  this is the email address for the mailing list  */
		mlist_name char(200),
		mlist_descr text,
		/*  mailing list admin is in the expert table  */
		mlist_admin int references as_expert,

		created timestamp,
		modified timestamp default now());

	grant all on as_mail_lists  to public;

EOF

########################################################################
#						 A S _ R A T I N G S			  			   #
########################################################################
echo "------------------------------------------------------------------------"
echo "Creating as_ratings"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	create table as_ratings (
		rating_id serial PRIMARY KEY,
		rating_rator int references as_user NOT NULL,
		rating_ratee int references as_user NOT NULL,
		rating_rid int references as_ratings,

		rating_mlist int references as_mail_lists,
		rating_subj text,
		rating_msgid char(75),

		rating_value int NOT NULL,
		rating_category int references as_competencies,
		rating_descr text,

		created timestamp,
		modified timestamp default now());

	grant all on as_ratings to public;
EOF

########################################################################
#					A S _ P A Y _ P R O F I L E S		  			   #
########################################################################
#  pay profiles are associated with experts (for now) they are never
#  deleted, but they may be inactivated.
echo "------------------------------------------------------------------------"
echo "Creating as_pay_profiles"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	create table as_pay_profiles (
		pprof_id serial PRIMARY KEY,
		pprof_expert_id int references as_expert,
		pprof_name text,
		pprof_xseq int,
		/*  the propaganda field.  this is a piece of html that */
		/*  appears on the ratings screen                       */
		pprof_proppa_tp char(10) DEFAULT 'plain',
		pprof_proppa text,
		pprof_active boolean DEFAULT 'true' NOT NULL,

		created timestamp,
		modified timestamp default now());

	grant all on as_pay_profiles to public;
EOF

psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1
	alter table as_pay_profiles add check (lower(trim(pprof_proppa_tp)) in ('plain', 'html'));
    alter table as_expert add foreign key (expert_profile )references as_pay_profiles;
EOF

########################################################################
#				   A S _ P P R O F _ D E T A I L S                     #
########################################################################
echo "------------------------------------------------------------------------"
echo "Creating as_pprof_details"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	create table as_pprof_details (
		ppd_id serial PRIMARY KEY,
		ppd_prof int references as_pay_profiles,
		ppd_found int references as_foundations,
		ppd_percent int,

		created timestamp,
		modified timestamp default now());

	grant all on as_pprof_details to public;
EOF

########################################################################
#						  A S _ C L I E N T				  			   #
########################################################################
echo "------------------------------------------------------------------------"
echo "Creating as_client"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	create table as_client (
		client_id serial PRIMARY KEY,
		client_uid int references as_user,
		client_rate_notify boolean default 'yes',
		client_gift_notify boolean default 'yes',
		client_tip_history char(10) default 'Public',

		/*  public profile is is viewable  				  */
		client_public boolean default true,

		created timestamp,
		modified timestamp default now());

	grant all on as_client to public;
EOF

########################################################################
#					   A S _ A L T _ E M A I L                         #
########################################################################
echo "------------------------------------------------------------------------"
echo "Creating as_alt_email"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	create table as_alt_email (
		amail_id serial PRIMARY KEY,
		amail_uid int references as_user,
		amail_email text UNIQUE,
		amail_activep boolean DEFAULT 'f' NOT NULL,

		created timestamp,
		modified timestamp default now());

	grant all on as_alt_email to public;
EOF

########################################################################
#							A S _ T I P S				  			   #
########################################################################
echo "------------------------------------------------------------------------"
echo "Creating as_tips"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	create table as_tips (
		tip_id serial PRIMARY KEY,
		tip_grantor int references as_user,
		tip_recipient int references as_user,
		tip_rating int references as_ratings,
		tip_profile_id int references as_pay_profiles,
		tip_amt int,						 /* tip ammount in cents  */

		created timestamp,
		modified timestamp default now());

	grant all on as_tips to public;
EOF

########################################################################
#							A S _ B P C T                              #
########################################################################
#  a table of beneficiary percentages.  rows in this table are written
#  as part of a vault transaction.  maps tips to pay profiles at the
#  time that the transaction happened.  Rows in the table may be
#  interpreted as meaning that foundation F gets percent P of tip T.
echo "------------------------------------------------------------------------"
echo "Creating as_bpct"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	create table as_bpct (
		bpct_id serial PRIMARY KEY,
		bpct_tip int references as_tips NOT NULL,
		bpct_foundation int references as_foundations NOT NULL,
		bpct_percent int,
		created timestamp,
		modified timestamp default now());

	grant all on as_bpct to public;
EOF

########################################################################
#					 A S _ T C _ X A C T I O N S                       #
########################################################################
#  a table of trust commerce transactions
echo "------------------------------------------------------------------------"
echo "Creating as_tc_xactions"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	create table as_tc_xactions (
		tcx_id serial PRIMARY KEY,
		tcx_tip_id int references as_tips NOT NULL UNIQUE,
		tcx_name char(100),
		tcx_transid char(50),
		tcx_transdate char(50),
		tcx_cardtp char(50),
		tcx_transstatus text,
		tcx_valarray text,
		created timestamp,
		modified timestamp default now());

	grant all on as_tc_xactions to public;
EOF

########################################################################
#						A S _ S E S S I O N S                          #
########################################################################
#  a table of session data
echo "------------------------------------------------------------------------"
echo "Creating as_sessions"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	create table as_sessions (
		sid varchar(255) PRIMARY KEY,
		val text not null,
		created timestamp,
		modified timestamp default now());

	grant all on as_sessions to public;
EOF

########################################################################
#					 A S _ M L I S T _ C O M P S                       #
########################################################################
#  a one to many relation from mailing lists to competencies
echo "------------------------------------------------------------------------"
echo "Creating as_mlist_comps"
psql -U "allseer"  $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	create table as_mlist_comps (
		mc_id serial PRIMARY KEY,
		mc_mid int references as_mail_lists,
		mc_cid int references as_competencies,

		created timestamp,
		modified timestamp default now());

	grant all on as_mail_lists  to public;

EOF
