#!/bin/bash
########################################################################
#   $Name: ORG-TEST $, $Id: db2Proppa.sh,v 1.3 2002/05/15 20:04:11 leed Exp $
########################################################################
##------------------+---------------------------------------------------
## Copyright (C) 2002 Affero, Inc.

## This file is part of The Affero Project.

## The Affero Project is free software# you can redistribute it and/or
## modify it under the terms of the Affero General Public License as
## published by Affero, Inc.# either version 1 of the License, or
## (at your option) any later version.

## The Affero Project is distributed in the hope that it will be
## useful,but WITHOUT ANY WARRANTY# without even the implied warranty
## of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## Affero General Public License for more details.

## You should have received a copy of the Affero General Public
## License in the COPYING file that comes with The Affero Project# if
## not, write to Affero, Inc., 510 Third Street, Suite 225, San
## Francisco, CA 94107 USA.
##----------------------------------------------------------------------
#
#  inserts some stuff in the data base for a rating test
echo "------------------------------------------------------------------------"
usage="Usage $0: [-d dbname] [-U user]"

t=${AFFERO_DBNAME:="allseer"}
t=${AFFERO_USER:="allseer"}

while getopts ":d:U:" opt; do
	case $opt in
		d) AFFERO_DBNAME=$OPTARG;;
		U) AFFERO_USER=$OPTARG;;
		?) echo usage; exit1;;
	esac
done
shift $(($OPTIND - 1))

echo "$0: \$AFFERO_DBNAME is $AFFERO_DBNAME"
echo "$0: \$AFFERO_USER is $AFFERO_USER"

########################################################################
###  AS_USER_STATES            #########################################
########################################################################
echo "------------------------------------------------------------------------"
echo "ADD PROPAGANDA ATRIBUTE TO AS_PROFILES"
psql -U $AFFERO_USER $AFFERO_DBNAME <<-EOF || exit $?
	\set ON_ERROR_STOP 1

	alter table as_pay_profiles add column pprof_proppa text;
	alter table as_pay_profiles add column pprof_proppa_tp char(10) DEFAULT 'plain';
	alter table as_pay_profiles add check (lower(trim(pprof_proppa_tp)) in ('plain', 'html'));
	update as_pay_profiles set pprof_proppa_tp='plain';

	alter table as_competencies add column cmptcy_active boolean DEFAULT 'true';
	update as_competencies set cmptcy_active='true';

EOF

