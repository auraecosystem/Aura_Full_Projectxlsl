#! /usr/bin/perl 

# script to install rpm kits into the affero production locations
# the script assumes you have copied the files into /tmp on the 
# production machine.

# changelog
# v.2 by robert coli (rcoli@affero.org)
#     - moves to a more general architechture, moves definitions out
#       of the main perl file and into a "templates" file
#     - also 2 dimensional arrays for storing related information :)
# v.1 by jerry scharf (scharf@goral.org)

$rpmpath = "/usr/src/rpms";
$rpmpost = ".i386.rpm";
$rpmre = ".*\.i386\.rpm";
#$pathpre = "/usr/local/syswork/affero_testing/htdocs/";
$pathpre = "/affero/htdocs/";

    use Getopt::Std;            # command line options processing
    my $opt_string = 'ht:yr';
    getopts( "$opt_string", \my %opt );

    usage() and exit if $opt{h};

# command line option to allow you to specify
# another template file
if(defined($opt{t})){
$conf_file=$opt{t};
}else{
$conf_file="./rpm_vars";
}

# read in the templates with getTemplate()
&getTemplate($conf_file);

my @sitelist = sort(keys(%Templates));

# set up some name mapping
opendir RPMDIR, $rpmpath or die "unable to open rpm directory";

while ($nextfile = readdir RPMDIR)
{

#print("$nextfile is NEXTFILE\n");

    if ($nextfile =~ /$rpmre/)
    {
	foreach $sb (@sitelist)
	{
	
	    $re = ".*" . $Templates{$sb}{'RPMPRE'} . "(\\S*)" . $rpmpost;

            #print("$sb is SB $re is RE\n");

	    if ($nextfile =~ /$re/)
	    {

# skip over kits that are already installed and error and continue if a
# file that is not a directory is found where we want to create the site
		$ver = $1;
		$fullpath = $pathpre . $Templates{$sb}{'SITE'} . $Templates{$sb}{'DIRPRE'} . $ver;

# move the old current out of the way if we're -r(einstalling)A
		if(($opt{r}) && (-d $fullpath)){
		my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
		$year+="1900";
		rename($fullpath,"${fullpath}___$mon.$mday.$year-$min.$sec");
		print("Moving $fullpath to ${fullpath}___$mon.$mday.$year-$min.$sec because we are -r(einstalling) it!\n");

		}

		if (-d $fullpath) {last;}
		if (-e $fullpath) {
		    print "can't install " . $nextfile . " becuuse there is already a file at " . $fullpath . " ... continuing\n";
		    last;
		}

# got a possible kit to install. now ask if we want to do it.
		print "do you want to install " . $nextfile . "? [yn] ";
                if($opt{y}){ $ans="y"; print("-y specified, answering yes\n"); }else{ $ans = <STDIN>;}
		if ($ans =~ /[Yy].*/)
		{
# now we're ready to do something useful
		    system("mkdir -p \'$fullpath\'");
# or die "unable to make target directory";
		    $cmd = "rpm -i -v --force --prefix " . $fullpath . " " .$rpmpath."/". $nextfile;
		    if (system $cmd) {die "rpm command failed";}
		    print "are you ready to make it current? [yn] ";
                    if($opt{y}){ $ans="y"; print("-y specified, answering yes\n"); }else{ $ans = <STDIN>;}
		    if ($ans =~ /[Yy].*/)
		    {

			$cmd2 = "cd -- " . $pathpre . $Templates{$sb}{'SITE'} . "; rm -f current-last; mv current current-last; ln -s -- " . $Templates{$sb}{'DIRPRE'} . $ver . "/htdocs current";
#print("$cmd2 is CMD2 \n");
			if (system $cmd2) {die "making current died, CHECK IMMEDIATELY";}
		    }
		}
#		print "do you want to delete " . $nextfile . "? [yn] ";
#		read STDIN, $ans, 2;
#		if ($ans =~ /[Yy].*/)
#		{
#		    unlink $nextfile or die "unable to delete the rpm file";
#		}
	    }
	}
    }
}

####################################################################
# getTemplate(FILENAME) adds the info from template in FILENAME
#                       into a global hash called %Templates which
#                       is keyed on filenames of svcs
####################################################################

sub getTemplate {

my $filename=$_[0];

open(TEMPLATE,"$filename")|| die("Can't open Template file $filename : $! \n");

####################################################################
# TEMPLATE INFO
# : is the seperator here. 
# site identifier:rpmpre:site_dir:dirpre
# site identifier is an easy way to refer to the site
# rpmpre is the prefix on the rpm given
# site_dir is the top level directory for htdocs for the site
# dirpre is 
#com:static-com:site.affero.com/:affero.com



        TEMPLATE: while(<TEMPLATE>){
                next TEMPLATE if ($_ =~ /^(\s+)?#/);
                next TEMPLATE if ($_ =~ /^\n/);
        chomp;
	my @tempArray=split(/:/,$_);
	my $sb=$tempArray[0];
        ($Templates{$sb}{'ID'},$Templates{$sb}{'RPMPRE'},$Templates{$sb}{'SITE'},$Templates{$sb}{'DIRPRE'})=@tempArray;

        # end TEMPLATE:
        }

#end getTemplate
}


sub usage()
    {
        print STDERR << "EOF";

    usage: $0 [-h] [-y] [-r] [-t file]

     -h       : this (help) message
     -r       : reinstall packages. if rpm ver is already in place, moves it to
                a timestamped directory. NOTE : This reinstalls each package
		previous to being prompted whether you want to install the replacement one.
     -y       : answer 'yes' to all questions
     -t file  : file containing package wrapper templates, one per line
    
     example: $0 -t ~leed/rpm_vars


EOF
    }

