<?php
// $Name: ORG-TEST $, $Id: client-public-profile.php,v 1.8 2002/03/19 02:47:07 leed Exp $
////////////////////////////////////////////////////////////////////////
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
//  TODO:  this screen barfs if no m= argument is passed on the
//         request URL.  fix this.
////////////////////////////////////////////////////////////////////////
//  get here by clicking on a "rate me" link
//
require_once("global.php");
require_once("allseer.clientProfile.php");

$clientProfile = new clientProfile;
//phpinfo();


//  process URL arguments
$u = (isset($u)) ? $u : "lenna_0025";     //  DEVEL-ONLY>> client userid

if (!isset($u)) {
    // WTODO: if no user argument is passed on the URL?    
    header ("Location: notice.php?code=" . urlencode("client-public-profile.php missing user arg"));
    exit;
}

$clientProfile->setUserLogin($u);
if (!$clientProfile->init_public($u)) {
    // WTODO: if we can't build the clientProfile object?
    header ("Location: notice.php?code=" . urlencode("client-public-profile.php site 1. Object init failure"));
    exit;
}
//var_dump($clientProfile->PaymentArray);

$smarty = new Smarty;
$smarty->assign("ClientProfile", $clientProfile);
$smarty->display("client-public-profile.tpl");
header ("Location: index.php");
exit;
?>
