<?php
// $Name: ORG-TEST $, $Id: expert-profile.php,v 1.23 2002/10/11 17:53:17 leed Exp $
////////////////////////////////////////////////////////////////////////
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
//  TODO:  this screen barfs if no m= argument is passed on the
//         request URL.  fix this.
////////////////////////////////////////////////////////////////////////
//  get here by clicking on a "rate me" link
//
require_once("global.php");
require_once("allseer.expertProfile.php");
require_once("allseer.arrayLoader.php");
require_once("allseer.sessions.php");
//phpinfo();

$mySess = new sessionRep;
$expertProfile = new expertProfile;

//  process URL arguments
//$u = (isset($u)) ? $u : "Sly000004";     //  DEVEL-ONLY>> expert userid

// user logon id must be set by now
if (!isset($u)) {
    header ("Location: index.php");
    exit;
}

//  start a session for this user
$mySess->start($u);
$mySess->authorize($u);

$expertProfile->v= isset($v) ? $v : FALSE;

//  initialize the expert object.  bust out on failure.
if (!$expertProfile->init($u)) {
    if ($expertProfile->userRow['user_status'] == "inactivated") {
        header ("Location: index.php");
        exit;
    }
    header ("Location: notice.php?code=" . urlencode("expert-profile.php site 1. Object init failure"));
    exit;
}

if (isset($FormValidate)) {
    $expertProfile->validateFields();
}

if (!$expertProfile->validated()) {
    $arrayLoader = new arrayLoader;
    $smarty = new Smarty;
    //echo("<br>dpyProfile..."); var_dump($expertProfile->dpyProfile);
    //echo("<br><br>typeAry..."); var_dump($expertProfile->proppaTpAry);
    
    $smarty->assign("ExpertProfile", $expertProfile);
    $smarty->display("expert-profile.tpl");

} else {
    //  update the database here
    $dbRc = $expertProfile->Finalize();
    if (!$dbRc) {
        header ("Location: notice.php?code=" . urlencode($expertProfile->Message));
        exit;
    }
    if ($expertProfile->deActivated()){
        //  WTODO: after expert profile is updated?
        header ("Location: index.php");
        exit;
    }
    header ("Location: expert-profile.php?u=$u");
    exit;
}
?>
