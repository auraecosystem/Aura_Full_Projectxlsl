<?php
//  $Name: ORG-TEST $, $Id: index.php,v 1.17 2002/12/13 20:00:15 leed Exp $
////////////////////////////////////////////////////////////////////////
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
require_once("global.php");
require_once("allseer.arrayLoader.php");
//phpinfo();

if ($configgedForLive){
    header("Location: http://www.affero.net");
}

$arrayLoader = new arrayLoader;

$smarty = new Smarty;
if (isset($CVSBranchId)) {
    echo("<center>");
    echo("<table bgcolor=red cellpadding=0 cellspacing=0 border=0>");
    echo("<tr><td color=white><br><b>$CVSBranchId</b></td></tr>");
    echo("<tr><td><br></td></tr>");
    echo("</table>");
    echo("</center>");
}


$smarty->assign("ColHeadings", array("Free Software (GPL)", "Open Source Software (BSD)"));
$smarty->display("allseer.tpl");
?>
