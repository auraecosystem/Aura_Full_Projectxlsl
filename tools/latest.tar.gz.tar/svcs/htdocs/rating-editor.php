<?php
// $Name: ORG-TEST $, $Id: rating-editor.php,v 1.2 2002/09/02 21:31:16 leed Exp $
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
require_once("global.php");
require_once("allseer.ratingEditor.php");

$ratingEditor= new ratingEditor;
$smarty = new Smarty;

if (($code= $ratingEditor->init()) != "OK") {
    header ("Location: error.php?code=" . urlencode($code));
    exit;
}

$smarty->assign("RatingEditor", $ratingEditor);
if (!$ratingEditor->validateFields()) {
    $smarty->display("rating-editor.tpl");
    exit;
    
} else if (($dbCode= $ratingEditor->Finalize()) != "OK") {
    header ("Location: error.php?code=" . urlencode($dbCode));
    exit;
}
echo("<br><font size=+1> <b>Edit Complete</b></font><br>");

?>
