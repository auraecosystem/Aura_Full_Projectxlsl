<?php
//  $Name: ORG-TEST $, $Id: list-comps.php,v 1.3 2002/05/15 21:00:34 leed Exp $
////////////////////////////////////////////////////////////////////////
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
require_once("global.php");
require_once("allseer.editListComps.php");
require_once("allseer.sessions.php");
//phpinfo();

$mySess = new sessionRep;
$lc_editor = new lc_editor();

if (!isset($u)) {
     header("Location: notice.php?code=" . urlencode("(lCats) Your request cannot be served."));
     exit;
}

//  start a session for this user
$mySess->start($u);
$mySess->authorize($u);

//  init initialize the editor object
if (($msg= $lc_editor->init(&$mySess)) != "OK") {
    // WTODO: if we can't build the lc_editor object?
    $mySess->unregister("backTo");
    $mySess->save();
    //echo("<br>mySess..."); var_dump ($mySess);
    
    header ("Location: notice.php?code=". urlencode($msg));
    exit;
}

if (isset($FormValidate)) {
    //  move form fields into the edit object
    $lc_editor->validateFields();
    
    //  if the database update goes ok then re-initialise this screen
    //  and start all over otherwise publish an error message
    if ($lc_editor->validated()) {
        if (($msg= $lc_editor->Finalize()) == "OK") {
            header("Location: list-comps.php?u=". urlencode($u));
            exit;
            
        } else {
            header ("Location: notice.php?code=" . urlencode("$msg"));
            exit;
        }    
    }
}

$lc_editor->setDisplayInfo();

$smarty = new Smarty;
$smarty->assign("lComps", $lc_editor);
$smarty->display("list-comps.tpl");
?>
