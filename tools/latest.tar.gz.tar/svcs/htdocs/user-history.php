<?php
// $Name: ORG-TEST $, $Id: user-history.php,v 1.3 2002/12/09 17:19:40 leed Exp $
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
require_once("global.php");
require_once("allseer.userHistory.php");
require_once("allseer.sessions.php");

$mySess = new sessionRep;
$smarty = new Smarty;

$history = new userHistory;
if (($code= $history->init(&$mySess)) != "OK") {
    if ($history->browserErrorDisplay == "") {
        header ("Location: error.php?code=$code");
        
    } else {
        $smarty->assign("UserHistory", $history);
        $smarty->display("user-history-error.tpl");
    }
    exit;
}

$smarty->assign("UserHistory", $history);
$smarty->display("user-history.tpl");
header ("Location: error.php?code=" . urlencode("**user-history.php Smarty drop-through**"));
exit;

?>
