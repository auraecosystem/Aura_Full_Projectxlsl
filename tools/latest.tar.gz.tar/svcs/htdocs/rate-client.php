<?php
// $Name: ORG-TEST $, $Id: rate-client.php,v 1.11 2002/09/02 21:31:12 leed Exp $
////////////////////////////////////////////////////////////////////////
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
//  get here by clicking on a "rate me" link
require("global.php");
require("allseer.rateClient.php");

$rateClient = new rateClient;
if (($msg= $rateClient->init()) != "OK") {
    // WTODO: if we can't build the rateClient object?
    $errArgs =  urlencode("rateClient::init() returns '$msg'");
    header ("Location: notice.php?code=$errArgs");
    exit;
}

if (isset($FormValidate)) {
    $rateClient->Value = $FormValue;
    $rateClient->Comment = $FormComment;
    
    $rateClient->validateFields();
}

if (!$rateClient->validated() || !$rateClient->passwdCheck()) {
    $smarty = new Smarty;
    $smarty->assign("RateClient", $rateClient);
    $smarty->display("rate-client.tpl");

} else {
    //  update the database here and go on to fill in payment
    //  information
    if ($dbRc= $rateClient->Finalize()) {
        $noteArgs= urlencode("Thank you. Your feedback has been successfully submitted.");
        
    } else {
        $noteArgs=  urlencode("<rate-client.php> Couldn't insert client rating");
    }
    header ("Location: notice.php?code=$noteArgs");
    exit;
}

?>
