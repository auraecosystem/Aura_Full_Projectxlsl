{include file="header.tpl"}
<!--  $Name: ORG-TEST $, $Id: forgot-pass.tpl,v 1.11 2002/09/02 21:32:26 leed Exp $  -->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{config_load file="Smarty.Affero.conf"}
{assign var=myServer value=$smarty.server.HTTP_HOST}

<!-- //////////////  HTML GENERATION STARTS HERE  ////////////////// -->

<table width="100%" cellpadding=0 cellspacing=0 border=0>
<tr><td>
{assign var=ABB2_CELL1 value="FORGOT PASSWORD"}
{assign var=ABB2_CELL2 value=" "}
{include file="allseer-bluebar2.tpl"}
</td></tr>

<!--  .............................................................  -->
<!--  ...........................Form..............................  -->
<FORM METHOD=POST ACTION="forgot-pass.php">
<tr><td>&nbsp;<br></td></tr>
<!--             personalization error messages here                 -->
{section name=tmsg loop=$ErrorMessages}
<tr><td colspan=2>
  <FONT  color="red">
  <b>{$ErrorMessages[tmsg]}</b></FONT>
</td></tr>
{if %tmsg.last%}
<tr><td colspan=2>&nbsp;</td></tr>
{/if}
{/section}

<tr valign=middle><td align=center>
    <table  bgcolor="#cccccc" width="75%" cols=2 cellpadding=0 cellspacing=0 border=0>
        <tr><td colspan=2 align=left><b>Forgot Password</b></td></tr>
    </table>
</td></tr>
<tr valign=middle>
<td align=center>
    <table  bgcolor="#cccccc" width="75%" cols=2 cellpadding=0 cellspacing=0 border=0>
        <tr>
        <td align=left valign=middle width="15%">
        Your email address:</td>
        <td>&nbsp;
        <INPUT type=TEXT name=formEmail maxlength=50 size=35>
        </td></tr>
        <tr valign=bottom>
        <td colspan=2>
        <FONT  size=-1 color="black">
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; 
        <b>Email with username and instructions to change password will be sent to you shortly</b>
        </FONT>
        </td>
        </tr>
    </table>
</td></tr>
<!--  .............................................................  -->
<!--  .................    Form Submission    .....................  -->
<tr valign=middle>
<td align=center>
<INPUT TYPE=submit value="Submit Request">
<FONT  size=-1 color="gray"><b>&nbsp;</b></FONT>
</td></tr>
<!--  .............................................................  -->
<!--  ..................    Hidden Fields    ......................  -->
</FORM>

<!--  .............................................................  -->
<!--  ...........................FAQs..............................  -->
<tr><td colspan=2>
{assign var=ABB2_CELL1 value=" "}
{assign var=ABB2_CELL2 value=#AFFLINX#}
{include file="allseer-bluebar2.tpl"}

</td></tr>
</table>

<!--  .............................................................  -->
<!--  ..........................Footer.............................  -->
{include file="footer.tpl"}

