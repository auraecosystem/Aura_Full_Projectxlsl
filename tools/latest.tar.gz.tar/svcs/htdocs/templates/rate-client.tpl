{include file="header.tpl"}
<!--  $Name: ORG-TEST $, $Id: rate-client.tpl,v 1.18 2002/09/02 21:31:21 leed Exp $  -->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{config_load file="Smarty.Affero.conf"}
{assign var=myServer value=$smarty.server.HTTP_HOST}

<!-- //////////////  HTML GENERATION STARTS HERE  ////////////////// -->

<table width="100%" cellpadding=2 cellspacing=0 border=0>
<tr><td>
{assign var=ABB2_CELL1 value="RATE: $RateClient->BarString"}
{assign var=ABB2_CELL2 value=" "}
{include file="allseer-bluebar2.tpl"}
</td></tr><tr><td>

<FORM METHOD=POST ACTION="rate-client.php">

<table width="100%" cellpadding=3 cellspacing=0 border=0>

<tr valign=middle>
<td align=right class="fld-title">Rate the value of the feedback received:</td>
<td><font color=red size=2>&nbsp;</font></td>
<td colspan=2>&nbsp;
<select name=FormValue>
{section name=rating loop=$RateClient->Ratings}
<option value="{$RateClient->Ratings[rating].rating_val}">{$RateClient->Ratings[rating].rating_descr}</option>
{/section}
</select>
<FONT  size=-1 color="gray"><b>&nbsp;</b></FONT>
</td></tr>

<tr valign=middle>
<td align=right class="fld-title">Comment:</td>
<td>&nbsp;</td>
<td colspan=2>&nbsp;
<TEXTAREA name=FormComment rows=2 cols=40 wrap=soft>{$RateClient->Comment}</TEXTAREA>
<FONT face="Arial,Helvetica" size=-1 color="gray"><b>&nbsp;</b></FONT>
</td></tr>

<tr valign=middle>
<td align=right class="fld-title">&nbsp;</td>
<td>&nbsp;</td>
<td colspan=2>&nbsp;
<INPUT TYPE=submit value="Submit This form">
<FONT face="Arial,Helvetica" size=-1 color="gray"><b>&nbsp;</b></FONT>
</td></tr>

</table>
<INPUT TYPE=hidden name=FormValidate value="1">
<INPUT TYPE=hidden name=cb value="{$RateClient->cb}">
<INPUT TYPE=hidden name=k value="{$RateClient->k}">
</FORM>
</td></tr>

<!--  .............................................................  -->
<!--  ...........................FAQs..............................  -->
<tr><td colspan=2>
{assign var=ABB2_CELL1 value="FAST FAQs"}
{assign var=ABB2_CELL2 value=#AFFLINX#}
{include file="allseer-bluebar2.tpl"}

</td></tr><tr><td colspan=2 align=center>
    <a target="new" href="http://{$myServer}/help.php?helpCat=RCwhyfeedbk">Why offer feedback?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=RCwhatpriv">What is Affero's privacy policy?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=RChowsource">How do I get the source code?</a>&nbsp;
</td></tr></table>

{include file="footer.tpl"}




