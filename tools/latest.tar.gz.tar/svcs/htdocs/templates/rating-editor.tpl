{include file="header.tpl"}
<!--  $Name: ORG-TEST $, $Id: rating-editor.tpl,v 1.2 2002/09/02 21:33:50 leed Exp $  -->
<!-- ---------------------------------------------------------------- -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- ---------------------------------------------------------------- -->
{config_load file="Smarty.Affero.conf"}
{assign var=myServer value=$smarty.server.HTTP_HOST}

<!-- --------------  HTML GENERATION STARTS HERE  ------------------ -->

<table width="100%" cellpadding=2 cellspacing=0 border=0>
<tr><td>
{assign var=ABB1_CELL1 value=$RatingEditor->topBarCell1}
{include file="allseer-bluebar1.tpl"}
</td></tr>

<!--  .............................................................  -->
<!--  ...........................Form..............................  -->
<FORM METHOD=POST ACTION="rating-editor.php">
<!--  .............................................................  -->
<tr><td>
<table width="100%" cellpadding=0 cellspacing=0 border=0>
  <tr valign=middle>
  <td align=right class="fld-title" width="30%">modify the comment</td>
  <td><font color=red size=2>&nbsp;</font></td>
  <td colspan=2>&nbsp;
  <TEXTAREA name=FormComment tabindex=2 rows=2 cols=40 wrap=soft>{$RatingEditor->rating.rating_descr}</TEXTAREA>
  <FONT  size=-1 color="gray"><b>&nbsp;</b></FONT>
  </td></tr>
</table>
</td></tr>
<!--  .............................................................  -->
<tr><td>
<table width="100%" cellpadding=0 cellspacing=0 border=0>
  <tr valign=middle>
  <td class="fld-title" align=right width="30%">Check here to <font color=red>DELETE</font> this rating:&nbsp;</td>
  {assign var=CHSTATE value=" "}
  <td align=left>&nbsp;
      <input TYPE=checkbox VALUE="t" NAME=FormDeleteRequest {$CHSTATE}>
  </td></tr>
</table>
</td></tr>

<!--  .....................  Form Submit  .........................  -->
<tr><td>
<table width="100%" cols=2 cellpadding=2 cellspacing=0 border=0>
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">Click here to save changes above:&nbsp;</td>
    <td align=left>
    <INPUT TYPE=submit value="Update Preferences"><FONT  size=-1 color="gray"><b>&nbsp;</b></FONT>
    </td></tr>
</table>
</td></tr>

<INPUT TYPE=hidden name=FormValidate value="1">
<INPUT TYPE=hidden name=rid value="{$RatingEditor->rid}">
<INPUT TYPE=hidden name=action value="{$RatingEditor->action}">
</FORM>


<!--  .............................................................  -->
<!--  ...........................FAQs..............................  -->
<tr><td colspan=2>
{assign var=ABB2_CELL1 value="&nbsp;"}
{assign var=ABB2_CELL2 value=#AFFLINX#}
{include file="allseer-bluebar2.tpl"}
</td></tr>

</table>

<!--  .............................................................  -->
<!--  ..........................Footer.............................  -->
{include file="footer.tpl"}
