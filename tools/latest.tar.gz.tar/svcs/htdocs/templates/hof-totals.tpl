{include file="header.tpl"}
<!--  $Name: ORG-TEST $, $Id: hof-totals.tpl,v 1.5 2002/09/02 21:32:39 leed Exp $  -->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{assign var=myServer value=$smarty.server.HTTP_HOST}


{include file="allseer-logo1.tpl"}

<table width="100%" cellpadding=3 cellspacing=0 border=0>
    <tr><td rowspan=15 valign=top>
    <table width="30%" cellpadding=3 cellspacing=1 border=1>
<!-- /////////////////////////////////////////////////////////////// -->
     <tr><td COLSPAN="3">
        <table  border=0 cellspacing=0 cellpadding=0 width="100%">
            <tr> <th align=center colspan=5 width=100% BGCOLOR="cadetblue"> 
              {$HOFObject->summaryType}&nbsp;{$HOFObject->timeFrame}&nbsp;Details</th>
            </tr>
            <tr> 
              <th align=left   width=10% BGCOLOR="#E0D0B0">&nbsp;</th>
              <th align=left   width=50% BGCOLOR="#E0D0B0">{$HOFObject->summaryType}&nbsp;Name</th>
              <th align=right  width=10% BGCOLOR="#E0D0B0">Rating Average</th>
              <th align=left   width=15% BGCOLOR="#E0D0B0">&nbsp;</th>
              <th align=right  width=15% BGCOLOR="#E0D0B0">{$HOFObject->columnThree}</th>
            </tr>
            {section name=sum loop=$HOFSummary}
              <tr>
                <td width="10%" valign=top>{if %sum.iteration% < 10}&nbsp;{/if}{%sum.iteration%})&nbsp;</td>
                <td WIDTH="50%" align=LEFT><a href="http://{$myHost}/expert-public-profile.php?u={$HOFSummary[sum].login|escape:"url"}">
                  <font face="arial"><font size=-1>{$HOFSummary[sum].login} </font></font></a></td>
                <td WIDTH="15%" ALIGN=RIGHT COLSPAN="1">{$HOFSummary[sum].avg}</td>
                <td WIDTH="10%" ALIGN=RIGHT COLSPAN="1">&nbsp;</td>
                {assign var=UARG value="Expert Ratings list"}
                <td WIDTH="15%" ALIGN=RIGHT COLSPAN="1"><a href="http://{$myHost}/unimplemented.php?code={$UARG|escape:"url"}">
                  <font face="arial"><font size=-1></font>
                    {if $HOFObject->summaryType == "Client"}
                      {$HOFSummary[sum].bux}
                    {else}
                      {$HOFSummary[sum].count}
                    {/if}
                  </font></a></td>
              </tr>
            {/section}
        </table>
    </td></tr>
<!-- /////////////////////////////////////////////////////////////// -->
    </table>
    </td></tr>
</table>

<a href="http://{$myHost}">Click here to restart</a>


{include file="allseer-footer.tpl"}

{include file="footer.tpl"}
