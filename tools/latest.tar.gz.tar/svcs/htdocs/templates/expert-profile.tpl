{include file="header.tpl"}
<!--  $Name: ORG-TEST $, $Id: expert-profile.tpl,v 1.34 2002/09/02 21:33:23 leed Exp $  -->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{config_load file="Smarty.Affero.conf"}
{assign var=myServer value=$smarty.server.HTTP_HOST}

<!-- //////////////  HTML GENERATION STARTS HERE  ////////////////// -->

<table width="100%" cellpadding=2 cellspacing=0 border=0>
<tr><td>
{assign var=escapedUID value=$ExpertProfile->uid|escape:"url"}
{assign var=ABB2_CELL1 value="UPDATE VOLUNTEER  PREFERENCES: $ExpertProfile->BarString"}
{assign var=ABB2_CELL2 value="<a href=\"client-profile.php?u=$escapedUID\">Update Patron Preferences</a>"}
{include file="allseer-bluebar2.tpl"}
</td></tr>


<tr><td>
<table width="90%" cols=2 cellpadding=2 cellspacing=0 border=0>
<td width="10%">&nbsp;</td>
<td>
<i>Edits on this page will not be saved permanently until you click on the 
<b>Update Preferences</b> button below</i>
</td>
</table>
</td></tr>


<!--  .............................................................  -->
<!--  ...........................Form..............................  -->
<FORM METHOD=POST ACTION="expert-profile.php">


<!--  .............................................................  -->
<!--.....................Communications Table........................-->
<tr><td>
{assign var=ABB1_CELL1 value="Communications"}
{include file="allseer-bluebar1.tpl"}
</td></tr>

<tr><td>
<table width="100%" cols=2 cellpadding=2 cellspacing=0 border=0>
    <tr valign=middle>
    <td class="fld-title" align=right width="30%">Please notify me by email when:&nbsp;</td>
    {assign var=CHSTATE value="CHECKED"}
    {if $ExpertProfile->RateNotifyState != "t"}
    {assign var=CHSTATE value=" "}
    {/if}
    <td align=left>&nbsp;
        <input TYPE=checkbox VALUE="t" NAME=FormRateNotify {$CHSTATE}>
        &nbsp;&nbsp;&nbsp;I'm rated by a Patron&nbsp;
    </td></tr>

    <tr valign=middle >
    <td class="fld-title" align=right width="30%">&nbsp;</td>
    {assign var=CHSTATE value="CHECKED"}
    {if $ExpertProfile->TipNotifyState != "t"}
    {assign var=CHSTATE value=" "}
    {/if}
    <td align=left>&nbsp;
        <input TYPE=checkbox VALUE="t" NAME=FormTipNotify {$CHSTATE}>
        &nbsp;&nbsp;&nbsp;A gift is provided by a Patron&nbsp;
    </td></tr>

    <tr valign=middle>
    <td class="fld-title" align=right width="30%">Select email address for notifications:</td>
    <td align=left>&nbsp;
        <select name=FormEmailSelected>
        {section name=email loop=$ExpertProfile->emailSelectionAry}
        <option value="{$ExpertProfile->emailSelectionAry[email].addy}">{$ExpertProfile->emailSelectionAry[email].addy}</option>
        {/section}
        </select>
    </td></tr>

    <tr valign=middle >
    <td class="fld-title" align=right width="30%">&nbsp;</td>
    <td align=left>&nbsp;
        {assign var=escapedUID value=$ExpertProfile->uid|escape:"url"}
        <a href="email-edit.php?u={$escapedUID}">View, add or delete other email addresses</a>
    </td></tr>
</table>
</td></tr>


<!--  .............................................................  -->
<!--....................Personalization Table........................-->
<tr><td>
{assign var=ABB1_CELL1 value="Create and Manage Your Beneficiary Profiles"}
{include file="allseer-bluebar1.tpl"}
</td></tr>

<!--             personalization error messages here                 -->
{section name=tmsg loop=$ExpertProfile->persMessages}
<tr><td colspan=2>
  <FONT  color="red">
  <b>{$ExpertProfile->persMessages[tmsg]}</b></FONT>
</td></tr>
{if %tmsg.last%}
<tr><td colspan=2>&nbsp;</td></tr>
{/if}
{/section}

<tr><td>
<table width="100%" cols=2 cellpadding=0 cellspacing=0 border=0>
    <tr valign=top>
    <td class="fld-title" align=right width="30%">Click to view active profiles:&nbsp;</td>
    <td align=left>
        {section name=prof loop=$ExpertProfile->ppEditor->activeProfileAry}
          <a href="expert-profile.php?{$ExpertProfile->ppEditor->activeProfileAry[prof].viewArgs}">
            {$ExpertProfile->ppEditor->activeProfileAry[prof].name}</a>
          {if ! %prof.last%},&nbsp;{/if}
        {/section}
    </td></tr>

    <tr valign=top><td colspan=2><font size=-2>&nbsp;</font></td></tr>

    <tr valign=top>
    {assign var=TITLE_COLOR value="black"}
    {if $ExpertProfile->Messages.prfname != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <td class="fld-title" valign=center align=right width="30%"><br>
    <font color={$TITLE_COLOR}>Enter name of new profile:<br><font size=-1>(eg: SF_Culture; FreeSoftware; myEdu; NoDrilling)</font>&nbsp;</font></td>
    <td align=left>
        <table width="80%"  bgcolor="#cccccc" cols=2 cellpadding=0 cellspacing=0 border=0>
            <tr BGColor="#999999">
            <th width="30%" align=left><b>Profile Name</b></th>
            <th align=left><b>Set as default</b></th>
            </tr><tr>
            <td align=left valign=top>
            &nbsp;&nbsp;<INPUT type=TEXT name=FormProfName maxlength=25 size=15 value="{$ExpertProfile->dpyProfile->name}"></td>
            <td align=left>
            <input TYPE=checkbox VALUE="t" NAME=FormSetDefault {$ExpertProfile->FormSetDefault}>
            &nbsp;&nbsp;&nbsp;Yes&nbsp;<br>&nbsp;
            </td>
            </tr>
        </table>
    </td></tr>

    <tr valign=top>
    <td class="fld-title" valign=bottom align=right width="30%">&nbsp;</td>
    <td align=left>
        <table width="80%" bgcolor="#cccccc" cols=2 cellpadding=0 cellspacing=0 border=0>
        <tr BGColor="#999999">
        <th align=left><b>Profile Message</b></th>
        <th align=right>&nbsp</th>
        </tr></table>
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $ExpertProfile->Messages.prfdescr != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=center align=right width="30%">
    <font color={$TITLE_COLOR}>Enter profile message:&nbsp;</font>
    <br><font size=-1>(This message and your beneficiaries will appear on the ratings screen)</font>
    </td>
    <td align=left>
      <table width="80%"  bgcolor="#cccccc" cols=2 cellpadding=0 cellspacing=0 border=0>
      <tr><td align=center colspan=2>
        <TEXTAREA name=FormProfProppa rows=4 cols=50 wrap=soft>{$ExpertProfile->dpyProfile->proppa}</TEXTAREA>
      </td>
      </tr>
      </table>
    </td></tr>

    <tr valign=top>
    <td class="fld-title" valign=bottom align=right width="30%">&nbsp;</td>
    <td align=left>
        <table width="80%" cols=2 bgcolor="#cccccc" cellpadding=0 cellspacing=0 border=0>
        <tr><td align=right>
          <select name=FormProfProppaType>
            {section name=i loop=$ExpertProfile->proppaTpAry}
              {assign var=SELECTED value= " "}
              {if $ExpertProfile->dpyProfile->proppa_tp == $ExpertProfile->proppaTpAry[i]}
                {assign var=SELECTED value= "SELECTED"}
              {/if}
              <option {$SELECTED} value="{$ExpertProfile->proppaTpAry[i]}">{$ExpertProfile->proppaTpAry[i]}</option>
            {/section}
          </select>
        </td><td>&nbsp;&nbsp;
        <a target="new" href="http://{$myServer}/help.php?helpCat=HHonlytag">
        <font SIZE=-1>HTML Help</font></a>&nbsp;</td></tr>
        </table>
    
    <tr valign=top>

    <tr valign=top>
    <td class="fld-title" valign=bottom align=right width="30%">&nbsp;</td>
    <td align=left>
        <table width="80%"  bgcolor="#cccccc" cellpadding=0 cellspacing=0 border=0>
        <tr BGColor="#999999">
        <th align=left width="15%"><b>Share</b></th>
        <th align=left><b>Beneficiaries</b></th>
        </tr></table>
    </td></tr>

    <tr valign=top>
    {assign var=TITLE_COLOR value="black"}
    {if $ExpertProfile->Messages.prfdetails != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <td class="fld-title" valign=top align=right width="30%">
    <font color={$TITLE_COLOR}>Select Beneficiaries:</font>
    <br><font size=-1>(Click on Update Peferences<br>below to save)&nbsp;</font></td>
    <td align=left>
    <table width="80%"  bgcolor="#cccccc" cellpadding=0 cellspacing=0 border=0>

        {section name=ip loop=$ExpertProfile->dpyProfile->array}
            <tr>
            <td align=left width="15%">&nbsp;
                <font size=-1>
                <INPUT type=TEXT name=FormPercent{%ip.index%} maxlength=4 size=4 value="{$ExpertProfile->dpyProfile->array[ip].pc}%">
                </font>
            </td>
            <td align=left>
                <select name=FormFoundation{%ip.index%}>
                    <option value="{$ExpertProfile->dpyProfile->array[ip].found}">{$ExpertProfile->dpyProfile->array[ip].found}</option>
                    {section name=i loop=$ExpertProfile->ppEditor->Foundations}
                      {if $ExpertProfile->ppEditor->Foundations[i].name != $ExpertProfile->dpyProfile->array[ip].found}
                        <option value="{$ExpertProfile->ppEditor->Foundations[i].name}"> {$ExpertProfile->ppEditor->Foundations[i].name} </option>
                      {/if}
                    {/section}
                </select>
            </td></tr>
        {/section}
    </table>
    </td></tr>

    <tr valign=top>
    <td class="fld-title" valign=top align=right width="30%"><font size=-1>(Total must equal 100%)</font>&nbsp;</td>
    <td align=left>
    <table width="80%"  bgcolor="#cccccc" cellpadding=0 cellspacing=0 border=0>
        <tr><td width="1%">&nbsp;</td><td>&nbsp;{$ExpertProfile->dpyProfile->sum}%&nbsp;</td><td width="1%">&nbsp;</td></tr>
    </table></td></tr>

    <tr valign=top>
    <td class="fld-title" valign=bottom align=right width="30%"><font size=-2>&nbsp;</font></td>
    <td align=left>
    <table width="80%"  bgcolor="#cccccc" cellpadding=0 cellspacing=0 border=0>
        <tr><td colspan=2><font size=-2>&nbsp;</font></td></tr>
    </table></td></tr>

    <tr valign=top>
    <td class="fld-title" valign=bottom align=right width="30%">&nbsp;</td>
    <td align=left>
        <table width="80%"  bgcolor="#cccccc" cellpadding=0 cellspacing=0 border=0>
        <tr BGColor="#999999">
        <th align=left width="15%"><b>Profile Signature</b></th>
        </tr></table>
    </td></tr>
    <tr valign=top>
    <td class="fld-title" valign=bottom align=right width="30%">Personalized email signature:&nbsp;<br><font size=-1>(Select text, copy, and paste into your email signature to provide a link to produce this disbursement)</font>&nbsp;</td>
    <td align=left>
    <table width="80%"  cols=3 bgcolor="#cccccc" cellpadding=0 cellspacing=0 border=0>
        <tr><td width="1%">&nbsp;</td><td bgcolor="white">&nbsp;{$ExpertProfile->copyHTML}<br>&nbsp;</td><td width="1%">&nbsp;</td></tr>
    </table></td></tr>

    <tr valign=top>
    <td class="fld-title" valign=bottom align=right width="30%"><font size=-2>&nbsp;</font></td>
    <td align=left>
    <table width="80%"  bgcolor="#cccccc" cellpadding=0 cellspacing=0 border=0>
        <tr><td colspan=2><font size=-2>&nbsp;</font></td></tr>
    </table></td></tr>

    <tr valign=top>
    <td class="fld-title" valign=top align=right width="30%">Click here to view:&nbsp;</td>
    <td align=left>
    <table width="80%"  bgcolor="#cccccc" cellpadding=0 cellspacing=0 border=0>
        <tr><td width="1%">&nbsp;</td><td>&nbsp;{$ExpertProfile->testHTML}<br>&nbsp;</td><td width="1%">&nbsp;</td></tr>
    </table></td></tr>

    <tr valign=top><td colspan=2><font size=-2>&nbsp;</font></td></tr>

    <tr valign=top>
    <td class="fld-title" valign=bottom align=right width="30%">Manage your other existing profiles:</td>
    <td align=left>
    <table width="80%" cellpadding=0 cellspacing=0 border=0>
        {assign var=escapedUID value=$ExpertProfile->uid|escape:"url"}
        <tr><td width="1%">&nbsp;</td><td>&nbsp;<a href="pay-profile-edit.php?u={$escapedUID}">View, activate and deactivate other profiles</a></td><td width="1%">&nbsp;</td></tr>
    </table></td></tr>

    <tr valign=top><td colspan=2><font size=-2>&nbsp;</font></td></tr>

</table>
</td></tr>


<!--  .............................................................  -->
<!--........................Security Table...........................-->

<tr><td>
{assign var=ABB1_CELL1 value="Password Change"}
{include file="allseer-bluebar1.tpl"}
</td></tr>

<!--                 security error messages here                    -->
{section name=tmsg loop=$ExpertProfile->pswdMessages}
<tr><td colspan=2>
  <FONT  color="red">
  <b>{$ExpertProfile->pswdMessages[tmsg]}</b></FONT>
</td></tr>
{if %tmsg.last%}
<tr><td colspan=2>&nbsp;</td></tr>
{/if}
{/section}

{assign var=TITLE_COLOR value="black"}
{if $ExpertProfile->Messages.Password != ""}
{assign var=TITLE_COLOR value="red"}
{/if}
<tr><td>
<table width="100%" cols=2 cellpadding=2 cellspacing=0 border=0>
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>Change Affero Password (enter twice):&nbsp;</font></td>
    <td align=left>
        <table width="100%" cellpadding=0 cellspacing=0 border=0>
        <tr><td width="30%">
        <INPUT type=password name=FormPassword1 maxlength=15 size=12 value="{$ExpertProfile->FormPassword1}">
        </td><td>
        <INPUT type=password name=FormPassword2 maxlength=15 size=12 value="{$ExpertProfile->FormPassword2}">
        </td></tr>
        </table>
    </td></tr>
</table>
</td></tr>


<!--  .............................................................  -->
<!--  ...............    Category Maintenance    ..................  -->
{if $ExpertProfile->listAdminFlag == "yes"}
    <tr><td>
    {assign var=ABB1_CELL1 value="Feedback Categories"}
    {include file="allseer-bluebar1.tpl"}
    </td></tr>

    <tr><td>
    <table width="100%" cols=2 cellpadding=2 cellspacing=0 border=0>
        <tr valign=middle>
        <td class="fld-title" align=right width="30%">Manage Mailing List Feedback Categories:&nbsp;</td>
        <td align=left>&nbsp;
          <a href="list-comps.php?u={$ExpertProfile->uid}">
                Create, activate and deactivate categories </a>    
        </td></tr>

    </table>
    </td></tr>
{/if}


<!--  .............................................................  -->
<!--.....................Account Status Table........................-->
<tr><td>
{assign var=ABB1_CELL1 value="Deactivate Account"}
{include file="allseer-bluebar1.tpl"}
</td></tr>

<tr><td>
<table width="100%" cols=2 cellpadding=2 cellspacing=0 border=0>
    <tr valign=middle>
    <td class="fld-title" align=right width="30%">&nbsp;</td>
    <td align=left>&nbsp;
        <input TYPE=checkbox VALUE="t" NAME=FormDeActivate {$ExpertProfile->FormDeActivate}>
        &nbsp;&nbsp;&nbsp;De-activate my account&nbsp;
    </td></tr>

</table>
</td></tr>


<!--  .............................................................  -->
<!--  .............Form Submission / Hidden Fields.................  -->
<tr><td>
{assign var=ABB1_CELL1 value="Update Preferences"}
{include file="allseer-bluebar1.tpl"}
</td></tr>

<tr><td>
<table width="100%" cols=2 cellpadding=2 cellspacing=0 border=0>
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">Click here to save changes above:&nbsp;</td>
    <td align=left>
    <INPUT TYPE=submit value="Update Preferences"><FONT  size=-1 color="gray"><b>&nbsp;</b></FONT>
    </td></tr>
</table>
</td></tr>

<INPUT TYPE=hidden name=FormValidate value="1">
<INPUT TYPE=hidden name=u value="{$ExpertProfile->uid}">
<INPUT TYPE=hidden name=v value="{$ExpertProfile->v}">
<INPUT TYPE=hidden name=dpyProfileSer value="{$ExpertProfile->dpyProfileSer}">
</FORM>


<!--  .............................................................  -->
<!--  ...........................FAQs..............................  -->
<tr><td colspan=2>
{assign var=ABB2_CELL1 value="FAST FAQs"}
{assign var=ABB2_CELL2 value=#AFFLINX#}
{include file="allseer-bluebar2.tpl"}

</td></tr><tr><td colspan=2 align=center>
    <a target="new" href="http://{$myServer}/help.php?helpCat=EPwhynotify">Why should I be notified?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=EPwhyaddemail">Why should I add email addresses?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=EPwhyprofile">Why should I add disbursement profiles?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=EPwhatpriv">What is Affero's privacy policy?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=EPwhyselect">Why should I select a default disbursement profile?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=EPwhylink">Why should I add a link in my email sig or web page?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=EPhowsource">How do I get the source code?</a>&nbsp;
</td></tr>
</table>

<!--  .............................................................  -->
<!--  ..........................Footer.............................  -->
{include file="footer.tpl"}

