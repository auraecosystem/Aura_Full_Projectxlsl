{include file="header.tpl"}
<!--  $Name: ORG-TEST $, $Id: client-profile.tpl,v 1.28 2002/10/23 22:59:03 leed Exp $-->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{config_load file="Smarty.Affero.conf"}
{assign var=myServer value=$smarty.server.HTTP_HOST}

<!-- //////////////  HTML GENERATION STARTS HERE  ////////////////// -->

<table width="100%" cellpadding=2 cellspacing=0 border=0>
<tr><td>
{assign var=escapedUID value=$ClientProfile->uid|escape:"url"}
{assign var=ABB2_CELL1 value="UPDATE PATRON PREFERENCES: $ClientProfile->BarString"}
{assign var=ABB2_CELL2 value="<a href=\"expert-profile.php?u=$escapedUID\">Update Volunteer Preferences</a>"}
{include file="allseer-bluebar2.tpl"}
</td></tr>

<!--  .............................................................  -->
<!--  ...........................Form..............................  -->
<FORM METHOD=POST ACTION="client-profile.php">

<!--  .............................................................  -->
<!--  ......................Communications.........................  -->
<tr><td>
{assign var=ABB1_CELL1 value="Communications"}
{include file="allseer-bluebar1.tpl"}
</td></tr><tr><td>
<table width="100%" cols=2 cellpadding=2 cellspacing=0 border=0>
    <tr valign=middle>
    <td class="fld-title" align=right width="30%">Please notify me by email when:&nbsp;</td>
    {assign var=CHSTATE value="CHECKED"}
    {if $ClientProfile->RateNotify != "t"}
    {assign var=CHSTATE value=" "}
    {/if}
    <td align=left>&nbsp;
        <input TYPE=checkbox VALUE="t" NAME=FormRateNotify {$CHSTATE}>
        &nbsp;&nbsp;&nbsp;Rated&nbsp;
    </td></tr>

    <tr valign=middle >
    <td class="fld-title" align=right width="30%">&nbsp;</td>
    {assign var=CHSTATE value="CHECKED"}
    {if $ClientProfile->GiftNotify != "t"}
    {assign var=CHSTATE value=" "}
    {/if}
    <td align=left>&nbsp;
        <input TYPE=checkbox VALUE="t" NAME=FormGiftNotify {$CHSTATE}>
        &nbsp;&nbsp;&nbsp;I have contributed a gift&nbsp;
    </td></tr>

    <tr valign=middle>
    <td class="fld-title" align=right width="30%">Select email address for notifications:</td>
    <td align=left>&nbsp;
        <select name=FormEmailSelected>
        {section name=email loop=$ClientProfile->emailSelectionAry}
        <option value="{$ClientProfile->emailSelectionAry[email].addy}">{$ClientProfile->emailSelectionAry[email].addy}</option>
        {/section}
        </select>
    </td></tr>

    <tr valign=middle >
    <td class="fld-title" align=right width="30%">&nbsp;</td>
    <td align=left>&nbsp;
        {assign var=escapedUID value=$ClientProfile->uid|escape:"url"}
        <a href="email-edit.php?u={$escapedUID}">View, add or delete other email addresses</a>
    </td></tr>
</table>
</td></tr>

<!--  .............................................................  -->
<!--  ...................Billing Information.......................  -->
<tr><td>
{assign var=ABB1_CELL1 value="Billing Information for Credit Card Verification"}
{include file="allseer-bluebar1.tpl"}
</td></tr>

<tr><td>
<br><center>Please provide the billing address for the credit card you will be using. Affero
accepts Master Card or Visa.</center><br>
</td></tr>

{section name=j loop=$ClientProfile->billMessages}
<tr><td>
  <FONT  color="red">
  <b>{$ClientProfile->billMessages[j]}</b></FONT>
</td></tr>
{if %j.last%}
<tr><td>&nbsp;</td></tr>
{/if}
{/section}

<tr><td>
<table width="100%" cols=2 cellpadding=2 cellspacing=0 border=0>
    <!--  these should be generated from an array in the             -->
    <!--  $ClientProfile object                                      -->
    {assign var=TITLE_COLOR value="black"}
    {if $ClientProfile->Messages.First != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>First Name:&nbsp;</font></td>
    <td align=left>
    <INPUT type=TEXT name=FormFirst maxlength=25 size=20 value="{$ClientProfile->First}">
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $ClientProfile->Messages.Last != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>Last Name:&nbsp;</font></td>
    <td align=left>
    <INPUT type=TEXT name=FormLast maxlength=25 size=20 value="{$ClientProfile->Last}">
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $ClientProfile->Messages.Phone != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>Phone:&nbsp;</font></td>
    <td align=left>
    <INPUT type=TEXT name=FormPhone maxlength=25 size=20 value="{$ClientProfile->Phone}">
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $ClientProfile->Messages.Company != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>Company:&nbsp;</font></td>
    <td align=left>
    <INPUT type=TEXT name=FormCompany maxlength=25 size=20 value="{$ClientProfile->Company}">
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $ClientProfile->Messages.Address1 != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>Address:&nbsp;</font></td>
    <td align=left>
    <INPUT type=TEXT name=FormAddress1 maxlength=25 size=20 value="{$ClientProfile->Address1}">
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $ClientProfile->Messages.Address2 != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>Address (2nd line):&nbsp;</font></td>
    <td align=left>
    <INPUT type=TEXT name=FormAddress2 maxlength=25 size=20 value="{$ClientProfile->Address2}">
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $ClientProfile->Messages.City != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>City:&nbsp;</font></td>
    <td align=left>
    <INPUT type=TEXT name=FormCity maxlength=25 size=20 value="{$ClientProfile->City}">
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $ClientProfile->Messages.State != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>State:&nbsp;</font></td>
    <td align=left>
        <!--  US States dropdown                       -->
        <select name=FormState>
        <option value="{$ClientProfile->State}"> {$ClientProfile->State} </option>
        {section name=state loop=$US_States}
            {if $ClientProfile->State != $US_States[state].name}
            <option value="{$US_States[state].name}"> {$US_States[state].name} </option>
            {/if}
        {/section}
        </select>
        &nbsp;&nbsp;&nbsp;&nbsp;Select None/Other for non-US billing address
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $ClientProfile->Messages.Zip != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>Zip/Postal Code:&nbsp;</font></td>
    <td align=left>
    <INPUT type=TEXT name=FormZip maxlength=25 size=20 value="{$ClientProfile->Zip}">
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $ClientProfile->Messages.Country != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>Country:&nbsp;</font></td>
    <td align=left>
        <!--  Countries dropdown                       -->
        <select name=FormCountry>
        <option value="{$ClientProfile->Country}"> {$ClientProfile->Country} </option>
        {section name=cntry loop=$Countries}
            {if $ClientProfile->Country != $Countries[cntry].name}
            <option value="{$Countries[cntry].name}"> {$Countries[cntry].name} </option>
            {/if}
        {/section}
        </select>
    </td></tr>

</table>
</td></tr>

<!--  .............................................................  -->
<!--  .........................Payments............................  -->
<tr><td>
{assign var=ABB1_CELL1 value="Payments"}
{include file="allseer-bluebar1.tpl"}
</td></tr><tr><td>
<table width="100%" cols=2 cellpadding=2 cellspacing=0 border=0>
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">Gift History:&nbsp;</td>
    <td align=left>
        {if $ClientProfile->TipHistory == "Public"}
           {assign var=YSTATE value="checked"}
           {assign var=NSTATE value=" "}
        {else}
           {assign var=YSTATE value=" "}
           {assign var=NSTATE value="checked"}
        {/if}
        <table width="100%" cols=2 cellpadding=2 cellspacing=0 border=0>
        <tr>
        <td width="10%" align=left>&nbsp;<input TYPE="radio" VALUE="Public" NAME=FormTipHistory {$YSTATE}> Public<br>
        </td>
        <td align=left>&nbsp;<input TYPE="radio" VALUE="Private" NAME=FormTipHistory {$NSTATE}> Private<br>
        </td>
        </tr>
        </table>
    </td></tr>

    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">Total Amount paid this Month:&nbsp;</td>
    <td align=left>
        <table  width="100%" cols=2 cellpadding=2 cellspacing=0 border=0>
        <tr><td width="10%" align=right>
        ${$ClientProfile->tipsMonth|string_format:"%7.2f"}
        </td><td><br></td>
        </table>
    </td></tr>

    <tr valign=middle>
    <td class="fld-title" valign=middle align=right width="30%">Yearly Total:&nbsp;</td>
    <td align=left>
        <table  width="100%" cols=2 cellpadding=2 cellspacing=0 border=0>
        <tr><td width="10%" align=right>
        ${$ClientProfile->tipsYear|string_format:"%7.2f"}
        </td><td><br></td>
        </table>
    </td></tr>
</table>
</td></tr>
<!--  .............................................................  -->
<!--  .........................Security............................  -->
<tr><td>
{assign var=ABB1_CELL1 value="Password Change"}
{include file="allseer-bluebar1.tpl"}
</td></tr>

<!--                 security error messages here                    -->
{section name=j loop=$ClientProfile->pswdMessages}
<tr><td>
  <FONT  color="red">
  <b>{$ClientProfile->pswdMessages[j]}</b></FONT>
</td></tr>
{if %j.last%}
<tr><td>&nbsp;</td></tr>
{/if}
{/section}

{assign var=TITLE_COLOR value="black"}
{if $ClientProfile->Messages.Password != ""}
{assign var=TITLE_COLOR value="red"}
{/if}
<tr><td>
<table width="100%" cols=2 cellpadding=2 cellspacing=0 border=0>
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>Change Affero Password (enter twice):&nbsp;</font></td>
    <td align=left>
        <table width="100%" cellpadding=0 cellspacing=0 border=0>
        <tr><td width="30%">
        <INPUT type=password name=FormPassword1 maxlength=15 size=12 value="{$ClientProfile->FormPassword1}">
        </td><td>
        <INPUT type=password name=FormPassword2 maxlength=15 size=12 value="{$ClientProfile->FormPassword2}">
        </td></tr>
        </table>
    </td></tr>

</table>
</td></tr>


<!--  .............................................................  -->
<!--  ......................Account Status.........................  -->
<tr><td>
{assign var=ABB1_CELL1 value="Deactivate Account"}
{include file="allseer-bluebar1.tpl"}
</td></tr>

<tr><td>
<table width="100%" cols=2 cellpadding=2 cellspacing=0 border=0>
    <tr valign=middle>
    <td class="fld-title" align=right width="30%">&nbsp;</td>
    <td align=left>&nbsp;
        <input TYPE=checkbox VALUE="t" NAME=FormDeActivate {$ClientProfile->FormDeActivate}>
        &nbsp;&nbsp;&nbsp;De-activate my account&nbsp;
    </td></tr>
</table>
</td></tr>

<!--  .............................................................  -->
<!--  .............Form Submission / Hidden Fields.................  -->
<tr><td>
{assign var=ABB1_CELL1 value="Update Preferences"}
{include file="allseer-bluebar1.tpl"}
</td></tr>

<tr><td>
<table width="100%" cols=2 cellpadding=2 cellspacing=0 border=0>
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">Click here to save changes above:&nbsp;</td>
    <td align=left>
     <INPUT TYPE=submit value="Update Preferences"><FONT  size=-1 color="gray"><b>&nbsp;</b></FONT>
    </td></tr>
</table>
</td></tr>

<INPUT TYPE=hidden name=FormValidate value="1">
<INPUT TYPE=hidden name=u value="{$ClientProfile->uid}">
</FORM>

<!--  .............................................................  -->
<!--  ...........................FAQs..............................  -->
<tr><td colspan=2>
{assign var=ABB2_CELL1 value="FAST FAQs"}
{assign var=ABB2_CELL2 value=#AFFLINX#}
{include file="allseer-bluebar2.tpl"}

</td></tr><tr><td colspan=2 align=center>
    <a target="new" href="http://{$myServer}/help.php?helpCat=CPwhynotify">Why should I be notified?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=CPwhyaddemail">Why should I add email addresses?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=CPwhyprovidebill">Why should I provide billing information?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=CPwhatpriv">What is  Affero's privacy policy?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=CPwhycredit">Why do I need to provide credit card information each time I provide a gift?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=CPhowprivate">How can I keep my gifts private?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=CPhowsource">How do I get the source code?</a>&nbsp;
</td></tr>
</table>

<!--  .............................................................  -->
<!--  ..........................Footer.............................  -->
{include file="footer.tpl"}

