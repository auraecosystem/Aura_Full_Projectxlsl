{include file="header.tpl"}
<!--  $Name: ORG-TEST $, $Id: notice.tpl,v 1.4 2002/09/02 21:33:03 leed Exp $  -->
<!-- -/////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{config_load file="Smarty.Affero.conf"}
{assign var=myServer value=$smarty.server.HTTP_HOST}

 <table border="0" cellpadding="2" cellspacing="0" width="100%">
   <tbody>
   <tr>
     <td bgcolor="#999999"><font color="#000000"><strong>THANK YOU!</strong>
      </font></td>
    </tr>
   <tr>
     <td>
        <blockquote><br>
        <center>
        <p>{$Code}</p>
        <p>Use your browser back button to return, or click 
        <a href="http://{$myServer}">here</a> to visit Affero's home page.<br>
        </p>
        </center>
        </blockquote>
      </td>
   </tr>
   </tbody>
</table>
<br>
{assign var=ABB2_CELL2 value=#AFFLINX#}
{include file="allseer-bluebar2.tpl"}
{include file="footer.tpl"}
