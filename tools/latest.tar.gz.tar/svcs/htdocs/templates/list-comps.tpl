{include file="header.tpl"}
<!--  $Name: ORG-TEST $, $Id: list-comps.tpl,v 1.6 2002/09/02 21:32:50 leed Exp $ -->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{config_load file="Smarty.Affero.conf"}
{assign var=myServer value=$smarty.server.HTTP_HOST}

<!-- //////////////  HTML GENERATION STARTS HERE  ////////////////// -->

<table width="100%" cellpadding=0 cellspacing=0 border=0>
<tr><td>
{assign var=escapedUID value=$lComps->Login|escape:"url"}
{assign var=ABB2_CELL1 value="CREATE, ACTVATE AND DEACTVATE CATEGORIES: $lComps->Login"}
{assign var=ABB2_CELL2 value="<a href=\"expert-profile.php?u=$escapedUID\">Volunteer Profile</a>"}
{include file="allseer-bluebar2.tpl"}
</td></tr>


<FORM METHOD=POST ACTION="list-comps.php">
<!-- ////////////////////////////////////////////////////////////// -->
<tr><td><font size=-2>&nbsp;</font></td></tr>
<tr><td><font size=-2>&nbsp;</font></td></tr>
<tr><td><font size=-2>&nbsp;</font></td></tr>

<tr><td>
<table width="100%" cols=2 cellpadding=0 cellspacing=0 border=0>
    <!--  .............................................................  -->
    <!--  ...................List Dropdown.............................  -->
    <tr valign=middle>
    <td class="fld-title"  valign=center align=right width="30%">Select a mailing list:&nbsp;</td>
    <td align=left>
        <select name=FormSelectedList>
        <option value="{$lComps->SelectedLIst}">{$lComps->SelectedList}</option>
        {section name=list loop=$lComps->Lists}
          {if $lComps->SelectedList != $lComps->Lists[list].mlist_name}
            <option value="{$lComps->Lists[list].mlist_name}">{$lComps->Lists[list].mlist_name}</option>
          {/if}
        {/section}
        </select>
        &nbsp;&nbsp;&nbsp;Click <b>Update Preferences</b> button below to load list details
    </td></tr>
    <tr><td colspan=2>&nbsp;</td></tr>

    <tr valign=top>
    <td class="fld-title" valign=center align=right width="30%">
    <font color={$TITLE_COLOR}><br>Activate Deactivate Categories:&nbsp;</font></td>
    <td align=left>
        <table width="80%"  bgcolor="#cccccc" cols=5 cellpadding=0 cellspacing=0 border=0>
        <tr bgcolor="#999999">
            <th width="1%"> &nbsp </th>
            <th width="20%" align=left> Category</th>
            <th width="1%"> &nbsp </th>
            <th width="5%" align=center> Active</th>
            <th width="1%"> &nbsp </th>
        </tr>
        {assign var=LID value=$lComps->SelectedListId}
        {section name=i loop=$lComps->Competencies}
            <tr>
              <td width="1%">&nbsp;</td>
              <td width="20%" align=left>{$lComps->Competencies[i].cmptcy_descr}</td>
              <td width="1%">&nbsp;</td>
              <td  width="5%" align=left>
                {if $lComps->Competencies[i].screen_active == "t"}
                   {assign var=YSTATE value="checked"}
                   {assign var=NSTATE value=" "}
                {else}
                   {assign var=YSTATE value=" "}
                   {assign var=NSTATE value="checked"}
                {/if}
                <table width="100%" cellpadding=0 cols=2 cellspacing=0 border=0>
                  <tr>
                    <td align=right>&nbsp;
                      <input TYPE="radio" VALUE="Yes" NAME=FormScrAct.{$LID}.{%i.index%} {$YSTATE}> Y<br></td>
                    <td align=right>&nbsp;
                      <input TYPE="radio" VALUE="No"  NAME=FormScrAct.{$LID}.{%i.index%} {$NSTATE}> N<br></td>
                  </tr>
                </table>
              </td>
              <td width="1%">&nbsp;</td>
            </tr>
        {/section}
        </table>
    </td></tr>

    <!--  .............................................................  -->
    <!--  ...................New Category..............................  -->
    {section name=tmsg loop=$lComps->Messages.NewCat}
    <tr valign=top>
    <td align=leftcolspan=2><FONT  color="red">
    <b>{$lComps->Messages.NewCat[tmsg]}</b></FONT>
    </td></tr>
    {/section}


    <tr valign=top>
    <td class="fld-title" valign=center align=right width="30%">
    <font color={$TITLE_COLOR}><br>Enter a list of categories separated by&nbsp;<br>commas or newlines:&nbsp;</font></td>
    <td align=left>
      <table width="80%" bgcolor="#cccccc" cols=3 cellpadding=0 cellspacing=0 border=0>
        <tr bgcolor="#999999">
            <th width="3%"> &nbsp </th>
            <th colspan=2 align=left>Categories</th>
        </tr>

        <tr>
        <td align=left>&nbsp;</td>
        <td><center>
          <table width="60%" cellpadding=0 cellspacing=0 border=0>
            <tr>
            <td align=middle>
            <TEXTAREA name=FormNewCat rows=4 cols=40 wrap=soft>{$lComps->NewCat}</TEXTAREA>
            <FONT  size=-1 color="gray"><b>&nbsp;</b></FONT>
            </td></tr>
          </table>
        </center></td>
        <td align=left>&nbsp;</td>
        </tr>

      </table>
      </td></tr>

    <tr><td colspan=2>&nbsp;</td></tr>

    <!--  .............................................................  -->
    <!--  .......................Form Submit...........................  -->
    <tr valign=middle>
      <td valign=center align=right width="30%">Click here to save changes above:&nbsp;</td>
      <td align=left>
      <INPUT TYPE=submit value="Update Preferences">
      <FONT face="Arial,Helvetica" size=-1 color="gray">&nbsp;</FONT>
      </td>
    </tr>

    <!--  .............................................................  -->
    <!--  ...................Hidden Fields.............................  -->
    <INPUT TYPE=hidden name=FormValidate value="1">
    <INPUT TYPE=hidden name=u value="{$lComps->Login}">
  </table>
</td></tr>

</FORM>
<!--  .......................End of Form...........................  -->
<tr><td><font size=-2>&nbsp;</font></td></tr>
<tr><td><font size=-2>&nbsp;</font></td></tr>
<tr><td><font size=-2>&nbsp;</font></td></tr>

<tr><td colspan=2>
{assign var=ABB2_CELL1 value="FAST FAQs"}
{assign var=ABB2_CELL2 value=#AFFLINX#}
{include file="allseer-bluebar2.tpl"}

</td></tr><tr><td align=center>
    <a target="new" href="http://{$myServer}/help.php?helpCat=EEhowsource">How do I get the source code?</a>&nbsp;
</td></tr></td></tr>
</table>
<!--  ..........................Footer.............................  -->

{include file="footer.tpl"}
