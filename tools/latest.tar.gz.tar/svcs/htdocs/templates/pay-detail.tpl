{include file="header.tpl"}
<!--  $Name: ORG-TEST $, $Id: pay-detail.tpl,v 1.26 2002/10/24 00:04:05 leed Exp $ -->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{config_load file="Smarty.Affero.conf"}
{assign var=myServer value=$smarty.server.HTTP_HOST}

<!-- //////////////  HTML GENERATION STARTS HERE  ////////////////// -->

<table width="100%" cellpadding=2 cellspacing=0 border=0>
<tr><td>

<FORM METHOD=POST ACTION="payment-details.php">
<tr><td>
{assign var=ABB1_CELL1 value="Billing Information"}
{include file="allseer-bluebar1.tpl"}
</td></tr>

<tr><td>
<br><center><i>Please provide the billing address for the credit card you will be using. Affero
accepts Master Card or Visa.</i></center><br>
</td></tr>

<tr><td>
<center>Asterisks (<font color=red>*</font>) denote required fields</center>
</td></tr>

{section name=j loop=$PayDetail->billMessages}
<tr><td>
  <FONT  color="red">
  <b>{$PayDetail->billMessages[j]}</b></FONT>
</td></tr>
{if %j.last%}
<tr><td>&nbsp;</td></tr>
{/if}
{/section}

<tr><td>
<table width="100%" cols=2 cellpadding=2 cellspacing=0 border=0>
    {assign var=TITLE_COLOR value="black"}
    {if $PayDetail->Messages.First != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>First Name:&nbsp;<font color=red>*</font></font></td>
    <td align=left>
    <INPUT type=TEXT name=FormFirst maxlength=25 size=20 value="{$PayDetail->First}">
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $PayDetail->Messages.Last != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>Last Name:&nbsp;<font color=red>*</font></font></td>
    <td align=left>
    <INPUT type=TEXT name=FormLast maxlength=25 size=20 value="{$PayDetail->Last}">
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $PayDetail->Messages.Phone != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>Phone:&nbsp;<font color=red>*</font></font></td>
    <td align=left>
    <INPUT type=TEXT name=FormPhone maxlength=25 size=20 value="{$PayDetail->Phone}">
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $PayDetail->Messages.Company != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>Company:&nbsp;&nbsp</font></td>
    <td align=left>
    <INPUT type=TEXT name=FormCompany maxlength=25 size=20 value="{$PayDetail->Company}">
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $PayDetail->Messages.Address1 != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>Address:&nbsp;<font color=red>*</font></font></td>
    <td align=left>
    <INPUT type=TEXT name=FormAddress1 maxlength=25 size=20 value="{$PayDetail->Address1}">
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $PayDetail->Messages.Address2 != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>Address (2nd line):&nbsp;</font></td>
    <td align=left>
    <INPUT type=TEXT name=FormAddress2 maxlength=25 size=20 value="{$PayDetail->Address2}">
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $PayDetail->Messages.City != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>City:&nbsp;<font color=red>*</font></font></td>
    <td align=left>
    <INPUT type=TEXT name=FormCity maxlength=25 size=20 value="{$PayDetail->City}">
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $PayDetail->Messages.State != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>State:&nbsp;<font color=red>*</font></font></td>
    <td align=left>
        <!--  US States dropdown                       -->
        <select name=FormState>
        <option value="{$PayDetail->State}"> {$PayDetail->State} </option>
        {section name=state loop=$US_States}
            {if $PayDetail->State != $US_States[state].name}
            <option value="{$US_States[state].name}"> {$US_States[state].name} </option>
            {/if}
        {/section}
        </select>
        &nbsp;&nbsp;&nbsp;&nbsp;Select None/Other for non-US billing address
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $PayDetail->Messages.Zip != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>Zip / Postal Code:&nbsp;<font color=red>*</font></font></td>
    <td align=left>
    <INPUT type=TEXT name=FormZip maxlength=25 size=20 value="{$PayDetail->Zip}">
    </td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $PayDetail->Messages.Country != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign=top>
    <td class="fld-title" valign=middle align=right width="30%">
    <font color={$TITLE_COLOR}>Country:&nbsp;<font color=red>*</font></font></td>
    <td align=left>
        <!--  Countries dropdown                       -->
        <select name=FormCountry>
        <option value="{$PayDetail->Country}"> {$PayDetail->Country} </option>
        {section name=cntry loop=$Countries}
            {if $PayDetail->Country != $Countries[cntry].name}
            <option value="{$Countries[cntry].name}"> {$Countries[cntry].name} </option>
            {/if}
        {/section}
        </select>
    </td></tr>
    <tr valign=top><td colspan="2">&nbsp;</td></tr>

    {if $PayDetail->displayTOS == 1}
        {assign var=TITLE_COLOR value="black"}
        <tr valign=top>
        <td class="fld-title" valign="middle" align=right width="30%">
        <font color="{$TITLE_COLOR}">&nbsp;<font color="red">*</font></font></td>

        <td align=left>
            <font color="{$TITLE_COLOR}">I accept Affero's</font>
            <a target="new" href= "http://www.affero.com/ctos.html">Terms of Service</a>&nbsp;
            <input type= "checkbox" value="CHECKED" name="FormTOS">
        </td> 
        </tr>
        <tr valign=top><td colspan="2">&nbsp;</td></tr>
    {/if}
</table>
</td></tr>


<!--  .............................................................  -->
<!--  .............Form Submission / Hidden Fields.................  -->
<tr valign=middle>
<td align=center>
<INPUT TYPE=submit value="Proceed to Final Step">
<FONT  size=-1 color="gray"><b>&nbsp;</b></FONT>
</td></tr>

<INPUT TYPE=hidden name=FormValidate value="1">
<INPUT TYPE=hidden name=re value="{$PayDetail->re}"> 
<INPUT TYPE=hidden name=cl value="{$PayDetail->cl}"> 
<INPUT TYPE=hidden name=pid value="{$PayDetail->pid}"> 
<INPUT TYPE=hidden name=tip value="{$PayDetail->Tip}"> 
<INPUT TYPE=hidden name=ish value="{$PayDetail->ish}"> 
<INPUT TYPE=hidden name=tip_oid value="{$PayDetail->TipOID}"> 
</FORM>

<!--  .............................................................  -->
<!--  ...........................FAQs..............................  -->
<tr><td colspan=2>
{assign var=ABB2_CELL1 value="FAST FAQs"}
{assign var=ABB2_CELL2 value=#AFFLINX#}
{include file="allseer-bluebar2.tpl"}

</td></tr><tr><td colspan=2 align=center>
    <a target="new" href="http://{$myServer}/help.php?helpCat=PDwhyprovidebill">Why should I provide billing information?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=PDwhatpriv">What is  Affero's privacy policy?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=PDwhycredit">Why do I need to provide credit card information each time I provide a gift?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=PDhowprivate">How do I keep my gifts private?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=PDhowsource">How do I get the source code?</a>&nbsp;
</td></tr>
</table>
{include file="footer.tpl"}




