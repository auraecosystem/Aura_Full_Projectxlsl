{include file="header.tpl" AHD_TITLE="$UserHistory->browserTitleString"}
<!--  $Name: ORG-TEST $, $Id: user-history.tpl,v 1.5 2002/12/09 18:06:31 leed Exp $-->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{config_load file="Smarty.Affero.conf" section="user-history"}
{assign var=myServer value=$smarty.server.HTTP_HOST}

<!-- //////////////  HTML GENERATION STARTS HERE  ////////////////// -->
<table width="100%" cellpadding=1 cellspacing=0 border=0>
<tr><td>
    {assign var=ABB1_CELL1 value="&nbsp;AFFERO PROFILE: $UserHistory->summaryBarString"}
    {include file="allseer-bluebar1.tpl"}
</td></tr>

<tr><td>
<table width="100%" cols=2 cellpadding=2 cellspacing=0 border=0>
<tr><td valign=top width="60%">
    <table cols=5 bgcolor="#cccccc" width="100%" cellpadding=0 cellspacing=0 border=0>
    <tr bgcolor="#999999"><th colspan=5 align=left>&nbsp;<b>Reputation Summary</b></th></tr>
    <tr bgcolor="#999999">
        <th colspan=2 align=left>&nbsp;<b>Status</b></th>
        <th colspan=3 align=left><b>Details</b></th>
    </tr>

    {assign var=SPACER value="&nbsp;"}
    {section name=i loop=$UserHistory->dpyReputationAry}
        {if %i.index% <= 1}
            {assign var=RPI value=#repSummaryTablPatron#}
        {elseif %i.index% <= 3}
            {assign var=RPI value=#repSummaryTablVolunteer#}
        {else}
            {assign var=RPI value=#xparentPixel#}
            {assign var=SPACER value=""}
        {/if}

        <tr>
        <td width="5%"> <font size= -1>{$UserHistory->dpyReputationAry[i].0}</font></td>
        <td width="20%"> <font size= -1>{$UserHistory->dpyReputationAry[i].1}</font></td>
        <td align=right width="5%"> <font size= -1>{$UserHistory->dpyReputationAry[i].2}</font></td>
        <td width="10"> &nbsp;</td>
        <td>
        <img SRC={$RPI} alt= "" BORDER=0 usemap="#m">{$SPACER}
        <font size= -1>{$UserHistory->dpyReputationAry[i].3}</font></td>
        </tr>
    {/section}
    </table>

</td><td valign=top width="40%">
    <table width="100%" bgcolor="#cccccc" cellpadding=0 cellspacing=0 border=0>
    <tr bgcolor="#999999"><th align=left>&nbsp;<b>{$UserHistory->user}'s Personal Web Pages</b></th></tr>
    <tr><td>
    {section name=i loop=$UserHistory->dpyGiftOptionsAry}
      &nbsp;{$UserHistory->dpyGiftOptionsAry[i]}
      {if ! %i.last%}, {/if}
    {/section}
    </td></tr>
    </table>

</td>
</table>
</td></tr>

<tr><td>
    <table width="100%" cellpadding=0 cellspacing=0 border=0>
    <tr BGColor="#999999">
    <td width="100%" align=left>&nbsp;{$UserHistory->filterBar}</td>
    </tr>
    </table>
</td></tr>

<!-- comment made about user  -->
<tr><td>
{assign var=BI value=#reviewBarVolunteer#}
{assign var=rBarImage value="<img SRC=$BI alt= \"\" BORDER=0 usemap=\"#m\">"}
{if $UserHistory->commentCount > 0}
    {assign var=ABB1_CELL1 value="Reviews on: $rBarImage &nbsp;&nbsp;$UserHistory->user &nbsp;&nbsp;$UserHistory->commentsBarCount"}
{else}
    {assign var=ABB1_CELL1 value="No Reviews on: $rBarImage &nbsp;&nbsp;$UserHistory->user"}
{/if}
{include file="allseer-bluebar1.tpl"}
</td></tr>

{if $UserHistory->commentCount > 0}
<tr><td>
    <table width="100%" bgcolor="#999999" cellpadding=0 cellspacing=0 border=0>
    <tr bgcolor="#999999"><td>
            {$UserHistory->dpyCommentsTitle}
    </td></tr>
    {assign var=BG_COLOR value=#COMMENT_BAR1#}
    {section name=i loop=$UserHistory->dpyCommentsAry}

        {if %i.index% >= $UserHistory->firstDpyComment && %i.index% < $UserHistory->lastDpyComment}
            {assign var=BI value=#tableCommentVolunteer#}
            {if $UserHistory->dpyCommentsAry[i].image == "patron"}
                {assign var=BI value=#tableCommentPatron#}
            {/if}
            {assign var=entImage value="<img SRC=$BI alt= \"\" BORDER=0 usemap=\"#m\">"}

            <tr bgcolor={$BG_COLOR}><td>
                {$UserHistory->dpyCommentsAry[i].name}&nbsp;
                {$entImage}&nbsp;
                {$UserHistory->dpyCommentsAry[i].rest}
            </td></tr>
            {if $BG_COLOR == #COMMENT_BAR1#}
                {assign var=BG_COLOR value=#COMMENT_BAR2#}
            {else}
                {assign var=BG_COLOR value=#COMMENT_BAR1#}
            {/if}
        {/if}
    {/section}
    <tr><td>{$UserHistory->endOfComments}</td></tr>
    </table>

</td></tr>
{/if}

<!-- comment made by user  -->
<tr><td>
{assign var=BI value=#reviewBarPatron#}
{assign var=rBarImage value="<img SRC=$BI alt= \"\" BORDER=0 usemap=\"#m\">"}
{if $UserHistory->commentMadeCount > 0}
    {assign var=ABB1_CELL1 value="Reviews by: $rBarImage &nbsp;&nbsp;$UserHistory->user &nbsp;&nbsp;$UserHistory->commentsMadeBarCount"}
{else}
    {assign var=ABB1_CELL1 value="No Reviews by: $rBarImage &nbsp;&nbsp;$UserHistory->user"}
{/if}
{include file="allseer-bluebar1.tpl"}
</td></tr>

{if $UserHistory->commentMadeCount > 0}
<tr><td>
    <table width="100%" bgcolor="#999999" cellpadding=0 cellspacing=0 border=0>
    <tr bgcolor="#999999"><td>
            {$UserHistory->dpyMadeCommentsTitle}
    </td></tr>
    {assign var=BG_COLOR value=#COMMENT_BAR1#}
    {section name=i loop=$UserHistory->dpyMadeCommentsAry}

        {if %i.index% >= $UserHistory->firstMadeDpyComment && %i.index% < $UserHistory->lastMadeDpyComment}
            {assign var=BI value=#tableCommentVolunteer#}
            {if $UserHistory->dpyMadeCommentsAry[i].image == "patron"}
                {assign var=BI value=#tableCommentPatron#}
            {/if}

            {assign var=entImage value="<img SRC=$BI alt= \"\" BORDER=0 usemap=\"#m\">"}
            <tr bgcolor={$BG_COLOR}><td>
                {$UserHistory->dpyMadeCommentsAry[i].name}&nbsp;
                {$entImage}&nbsp;
                {$UserHistory->dpyMadeCommentsAry[i].rest}
            </td></tr>
            {if $BG_COLOR == #COMMENT_BAR1#}
                {assign var=BG_COLOR value=#COMMENT_BAR2#}
            {else}
                {assign var=BG_COLOR value=#COMMENT_BAR1#}
            {/if}
        {/if}
    {/section}
    <tr><td>{$UserHistory->endOfMadeComments}</td></tr>
    </table>

</td></tr>
{/if}

<!--  .............................................................  -->
<!--  ...........................FAQs..............................  -->
<tr><td>
{assign var=ABB2_CELL1 value="FAST FAQs"}
{assign var=ABB2_CELL2 value=#AFFLINX#}
{include file="allseer-bluebar2.tpl"}

</td></tr><tr><td align=center>
    <a target="new" href="http://{$myServer}/help.php?helpCat=UHrepsum">What is the Reputation Summary?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=UHletters">What do the letters and numbers after the Affero Profile mean?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=UHstatus">How is the status calculated?</a>&nbsp;
</td></tr><tr><td align=center>
    <a target="new" href="http://{$myServer}/help.php?helpCat=UHprivpol">What is Affero's privacy policy?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=UHwho">Who is Affero?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=UHhow">How do I get the source code?</a>&nbsp;
</td></tr>
</table>

{include file="footer.tpl"}

