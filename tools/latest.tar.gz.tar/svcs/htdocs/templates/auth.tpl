{include file="header.tpl"}
<!--  $Name: ORG-TEST $, $Id: auth.tpl,v 1.6 2002/09/02 21:31:47 leed Exp $-->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{assign var=myServer value=$smarty.server.HTTP_HOST}

<!-- //////////////  HTML GENERATION STARTS HERE  ////////////////// -->

<FORM METHOD=POST ACTION="activate.php">
<table width="100%" cellpadding=3 cellspacing=0 border=0>
<tr> <td colspan=3>
{assign var=ABB1_CELL1 value="AUTHORIZATION for: $NewUser->BarString"}
{include file="allseer-bluebar1.tpl"}
</td></tr>

<tr valign=middle>
<td width="20%" align=right class="fld-title">Enter your id number:</td>
<td width="1%"><font color=red size=2>&nbsp</font></td>
<td>
<INPUT type=TEXT name=regFormIdent maxlength=4 size=4>
<FONT  size=-1 color="red"><b>&nbsp; {$NewUser->Messages.Ident}</b></FONT>
</td></tr>


<tr valign=middle>
<td align=center colspan=3>&nbsp;
<INPUT TYPE=submit value="Submit">
<FONT  size=-1 color="gray"><b>&nbsp;</b></FONT>
</td></tr>
</table>

<!--  ..............  H I D D E N    F I E L D S  .................  -->
<INPUT TYPE=hidden name=regFormValidate value="1">
<INPUT TYPE=hidden name=m value={$NewUser->Email}>
</FORM>


{include file="footer.tpl"}

