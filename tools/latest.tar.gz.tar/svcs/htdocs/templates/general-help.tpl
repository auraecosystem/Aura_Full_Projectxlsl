<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--  $Name: ORG-TEST $, $Id: general-help.tpl,v 1.12 2002/09/02 21:32:30 leed Exp $-->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// //>
*{assign var=myServer value=$smarty.server.HTTP_HOST}
<HTML>
<HEAD>
<meta http/equiv="Content/Type" content="text/html; charset=iso/8859/1">
<META name="DESCRIPTION" content="Affero FAQs"> 
<META name="KEYWORDS" content="affero, help, volunteer, patron, rate, donate, donation">
<TITLE>AFFERO HELP AND HOW/TO'S
</TITLE>
</HEAD>
<BODY BGCOLOR="#FFFFFF" TEXT="000000" LINK="#0000FF" VLINK="#800080" ALINK="#FF0000">
<A NAME="helptop"></A>
<table width="100%" cellpadding=0 cellspacing=0 border=0>
<tr><td align=left colspan=4> &nbsp;</td></tr>
<tr><td colspan=4>
<tr BGColor="#999999">
<td width="103%" align=left>&nbsp;<b>GENERAL FAQs</b></td>
</tr>
<tr><td colspan=4>&nbsp;</td></tr>
</table>
<center>
<form method="get" action="help.php">
<div align="center">
OTHER FAQ'S:
<select name="helpFormSel">
<option value="GNL">General FAQs</option>
<option value="GNLwhoallseer">//Who is Affero?</option>
<option value="GNLcost">//Does it cost anything to join?</option>
<option value="GNLwhatmail">//How do I get additional support?</option>
<option value="GNLwhatbenef">//What are beneficiaries?</option>
<option value="GNLmla">//I am a mailing list administrator. How can I offer this service to my subscribers?</option>
<option value="GNLnpo">//I am a Non Profit Organization.  How can I enable donations to my organization?</option>
<option value="GNLhowedit">//How do I edit my member preferences?</option>
<option value="GNLforgotpass">//I forgot my username and/or password, what do I do?</option>
<option value="JS">Join FAQ's</option>
<option value="JSprivpol">//What is Affero's privacy policy?</option>
<option value="JSinfo">//What information is required?</option>
<option value="JSwho">//Who is Affero?</option>
<option value="JShow">//How do I get the source code?</option>
<option value="LG">Login FAQ's</option>
<option value="LGprivpol">//What is Affero's privacy policy?</option>
<option value="LGinfo">//What information is required?</option>
<option value="LGwho">//Who is Affero?</option>
<option value="LGhow">//How do I get the source code?</option>
<option value="RM">Rate Volunteer Fast FAQs</option>
<option value="RMfeedback">//Why provide ratings and comments?</option>
<option value="RMwhydonate">//Why donate?</option>
<option value="RMwhodonate">//Who can donate?</option>
<option value="RMprivacy">//What is Affero's privacy policy?</option>
<option value="RMwhatinfo">//What information is required?</option>
<option value="RMwhosallseer">//Who is Affero?</option>
<option value="RMwhoscharities">//Who chose the charities?</option>
<option value="RMhowgetsrc">//How do I get the source code?</option>
<option value="EP">Update Volunteer Preferences Fast FAQs</option>
<option value="EPwhynotify">//Why should I be notified?</option>
<option value="EPwhyaddemail">//Why should I add email addresses</option>
<option value="EPwhyprofile">//Why should I add disbursement profiles?</option>
<option value="EPwhatpriv">//What is Affero's privacy policy?</option>
<option value="EPwhyselect">//Why should I select a default disbursement profile?</option>
<option value="EPwhylink">//Why should I add a link in my email sig or web page?</option>
<option value="EPhowcancel">//What if I no longer want to be a Volunteer?</option>
<option value="EPhowsource">//How do I get the source code?</option>
<option value="EE">Volunteer Email Edit Fast FAQs</option>
<option value="EEwhyactivate">//Why do I need to activate each address?</option>
<option value="EEwhyremove">//Why should I remove an address?</option>
<option value="EEwhyadd">//Why should I add other email addresses?</option>
<option value="EEhowsource">//How do I get the source code?</option>
<option value="ACT">Activate Account Fast FAQs</option>
<option value="ACTemail">//Why did I receive an email from Affero?</option>
<option value="ACTregister">//Why register?</option>
<option value="ACTinfo">//What information is required?</option>
<option value="ACTwho">//Who is Affero?</option>
<option value="ACTprivPol">//What is Affero's privacy policy?</option>
<option value="ACThow">//How do I get the source code?</option>
<option value="CP">Update Patron Profile Fast FAQs</option>
<option value="CPwhynotify">//Why should I be notified?</option>
<option value="CPwhyaddemail">//Why should I add email addresses?</option>
<option value="CPwhyprovidebill">//Why should I provide billing information?</option>
<option value="CPwhatpriv">//What is Affero's privacy policy?</option>
<option value="CPwhycredit">//Why do I need to provide credit card information each time I provide a gift?</option>
<option value="CPhowprivate">//How do I keep my gifts private?</option>
<option value="CPhowsource">//How do I get the source code?</option>
<option value="RC">Rate Patron Fast FAQs</option>
<option value="RCwhyfeedbk">//Why provide ratings and comments?</option>
<option value="RCwhatpriv">//What is Affero's privacy policy?</option>
<option value="RChowsource">//How do I get the source code?</option>
<option value="PE">Update Pay Profile Fast FAQs</option>
<option value="PEwhynotactive">//Why should a profile be set not active?</option>
<option value="PEhownewbenes">//How can I suggest new beneficiaries not on the list?</option>
<option value="PExhowsource">//How do I get the source code?</option>
</select>
<input type="submit" value="GO!">
</div>
</form>
<FONT  size=/1 color="gray"><b>&nbsp;</b></FONT>
</CENTER>
<BR>
<P>
<A HREF="#GNLwhoallseer">Q: Who is Affero?</A><BR>
<A HREF="#GNLcost">Q: Does it cost anything to join?</A><BR>
<A HREF="#GNLwhatmail">Q: How do I get additional support?</A><BR>
<A HREF="#GNLwhatbenef">Q: What are beneficiaries?</A><BR>
<A HREF="#GNLmla">Q: I am a Mailing List Administrator; how can I offer service to my subscribers?</A><BR>
<A HREF="#GNLnpo">Q: I am a Non/Profit Organization; how can I enable donations to my organization?</A><BR>
<A HREF="#GNLhowedit">Q: How do I edit my member preferences?</A><BR>
<A HREF="#GNLforgotpass">Q: I forgot my username and/or password, what do I do?</A><BR>
</P>
<BR>
        <table border="0" cellspacing="0" cellpadding="2" width="100%">
<tr><td bgcolor="#999999">
   <strong>Answers</strong>
 </td></tr>
</table>
  <blockquote>
<table border="0" cellspacing="0" cellpadding="2" width="96.7%">
 <tr><td bgcolor="#999999">
   <a name="GNLwhoallseer"><strong>Who is Affero?</strong></a>
 </td></tr>
 <tr><td>
  <blockquote>
<p>Affero enables recognition of valuable online interactions.  We provide the means to offer feedback and say "thank you" for support and information provided via ratings and monetary donations to non/profit organizations without disrupting the natural dialogue in the community.<BR><a href="#helptop">Click here to return to top</a><BR></p>
   </blockquote>
 </td></tr>
</table>
<table border="0" cellspacing="0" cellpadding="2" width="96.7%">
 <tr><td bgcolor="#999999">
    <a name="GNLcost"><strong>Does it cost anything to join?</strong></a>
 </td></tr>
 <tr><td>
  <blockquote>
<p>No.<BR><a href="#helptop">Click here to return to top</a><BR></p>
   </blockquote>
 </td></tr>
</table>
<table border="0" cellspacing="0" cellpadding="2" width="96.7%">
 <tr><td bgcolor="#999999">
   <a name="GNLwhatmail"><strong>How do I get additional support?</strong></a>
 </td></tr>
 <tr><td>
  <blockquote>
<p>If you are unable to find your answers in the FAQ's, join the affero/members mailing list <a href="http://lists.affero.net/mailman/listinfo/affero/members">here</a> or visit our help area <a href="http://www.affero.com/ch.html">here</a><BR><a href="#helptop">Click here to return to top</a><BR></p>
   </blockquote>
 </td></tr>
</table>
<table border="0" cellspacing="0" cellpadding="2" width="96.7%">
 <tr><td bgcolor="#999999">
   <a name="GNLwhatbenef"><strong>What are beneficiaries?</strong></a>
 </td></tr>
 <tr><td>
  <blockquote>
<p>Beneficiaries may be registered non/profit entities.<BR><a href="#helptop">Click here to return to top</a><BR></p>
   </blockquote>
 </td></tr>
</table>
<table border="0" cellspacing="0" cellpadding="2" width="96.7%">
 <tr><td bgcolor="#999999">
   <a name="GNLmla"><strong>I am a Mailing List Administrator; how can I offer service to my subscribers?</strong></a>
 </td></tr>
 <tr><td>
  <blockquote>
<p>List administrators may offer Affero services to their subscribers by contacting us at <a href="mailto:addlist@affero.com">addlist@affero.com</a>.<BR><a href="#helptop">Click here to return to top</a><BR></p>
   </blockquote>
 </td></tr>
</table>
<table border="0" cellspacing="0" cellpadding="2" width="96.7%">
 <tr><td bgcolor="#999999">
   <a name="GNLnpo"><strong>I am a Non-Profit Organizations; how can I enable donations to my organization?</strong></a>
 </td></tr>
 <tr><td>
  <blockquote>
<p>A registered non-profit organization interested in adding Affero's service to their programs can contact us at <a href="mailto:nonprofit@affero.com">nonprofit@affero.com</a>.<BR><a href="#helptop">Click here to return to top</a><BR></p>
   </blockquote>
 </td></tr>
</table>
<table border="0" cellspacing="0" cellpadding="2" width="96.7%">
 <tr><td bgcolor="#999999">
   <a name="GNLhowedit"><strong>How do I edit my member preferences?</strong></a>
 </td></tr>
 <tr><td>
  <blockquote>
<p>To edit Volunteer or Patron preferences, simply log in with your username and password and you will be taken to your member preferences page.  You may switch between the Volunteer preferences and the Patron preferences with one simple click on the top right hand side of the screen.  Once you have updated the preferences, click update and the changes will take effect immediately.<BR><a href="#helptop">Click here to return to top</a><BR></p>
   </blockquote>
 </td></tr>
</table>
<table border="0" cellspacing="0" cellpadding="2" width="96.7%">
 <tr><td bgcolor="#999999">
   <a name="GNLforgotpass"><strong>I forgot my username and/or password, what do I do?</strong></a>
 </td></tr>
 <tr><td>
  <blockquote>
<p>Go to the Sign In page and click the link labeled "Forgot your login or password".  Enter your email address and we will send you instructions.<BR><a href="#helptop">Click here to return to top</a><BR></p>
   </blockquote>
 </td></tr>
</table>
</BLOCKQUOTE>

<table width="100%" cellpadding=3 cellspacing=0 border=0>
<tr BGColor="#999999">
<td width="50%" align=right>&nbsp;<b>POWERED BY</b> <u><i>affero</i></u>
<tr><td colspan=2 align=center>
</tr>
</table>
</BODY>
</HTML>
