{include file="header.tpl"}
<!--  $Name: ORG-TEST $, $Id: expert-public-profile.tpl,v 1.15 2002/09/02 21:32:21 leed Exp $  -->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{assign var=myServer value=$smarty.server.HTTP_HOST}

<!-- //////////////  HTML GENERATION STARTS HERE  ////////////////// -->
{assign var=AL2_CELL4 value="<a target=\"new\" href=\"http://$myServer/help.php?helpCat=EPPhelp\">Help</a>"}
{include file="allseer-logo2.tpl"}
{assign var=T_EMAIL value=$ExpertProfile->ExpertEmail}
{assign var=ABB2_CELL1 value="Expert Profile for <a href=\"mailto:$T_EMAIL\">$T_EMAIL</a>"}
{assign var=ABB2_CELL2 value="Client Profile Link"}
{include file="allseer-bluebar2.tpl"}

<table width="100%" cellpadding=3 cellspacing=0 border=0>
<tr valign=middle><td colspan=1 rowspan=2>&nbsp; </td></tr><br>
    <table width="100%" cellpadding=3 cellspacing=0 border=0>
        {assign var=HREF_MLIST value="$ExpertProfile->uid"}
        <td width=30%>
            <a href="http://{$myServer}/rate-me.php?r={$HREF_MLIST|escape:"url"}">
            Rate and/or Donate on behalf of {$ExpertProfile->ExpertName}</a>  
        </td>
    </tr>
    </table>
<tr><td colspan=1 rowspan=2>&nbsp;</td></tr>
</table>

<table width="100%" cellpadding=3 cellspacing=0 border=0>
    <tr><td rowspan=15 valign=top width="33%">
    <table width="100%" cellpadding=3 cellspacing=1 border=1>
        <tr><td>
        <table width="100%">
        <tr> <th width="100%" align=left bgcolor=cadetblue>In Their Own Write</th></tr>
            <tr><td width=100%>
            <form readonly WIDTH="100%">
            <TEXTAREA cols="25" rows="10" wrap="soft" width="100%">{$ExpertProfile->Bio}</TEXTAREA>
            </form>
            </td></tr>
        </table>
        </td></tr>
    </table>

    </td><td rowspan=15 valign=top>
    <table width="100%" cellpadding=3 cellspacing=0 border=0>
        <tr><td rowspan=5 valign=top>
        <table width="100%">
            <tr><td valign=top cellpadding=3 cellspacing=0 border=0>
            <table width="100%" cellpadding=3 cellspacing=1 border=1>
                <tr><td>
                <table width="100%" cellpadding=3 cellspacing=0 border=0>
                    <tr> <th width="100%" align=left bgcolor=cadetblue colspan=2>Current Beneficiaries</th></tr>
                    {section name=bene loop=$ExpertProfile->BeneficiaryArray}
                      <tr>
                        <td>{$ExpertProfile->BeneficiaryArray[bene].name}</td>
                        <td>{$ExpertProfile->BeneficiaryArray[bene].pct}%</td>
                      </tr>
                    {/section}
                </table></td></tr>
            </table>
            </td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>
            <table width="100%" cellpadding=3 cellspacing=1 border=1>
                <tr> <th width="100%" align=left bgcolor=cadetblue>Language Preferences</th></tr>
                <tr><td valign=top>&nbsp;&nbsp;{$ExpertProfile->LangList}<br></td></tr>
            </table>
            </td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>
            <table width="100%" cellpadding=3 cellspacing=1 border=1>
                <tr> <th width="100%" align=left bgcolor=cadetblue>Country of Residence</th></tr>
                <tr><td>{$ExpertProfile->ResCountry}<br></td></tr>
            </table>
            </td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>&nbsp;</td></tr>
        </table>
        </td></tr>
    </table>

    </td><td rowspan=15 valign=top width="33%">
    <table width="100%" cellpadding=3 cellspacing=1 border=1>
        <tr><td>
        <table width="100%">
            <tr> <th width100% align=left bgcolor=cadetblue colspan=3> Competencies </th></tr>
            {section name=comp loop=$ExpertProfile->PublicCompetencyArray}
              <tr>
                <td>{$ExpertProfile->PublicCompetencyArray[comp].name}</td>
                <td>{$ExpertProfile->PublicCompetencyArray[comp].rate}</td>
                <td>{$ExpertProfile->PublicCompetencyArray[comp].tips}</td>
              </tr>
            {/section}
        </table>
        </td></tr>
    </table>
    </td>
    </tr>
</table>
<BR>
<table width="100%" cellpadding=3 cellspacing=1 border=1>
    <tr><td>
    <table width="100%">
        <tr> <th width100% align=center bgcolor=cadetblue colspan=4> Recent Ratings and Comments</th></tr>
            {section name=rat loop=$ExpertProfile->ClientCommentsArray}
              <tr>
                <td width="10%">
                    {assign var=T_RECIP value=$ExpertProfile->ClientCommentsArray[rat].rator}
                      {assign var=T_DATA value="<a href=http://$myServer/client-public-profile.php?u=$T_RECIP>$T_RECIP</a>"}
                    {$T_DATA}
                </td>
                <td>{$ExpertProfile->ClientCommentsArray[rat].rating}</td>
                <td>{$ExpertProfile->ClientCommentsArray[rat].comp}</td>
                <td>{$ExpertProfile->ClientCommentsArray[rat].comment}</td>
              </tr>
            {/section}
    </table>
    </td></tr>
</table>
<!--  .............................................................  -->
<!--  ..........................Footer.............................  -->
{include file="allseer-footer.tpl"}
{include file="footer.tpl"}

