<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--  $Name: ORG-TEST $, $Id: html-help.tpl,v 1.2 2002/09/02 21:33:56 leed Exp $--></td>
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{assign var=myServer value=$smarty.server.HTTP_HOST}
<html>
<head>
             
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
             
  <meta name="DESCRIPTION" content="Affero FAQs">
              
  <meta name="KEYWORDS" content="affero, faq, help, volunteer, patron, rate, donate, donation">
  <title>HTML HELP AND HOW-TO'S</title>
</head>
  <body bgcolor="#ffffff" text="#000000" link="#0000ff" vlink="#800080" alink="#ff0000">
   
<table width="100%" cellpadding="0" cellspacing="0" border="0">
    <tbody>
           <tr>
        <td colspan="4"><br>
      </tr>
      <tr bgcolor="#999999">
        <td width="100%" align="Left">&nbsp;<a name="HHonlytag"><strong>BASIC HTML HELP</strong></a></td>
      </tr>
      <tr>
        <td colspan="4">&nbsp;</td>
      </tr>
       
  </tbody>  
</table>
   
<center>  
<form method="Get" action="help.php"></form>
  </center>
   
<blockquote>    <u><big><b>Posting a Link </b></big></u><br>
  To post a link in your message, use the standard HTML anchor tag. Use the
 following sample HTML code as an example:<br>
          
  <blockquote>&lt;a href="http://www.affero.com"&gt;This text&lt;/a&gt; is
 a link to the Affero website.<br>
      <br>
  results in:<br>
      <br>
      <u><font color="#3333ff">This text</font></u> is a link to the Affero 
website.<br>
      </blockquote>
      
    <hr width="100%" size="2"><u><big><b>Posting an E-mail </b></big></u><br>
  To post an e-mail address in your message, use the standard HTML anchor 
tag. Use the following sample HTML code as an example:<br>
                
    <blockquote>&nbsp; &lt;a href="mailto:info@affero.com"&gt;Email me here&lt;/a&gt;<br>
        <br>
  results in:<br>
        <br>
        <u><font color="#3333ff">Email me here</font></u> (when clicked open
 a mail message with a TO: info@affero.com)<br>
               </blockquote>
        
      <hr width="100%" size="2"><b><u><big>Text Tags</big></u></b><br>
               
      <blockquote><b>Bold</b><br>
  &lt;b&gt;This text is bold&lt;/b&gt;&nbsp; results in: <b>This text is
bold</b><br>
          
        <hr width="100%" size="2"><br>
          <i>Italic</i><br>
  &lt;i&gt;This text is italic&lt;/i&gt; results in: <i>This text italic</i><br>
          
        <hr width="100%" size="2"><br>
          <u>Underline</u><br>
  &lt;u&gt;This text is underlined&lt;/u&gt; results in: <u>This text is
underlined</u><br>
          
        <hr width="100%" size="2"><br>
          <b>Line Breaks</b><br>
  To break&lt;br&gt;lines&lt;br&gt;in a&lt;br&gt;sentence or between paragraphs,&lt;br&gt;use
 the br tag. <br>
          <br>
  results in:<br>
          <br>
  To break<br>
  lines<br>
  in a<br>
  sentence or between paragraphs,<br>
  use the br tag<br>
          </blockquote>
         
        <blockquote>         
          <hr width="100%" size="2"><b>Font Size</b> &#8211; sets size of font
from 1 to 7<br>
  &lt;font size="?"&gt;word(s) with selected font size&lt;/font&gt; An example 
is:<br>
                              
          <blockquote>I want &lt;font size="5"&gt;these words&lt;/font&gt; 
to be larger<br>
            <br>
  results in:<br>
            <br>
  I want <big><big>these words</big></big> to be larger.<br>
                       </blockquote>
            
            <hr width="100%" size="2"><b>Font Color</b> &#8211; sets font color
using name or hex html color  code<br>
  &lt;font color="?"&gt;word(s) with selected font color&lt;/font color&gt; 
 An example is:<br>
                        
            <blockquote>I want &lt;font color="#ff0000"&gt;these words&lt;/font&gt; 
to be red. <br>
              <br>
  results in: <br>
              <br>
  I want <font color="#ff0000">these words</font> to be red.<br>
                           </blockquote>
               </blockquote>
              
              <hr width="100%" size="2"><u><big><b>Posting an Image</b></big><big>
 </big></u><br>
  We currently do not provide the capability of adding an image at this time.&nbsp;
 Check back with us in the future as we are adding features regularly<br>
              <br>
              </blockquote>
                             
              <table width="100%" cellpadding="3" cellspacing="0" border="0">
                <tbody>
                  <tr bgcolor="#999999">
                    <td width="50%" align="Right"><br>
                    </td>
                  </tr>
                                 
                </tbody>                            
              </table>
                             
              <table width="100%" cellpadding="3" cellspacing="0" border="0">
                <tbody>
                  <tr>
                    <td colspan="2" align="Center"><br>
                    </td>
                  </tr>
                                 
                </tbody>                            
              </table>
                             
              </body>
              </html>
