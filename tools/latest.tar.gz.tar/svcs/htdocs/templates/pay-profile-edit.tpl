{include file="header.tpl"}
<!--  $Name: ORG-TEST $, $Id: pay-profile-edit.tpl,v 1.15 2002/09/02 21:33:16 leed Exp $ -->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{config_load file="Smarty.Affero.conf"}
{assign var=myServer value=$smarty.server.HTTP_HOST}

<!-- //////////////  HTML GENERATION STARTS HERE  ////////////////// -->

<table width="100%" cellpadding=2 cellspacing=0 border=0>
<FORM METHOD=POST ACTION="pay-profile-edit.php">
<tr><td>
<!-- /////////////////////////////////////////////////////////////// -->
<!--                         Profile List                            -->
<!-- /////////////////////////////////////////////////////////////// -->
{assign var=ABB1_CELL1 value="VIEW, &nbsp;ACTIVATE&nbsp; AND &nbsp;DEACTIVATE &nbsp;DISBURSEMENT &nbsp;PROFILES"}
{include file="allseer-bluebar1.tpl"}
</td></tr><tr><td>
    <table width="100%" cols=5 cellpadding=0 cellspacing=0 border=0>
    <tr bgcolor="#999999">
        <th width="1%"> &nbsp </th>
        <th width="20%" align=left> Profile Name</th>
        <th width="1%"> &nbsp </th>
        <th width="15%" align=center> Active</th>
        <th width="63%"> &nbsp </th>
    </tr>
    {section name=i loop=$PPedit->currentProfileAry}
        <tr>
          <td width="1%">&nbsp;</td>
          <td width="20%" align=left><a href=http://{$myServer}/pay-profile-edit.php?{$PPedit->currentProfileAry[i].viewArgs}>
              {$PPedit->currentProfileAry[i].name}</a></td>

          <td width="1%">&nbsp;</td>
          <td  width="15%" align=left>
            {if $PPedit->currentProfileAry[i].display == "Y"}
               {assign var=YSTATE value="checked"}
               {assign var=NSTATE value=" "}
            {else}
               {assign var=YSTATE value=" "}
               {assign var=NSTATE value="checked"}
            {/if}
            <table width="100%" cellpadding=0 cols=2 cellspacing=0 border=0>
              <tr>
                <td align=right>&nbsp;<input TYPE="radio" VALUE="Yes" NAME=FormPactiv.{%i.index%} {$YSTATE}> Y<br></td>
                <td align=right>&nbsp;<input TYPE="radio" VALUE="No" NAME=FormPactiv.{%i.index%} {$NSTATE}> N<br></td>
              </tr>
            </table>
          </td>
          <td width="63%">&nbsp;</td>
        </tr>
    {/section}
    </table>

<!-- /////////////////////////////////////////////////////////////// -->
<!--                       Profile Details                           -->
<!-- /////////////////////////////////////////////////////////////// -->
</td></tr><tr><td>
{assign var=ABB1_CELL1 value="View Profile details (click on name above to view details)"}
{include file="allseer-bluebar1.tpl"}
</td></tr><tr><td>
    {if $PPedit->viewProfName}
    <table width="100%" cols=2 cellpadding=0 cellspacing=0 border=0>
        <tr valign=top>
        <td class="fld-title" valign=top align=left width="15%"><b>{$PPedit->viewProfName}&nbsp;Details:&nbsp;</b></td>
        <td align=left>
        <table width="80%"  bgcolor="#cccccc" cellpadding=0 cellspacing=0 border=0>
            <tr valign=top><th align=left width="15%" bgcolor="#999999">Share</th>
            <th align=left bgcolor="#999999">Beneficiary</th></tr>
            {section name=jp loop=$PPedit->viewProfile}
              <tr>
                <td align=left width="15%">{$PPedit->viewProfile[jp].pc}%</td>
                <td align=left>{$PPedit->viewProfile[jp].found}</td>
              </tr>
            {/section}
        </table>
        </td></tr>
    </table>
    {/if}

<!-- /////////////////////////////////////////////////////////////// -->
<!--                         Form Submit                             -->
<!-- /////////////////////////////////////////////////////////////// -->
</td></tr><tr><td>
    <table width="100%" cellpadding=0 cellspacing=0 border=0>
        <tr valign=middle>
        <td width="40%">&nbsp;</td>
        <td align=left>&nbsp;
        <INPUT TYPE=submit value="Update Preferences">
        </td></tr>
    </table>

    <INPUT TYPE=hidden name=FormValidate value="1">
    <INPUT TYPE=hidden name=u value="{$PPedit->uid}">
    {if $PPedit->viewProfName}
        {assign var=TEMP value=$PPedit->viewProfileSer}
        <INPUT TYPE=hidden name=vn value="{$PPedit->viewProfName}">
        <INPUT TYPE=hidden name=va value="{$TEMP|escape:"url"}">
    {/if}

</FORM>

<!-- /////////////////////////////////////////////////////////////// -->
<!--                         Footer Shit                             -->
<!-- /////////////////////////////////////////////////////////////// -->
</td></tr><tr><td>
{assign var=ABB2_CELL1 value="FAST FAQs"}
{assign var=ABB2_CELL2 value=#AFFLINX#}
{include file="allseer-bluebar2.tpl"}
</td></tr><tr><td align=center>
    <a target="new" href="http://{$myServer}/help.php?helpCat=PEwhynotactive">Why should a profile be set not active?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=PEhownewbenes">How can I suggest new beneficiaries not on the list?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=PEhowsrc">How do I get the source code?</a>&nbsp;
</td></tr>
</table>
{include file="footer.tpl"}
