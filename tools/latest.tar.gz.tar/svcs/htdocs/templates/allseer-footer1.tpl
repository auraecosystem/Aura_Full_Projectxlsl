<!--  $Name: ORG-TEST $, $Id: allseer-footer1.tpl,v 1.6 2002/09/02 21:33:35 leed Exp $  -->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{if $AF1_CELL1 == "" }
{assign var=AF1_CELL1 value="<a href=\"http://$myServer/\">Privacy</a>"}
{/if}
{if $AF1_CELL4 == "" }
{assign var=AF1_CELL4 value="<a href=\"http://$myServer/\">About Affero</a>"}
{/if}
<hr noshade size=1>
<table width="100%" cellpadding=3 cellspacing=0 border=0>
<tr>
<td width="25%" align=left> &nbsp;{$AF1_CELL1}</td>
<td width="25%" align=left> &nbsp;{$AF1_CELL2}</td>
<td width="25%" align=right> &nbsp;{$AF1_CELL3}</td>
<td width="25%" align=right> &nbsp;{$AF1_CELL4}</td>
</tr>
</table>


