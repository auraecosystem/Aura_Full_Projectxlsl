{include file="header.tpl"}
<!--  $Name: ORG-TEST $, $Id: allseer.tpl,v 1.15 2002/09/02 21:31:43 leed Exp $ -->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{assign var=myServer value=$smarty.server.HTTP_HOST}

{include file="allseer-logo1.tpl"}

{*include file="allseer-searchbox1.tpl"*}

<center> <table BORDER=0 CELLSPACING=0 CELLPADDING=3 WIDTH="640" >
<tr><td ALIGN=CENTER COLSPAN="3"> <a href="http://{$myServer}/join.php?lg=1">login</a></td> </tr>
</table></center>

<center> <table BORDER=0 CELLSPACING=0 CELLPADDING=3 WIDTH="640" >
<tr><td ALIGN=CENTER COLSPAN="3"> <a href="http://{$myServer}/join.php">join</a></td> </tr>
</table></center>

<center> <table BORDER=0 CELLSPACING=0 CELLPADDING=3 WIDTH="640" >
<tr><td ALIGN=CENTER COLSPAN="3"> <a href="http://{$myServer}/forgot-pass.php">forgot password</a></td> </tr>
</table></center>

<br>

{include file="allseer-footer.tpl"}

{include file="footer.tpl"}
