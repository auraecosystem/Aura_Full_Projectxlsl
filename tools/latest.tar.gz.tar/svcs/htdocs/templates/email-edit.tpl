{include file="header.tpl"}
<!--  $Name: ORG-TEST $, $Id: email-edit.tpl,v 1.13 2002/09/02 21:32:11 leed Exp $ -->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{config_load file="Smarty.Affero.conf"}
{assign var=myServer value=$smarty.server.HTTP_HOST}

<!-- //////////////  HTML GENERATION STARTS HERE  ////////////////// -->

<table width="100%" cellpadding=0 cellspacing=0 border=0>
<tr><td>
{assign var=ABB2_CELL1 value="$eMedit->linkToUserHistory"}
{assign var=ABB2_CELL2 value="$eMedit->linkToVolunteerPrefs"}
{include file="allseer-bluebar2.tpl"}
</td></tr>


<FORM METHOD=POST ACTION="email-edit.php">
<!-- ////////////////////////////////////////////////////////////// -->

<tr><td>
    <table width="100%"  cols=6 cellpadding=0 cellspacing=0 border=0>
    <tr bgcolor="#cccccc">
      <th width="01%"> &nbsp </th>
      <th width="30%" align=left>&nbsp;&nbsp;{$eMedit->userRow.user_fwd_email}</th>
      <th width="02%"> &nbsp </th>
      <th width="05%"> Activated </th>
      <th width="02%"> &nbsp; </th>
      <th width="30%" align=left> Remove </th>
    </tr>
    <tr><td colspan=6><font size=-2>&nbsp;</font></td></tr>

    {section name=i loop=$eMedit->altAry}
      <tr>
        <td>&nbsp;</td>
        <td align=left>
        <font color={$eMedit->altAry[i].color}>
            &nbsp;&nbsp;{$eMedit->altAry[i].addy}</font></td>
        <td>&nbsp;</td>
        {assign var=CONT value="Mail Sent"}
        {if $eMedit->altAry[i].activep == "t"}
          {assign var=CONT value="Confirmed"}
        {/if}  
        <td align=center>{$CONT}</td>
        <td>&nbsp;</td>
        <td align=left>&nbsp;
            <input TYPE=checkbox VALUE="CHECKED" NAME=FormRemove.{%i.index%} {$eMedit->altAry[i].checkbox}>
            &nbsp;&nbsp;&nbsp;Remove&nbsp;
        </td>
      </tr>
    {/section}
    </table>
</td></tr>
<tr><td><font size=-2>&nbsp;</font></td></tr>
<tr><td><font size=-2>&nbsp;</font></td></tr>

<tr><td>
{assign var=ABB1_CELL1 value="Request new email address to be added to this account"}
{include file="allseer-bluebar1.tpl"}
</td></tr>
<tr><td><font size=-2>&nbsp;</font></td></tr>

<!--             personalization error messages here                 -->
{section name=mmsg loop=$eMedit->altEmailMessages}
<tr><td>
  <FONT  color="red"><b>{$eMedit->altEmailMessages[mmsg]}</b></FONT>
</td></tr>
{if %mmsg.last%}
<tr><td>&nbsp;</td></tr>
{/if}
{/section}

<tr><td>
  <table width="100%" cellpadding=0 cellspacing=0 border=0>
    <tr>
    <td width="30%">&nbsp;</td>
    <td width="30%" valign=top align=center>

    {assign var=TITLE_COLOR value="black"}
    {if $eMedit->Messages.addAltEmail != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <table width="100%" cellpadding=0 cellspacing=0 border=0>
      <tr valign=middle align=right><td><FONT  color={$TITLE_COLOR}>Add new email:</font></td>
      <td align=left>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <INPUT type=TEXT name=FormaddAltEmail maxlength=50 size=25 value="{$eMedit->addAltEmail}"></td>
      </tr>
    </table>
    </td><td>&nbsp</td></tr>
    <!--  .............................................................  -->
    <!--  .......................Form Submit...........................  -->
    <tr valign=middle>
      <td width="30%">&nbsp;</td>
      <td align=center clospan=2>&nbsp;
      <INPUT TYPE=submit value="Update Email Addresses">
      <FONT face="Arial,Helvetica" size=-1 color="gray">&nbsp;</FONT>
      </td>
      <td align=left>&nbsp;</td>
    </tr>

    <INPUT TYPE=hidden name=FormValidate value="1">
    <INPUT TYPE=hidden name=u value="{$eMedit->userLogin}">
  </table>
  </FORM>
<!--  .......................End of Form...........................  -->

<tr><td colspan=2>
{assign var=ABB2_CELL1 value="FAST FAQs"}
{assign var=ABB2_CELL2 value=#AFFLINX#}
{include file="allseer-bluebar2.tpl"}

</td></tr><tr><td align=center>
    <a target="new" href="http://{$myServer}/help.php?helpCat=EEwhyactivate">Why do I need to activate each address?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=EEwhyremove">Why should I remove an address?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=EEwhyadd">Why should I add other email addresses?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=EEhowsource">How do I get the source code?</a>&nbsp;
</td></tr></td></tr>
</table>
<!--  ..........................Footer.............................  -->

{include file="footer.tpl"}
