{include file="header.tpl"}
<!--  $Name: ORG-TEST $, $Id: client-public-profile.tpl,v 1.13 2002/09/02 21:32:02 leed Exp $  -->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{config_load file="Smarty.Affero.conf"}
{assign var=myServer value=$smarty.server.HTTP_HOST}

<!-- ///////////////  GENERATION STARTS HERE  ////////////////// -->

{assign var=AL2_CELL4 value="<a target=\"new\" href=\"http://$myServer/help.php?helpCat=CPPhelp\">Help</a>"}
{include file="allseer-logo2.tpl"}
{assign var=T_EMAIL value=$ClientProfile->ClientEmail}
{assign var=ABB2_CELL1 value="Client Profile for <a href=\"mailto:$T_EMAIL\">$T_EMAIL</a>"}
{assign var=ABB2_CELL2 value="Expert Profile Link"}
{include file="allseer-bluebar2.tpl"}

<table width="100%" cellpadding=3 cellspacing=0 border=0>
<tr valign=middle><td colspan=1 rowspan=2>&nbsp; </td></tr><br>
    <table width="100%" cellpadding=3 cellspacing=0 border=0>
    <tr>
        {assign var=HREF_MLIST value="cmd=List Archive&cl=$ClientProfile->uid"}
        <td width=30%>
            <a href="http://{$myServer}/unimplemented.php?code={$HREF_MLIST|escape:"url"}">
            {$ClientProfile->ClientName}'s List Archive</a>
        </td>
        <td width=40%>&nbsp;</td>
        {assign var=HREF_MLIST value="cmd=List Signup&cl=$ClientProfile->uid"}
        <td width=30%>
            Experts:&nbsp;
            <a href="http://{$myServer}/unimplemented.php?code={$HREF_MLIST|escape:"url"}">
            Sign up</a> to {$ClientProfile->ClientName}'s list
        </td>
    </tr>
    </table>
<tr><td colspan=1 rowspan=2>&nbsp;</td></tr>
</table>

<table width="100%" cellpadding=3 cellspacing=0 border=0>
    <tr><td rowspan=15 valign=top>
    <table width="100%" cellpadding=3 cellspacing=0 border=0>
        <tr><td rowspan=5 valign=top>
        <table width="100%">
            <tr><td valign=top cellpadding=3 cellspacing=0 border=0>
            <table width="100%" cellpadding=3 cellspacing=1 border=1>
                <tr> <th width="100%" align=left bgcolor=cadetblue> Language Preferences</th></tr>
                <tr><td valign=top>&nbsp;&nbsp;{$ClientProfile->LangList}<br></td></tr>
            </table>
            </td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>
            <table width="100%" cellpadding=3 cellspacing=1 border=1>
                <tr> <th width="100%" align=left bgcolor=cadetblue> Country of Residence</th></tr>
                <tr><td>{$ClientProfile->ResCountry}<br></td></tr>
            </table>
            </td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>
            <table width="100%" cellpadding=3 cellspacing=1 border=1>
                <tr> <th width="100%" align=left bgcolor=cadetblue> Client Since</th></tr>
                <tr><td>{$ClientProfile->Created}<br></td></tr>
            </table>
            </td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>&nbsp;</td></tr>
        </table>
        </td></tr>
    </table>
    </td><td rowspan=15 valign=top>

    <table width="100%" cellpadding=3 cellspacing=1 border=1>
        <tr><td>
        <table width="100%" cellpadding=1 cellspacing=0 border=0>
            <tr> <th width=100% align=center bgcolor=cadetblue colspan=3>Payments</th></tr>
            <tr> <th align=left bgcolor="#E0D0B0" > Recipient</th>
                 <th align left bgcolor="#E0D0B0" > Rating</th>
                 <th align=left bgcolor="#E0D0B0" > Amount</th></tr>
           {section name=pay loop=$ClientProfile->PaymentArray}
              {if %pay.iteration% <= 13}
              <tr>
                <!--  maybe link to the expert's public profile      -->
                {assign var=T_RECIP value=$ClientProfile->PaymentArray[pay].recipient}
                {if $ClientProfile->PaymentArray[pay].public == "f"}
                  {assign var=T_DATA value=$T_RECIP}
                {else}
                  {assign var=T_DATA value="<a href=http://$myServer/expert-public-profile.php?u=$T_RECIP>$T_RECIP</a>"}
                {/if}
                <td>{$T_DATA}</td>
                <td>{$ClientProfile->PaymentArray[pay].rating}</td>
                <td>${$ClientProfile->PaymentArray[pay].amt}</td>
              </tr>
              {/if}
            {/section}
        </table>
        </td></tr>
    </table>
    </td><td rowspan=15 valign=top>

    <table width="100%" cellpadding=3 cellspacing=1 border=1>
        <tr><td>
        <table width="100%"cellpadding=1 cellspacing=0 border=0>
            <tr> <th width100% align=center bgcolor=cadetblue colspan=4> Ratings</th></tr>
            <tr>
              <th width100% align=left  bgcolor="#E0D0B0">Competency</th>
              <th width100% align=right bgcolor="#E0D0B0">Rate</th>
              <th width100% align=right bgcolor="#E0D0B0">Tip</th>
              <th width100% align=right bgcolor="#E0D0B0">Avg($)</th>
            </tr>
            {section name=rate loop=$ClientProfile->RatingsArray}
              <tr><td>{$ClientProfile->RatingsArray[rate].comp}</td>
                  {assign var=CID value=$ClientProfile->RatingsArray[rate.index].cid}

                  <td align=right> 
                  {if $ClientProfile->RatingsArray[rate].rate_count > 0}
                    {assign var=HREF_RCOUNT value="cmd=Rate Count&cid=$CID&cl=$ClientProfile->uid"}
                    <a href="http://{$myServer}/unimplemented.php?code={$HREF_RCOUNT|escape:"url"}">
                    {$ClientProfile->RatingsArray[rate].rate_count}
                    </a>
                  {else}
                    {$ClientProfile->RatingsArray[rate].rate_count}
                  {/if}
                  </td>
                  
                  <td align=right>
                  {if $ClientProfile->RatingsArray[rate].tip_count > 0}
                    {assign var=HREF_TCOUNT value="cmd=Tip Count&cid=$ClientProfile->RatingsArray[rate].cid&cl=$ClientProfile->uid"}
                    <a href="http://{$myServer}/unimplemented.php?code={$HREF_TCOUNT|escape:"url"}">
                  {/if}
                  {$ClientProfile->RatingsArray[rate].tip_count}
                  </td> 

                  <td align=right>
                  {if $ClientProfile->RatingsArray[rate].tip_avg > 0}
                    {$ClientProfile->RatingsArray[rate].tip_avg|string_format:"%.2f"}
                  {else} 
                    ---
                  {/if}   
                  </td>
              </tr>
            {/section}
        </table>
        </td></tr>
    </table>
    </td>
    </tr>
</table>
<BR>
<table width="100%" cellpadding=3 cellspacing=1 border=1>
    <tr><td>
    <table width="100%">
        <tr> <th width100% align=left bgcolor=cadetblue colspan=3>
            Recent Ratings and Comments about {$ClientProfile->ClientName} by Experts</th>
        </tr>
        {section name=i loop=$ClientProfile->ExpertCommentsArray}
        {if $ClientProfile->ExpertCommentsArray[i].public == "t"}
            <tr>
                <td width="10%">
                    {assign var=T_RECIP value=$ClientProfile->ExpertCommentsArray[i].expert}
                      {assign var=T_DATA value="<a href=http://$myServer/expert-public-profile.php?u=$T_RECIP>$T_RECIP</a>"}
                    {$T_DATA}
                </td>
                <td width="5%">
                    {$ClientProfile->ExpertCommentsArray[i].rating}
                </td>
                <td width="85%">
                    {$ClientProfile->ExpertCommentsArray[i].comment}
                </td>
            </tr>
        {/if}
        {/section}
    </table>
    </td></tr>
</table>
<!--  .............................................................  -->
<!--  ..........................Footer.............................  -->
{include file="allseer-footer.tpl"}
{include file="footer.tpl"}

