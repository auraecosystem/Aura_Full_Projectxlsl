{include file="header.tpl"}
<!--  $Name: ORG-TEST $, $Id: join.tpl,v 1.18 2002/10/04 16:44:44 leed Exp $-->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{config_load file="Smarty.Affero.conf"}
{assign var=myServer value=$smarty.server.HTTP_HOST}

<!-- //////////////  HTML GENERATION STARTS HERE  ////////////////// -->

<table width="100%" cellpadding=0 cellspacing=0 border=0>
<tr><td>
{assign var=ABB2_CELL1 value="AFFERO JOIN"}
{assign var=ABB2_CELL2 value=" "}
{include file="allseer-bluebar2.tpl"}
</td></tr><tr><td>
&nbsp<br>
</td></tr><tr><td align=center>

<FORM METHOD="POST" ACTION="join.php">
    <center>
    <table width="100%" cellpadding=0 cellspacing=0 border=0>
    {section name=j loop=$NewUser->regMessages}
    <tr><td>
      <FONT  color="red">
      <b>{$NewUser->regMessages[j]}</b></FONT>
    </td></tr>
    {if %j.last%}
    <tr><td>&nbsp;</td></tr>
    {/if}
    {/section}
    </table>

    <table  bgcolor="#cccccc" width="45%" cols=2 cellpadding=0 cellspacing=0 border=0>
    <tr valign=top><th bgcolor="#999999" colspan=2>
    New User Register
    </th></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $NewUser->Messages.Email != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}

    <tr valign=top>
    <td align=right valign=middle class="fld-title"><FONT color={$TITLE_COLOR}>
    Your email address:</FONT></td>
    <td>&nbsp;
    <FONT  size=-1 color="gray">
    <INPUT type=TEXT name=regFormEmail maxlength=50 size=16>
    </FONT>
    </td></tr>

    <tr valign=bottom>
    <td colspan=2>
    <FONT  size=-1 color="black">
    &nbsp; &nbsp; &nbsp; &nbsp;
    Activation email will be sent to you shortly. 
    View the <a target="new" href="http://www.affero.com/ctos.html">Terms of Service</a>.
    </FONT>

    </tr>
    <tr><td colspan=2>&nbsp;</td></tr>
    </table>
    </center>

    <!--...........Form Submission / Hidden Fields.................  -->
    <table width="100%" cellpadding=0 cellspacing=0 border=0>
    <tr><td align=center>
    <INPUT TYPE=submit value="Join">
    </td></tr><tr><td>
    <INPUT TYPE=hidden name=regFormValidate value="1">
    <INPUT TYPE=hidden name=lg value="{$NewUser->loginScreen}">
    <INPUT TYPE=hidden name=spa value="{$NewUser->serializedProfileArgs}">
    </td></tr>
    </table>
</FORM>
</td></tr>

<!--  .............................................................  -->
<!--  ...........................FAQs..............................  -->
<tr><td>
{assign var=ABB2_CELL1 value="FAST FAQs"}
{assign var=ABB2_CELL2 value=#AFFLINX#}
{include file="allseer-bluebar2.tpl"}

</td></tr><tr><td align=center>
    <a target="new" href="http://{$myServer}/help.php?helpCat=JSprivpol">What is Affero's privacy policy?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=JSinfo">What information is required?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=JSwho">Who is Affero?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=JShow">How do I get the source code?</a>&nbsp;
</td></tr>
</table>

{include file="footer.tpl"}
