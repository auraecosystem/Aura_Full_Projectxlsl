{include file="header.tpl"}
<!--  $Name: ORG-TEST $, $Id: rate-me.tpl,v 1.38 2002/11/18 20:47:34 leed Exp $  -->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{config_load file="Smarty.Affero.conf"}
{assign var=myServer value=$smarty.server.HTTP_HOST}

<FORM METHOD=POST ACTION="rate-me.php">
<table width="100%" cellpadding=0 cellspacing=0 border=0>

{if $RateMe->ProfileObj->displayProppa != ""}
  <tr><td colspan=4>
  <table width="100%" cellpadding=0 cellspacing=0 border=0>
<!--                          Propaganda                             -->
  <tr><td colspan=4>
  {assign var=ABB1_CELL1 value="A MESSAGE FROM: $RateMe->proppaWriter"}
  {include file="allseer-bluebar1.tpl"}
  </td></tr>

  <tr><td colspan=4>
  <table width="100%" cols=3 cellpadding=0 cellspacing=0 border=0>
    <tr><td width="5%">&nbsp;</td><td >&nbsp;</td><td width="5%">&nbsp;</td><tr>
    <td>&nbsp</td>
    <td width="90%">{$RateMe->ProfileObj->displayProppa}</td>
    <td>&nbsp</td>
    </tr>
    </table>
  </td></tr>
  </table></td></tr>
{/if}

<!--                            Rating Fields                        -->
<tr><td align=left colspan=4> &nbsp;</td></tr>
<tr><td colspan=4>
{assign var=ABB1_CELL1 value="RATE AND DONATE"}
{include file="allseer-bluebar1.tpl"}
</td></tr>
<tr><td colspan=4>
<table width="100%" cellpadding=0 cellspacing=0 border=0>
    <tr><td width="10%">&nbsp;
      <font color="#999999" size="+3">Step&nbsp;&nbsp;<b>1</b></font>
    </td><td colspan=3>
    <center>
    {include file="rate-directions.txt"}
    </center>
    </td>
    <td width="10%">&nbsp</td>
    </tr>
</table>
</td></tr>

<tr><td colspan=4>&nbsp;</td></tr>
<!--                Rate block error messages here                   -->
{section name=tmsg loop=$RateMe->topMessages}
<tr><td colspan=4>
  <FONT  color="red">
  <b>{$RateMe->topMessages[tmsg]}</b></FONT>
</td></tr>
{if %tmsg.last%}
<tr><td colspan=4>&nbsp;</td></tr>
{/if}
{/section}

<!--              Rate block form fields after this                  -->
<tr><td colspan=4>
<table width="100%" cellpadding=0 cellspacing=0 border=0>
  <tr valign=middle>
  <td align=right class="fld-title">Rate the value of <b>{$RateMe->BarString}'s</b> contribution:</td>
  <td><font color=red size=2>&nbsp;</font></td>
  <td colspan=2>&nbsp;
  <select name=rateFormValue tabindex=1>
  {section name=rating loop=$RateMe->Ratings}
  <option value="{$RateMe->Ratings[rating].rating_val}">{$RateMe->Ratings[rating].rating_descr}</option>
  {/section}
  </select>
  <FONT  size=-1 color="gray"><b>&nbsp;</b></FONT>
  </td></tr>

<!--          there could be an empty comptencies array              -->
{if count($RateMe->Competencies) gt 0}
    <tr valign=middle>
    <td align=right class="fld-title">How would you categorize the contribution:</td>
    <td><font color=red size=2>&nbsp;</font></td>
    <td colspan=2>&nbsp;
    <select name=rateFormCategorize>
    {section name=competency loop=$RateMe->Competencies}
    <option value="{$RateMe->Competencies[competency].cmptcy_descr}">{$RateMe->Competencies[competency].cmptcy_descr}</option>
    {/section}
    </select>
    <FONT  size=-1 color="gray"><b>&nbsp;</b></FONT>
    </td></tr>
{/if}

  <tr valign=middle>
  <td align=right class="fld-title">Comment on the contribution:</td>
  <td><font color=red size=2>&nbsp;</font></td>
  <td colspan=2>&nbsp;
  <TEXTAREA name=rateFormComment tabindex=2 rows=2 cols=40 wrap=soft>{$RateMe->Comment}</TEXTAREA>
  <FONT  size=-1 color="gray"><b>&nbsp;</b></FONT>
  </td></tr>

  {assign var=TITLE_COLOR value="black"}
  {if $RateMe->Messages.Tip != ""}
  {assign var=TITLE_COLOR value="red"}
  {/if}
  <tr valign=middle>
  <td align=right class="fld-title"><FONT  color={$TITLE_COLOR}>
  Optionally show thanks with a Gift:</FONT></td>

  <td width="1%">&nbsp;</td>
  <td colspan=2>&nbsp;
  <INPUT type=TEXT name=rateFormTip tabindex=3 maxlength=7 size=7 value="{$RateMe->Tip}">
  <FONT  size=-1 color="black">
  <b>&nbsp;&nbsp;&nbsp;US$5 min + Processing fee--greater of $1.00 or 6%</b></FONT></td>
  </tr>

  <tr>
  <td valign=middle align=right class="fld-title">This Gift will be disbursed as follows:&nbsp;</td>
  <td width="1%">&nbsp;</td>
  <td valign=top colspan=2>&nbsp;
    <table bgcolor="#cccccc" width="75%" cols=3 cellpadding=0 cellspacing=0 border=0>
    <tr valign=top>
    <th bgcolor="#999999" align=left width="20%">&nbsp; &nbsp; Share</th>
    <th bgcolor="#999999" align=left width="80%">&nbsp; &nbsp; Beneficiary</th>
    </tr>
    {section name=prof loop=$RateMe->ProfileObj->profileAry}
      <tr>
      <td>&nbsp; &nbsp; {$RateMe->ProfileObj->profileAry[prof].pct}%</td>
      <td>&nbsp; &nbsp; {$RateMe->ProfileObj->profileAry[prof].dpyTxt}</td>
      </tr>
    {/section}
    </table>
  </td></tr>
</table>
</td></tr>

<!--                       Identity Fields                           -->
<tr><td align=left colspan=4> &nbsp;</td></tr>
<tr><td colspan=4>
{assign var=ABB1_CELL1 value="SUBMIT YOUR FEEDBACK"}
{include file="allseer-bluebar1.tpl"}
</td></tr>
<tr><td colspan=4>&nbsp;
  <font color="#999999" size="+3">Step&nbsp;&nbsp;<b>2</b></font>
{include file="submit-directions.txt"}
</td></tr>

<!--                Identity block error messages here               -->
{section name=tmsg loop=$RateMe->bottomMessages}
<tr><td colspan=4>
  <FONT  color="red">
  <b>{$RateMe->bottomMessages[tmsg]}</b></FONT>
</td></tr>
{if %tmsg.last%}
<tr><td colspan=4>&nbsp;</td></tr>
{/if}
{/section}

<tr><td colspan=4>
  <table width="100%" cols=3 cellpadding=0 cellspacing=0 border=0>
  <tbody><tr valign=top><td align=right>

  <table bgcolor="#cccccc" width="75%" cols="2" cellpadding="0" cellspacing="0" border="0">
   <tbody>
   <tr valign="Top"><th bgcolor="#999999" colspan="2">Existing User</th></tr>

   {assign var=TITLE_COLOR value="black"}
   {if $RateMe->Messages.Login != ""}
   {assign var=TITLE_COLOR value="red"}
   {/if}
   <tr valign="Top">
     <td align="Right" valign="Middle" class="fld-title">
     <font color="{$TITLE_COLOR}">Affero Username:</font></td>

     <td>&nbsp; <font size="-1" color="gray">
     <input type="text" name="rateFormLogin" tabindex="4" maxlength="15" size="12" value="{$RateMe->Login}">
     </font></td></tr>

    {assign var=TITLE_COLOR value="black"}
    {if $RateMe->Messages.Password != ""}
    {assign var=TITLE_COLOR value="red"}
    {/if}
    <tr valign="Top">
      <td align="Right" valign="Middle" class="fld-title">
      <font color="{$TITLE_COLOR}">Affero Password:</font></td>

      <td>&nbsp; <font size="-1" color="gray">
      <input type="password" name="rateFormPassword" tabindex="5" maxlength="15" size="12" value="{$RateMe->Password}">
      </font></td></tr>

    <tr valign=baseline><td colspan=2><div align="Center">
    {assign var=REM value="$RateMe->RateeEmail "}
    {if $REM != ""}
      <a href="http://{$myServer}/forgot-pass.php?m={$REM|escape:"url"}">
    {else}
      <a href="http://{$myServer}/forgot-pass.php">
    {/if}
    <font size="-1" color="gray">&nbsp;Forgot Login Info?</font></a>
    </div></td></tr>

    </tbody></table>
  </td>
  <td width="5%"><b><font color="#999999" size="+3">&nbsp;OR&nbsp;</font></b> </td>
  <td>
    <table bgcolor="#cccccc" width="75%" cols="2"cellpadding="0" cellspacing="0" border="0">
    <tbody>
      <tr valign="Top"><th colspan="2" bgcolor="#999999">New User</th></tr>
  
      <tr><td colspan="2">&nbsp;</td></tr>

      {assign var=TITLE_COLOR value="black"}
      {if $RateMe->Messages.Email != ""}
      {assign var=TITLE_COLOR value="red"}
      {/if}
      <tr valign="Top"><td align="Right" valign="Middle" class="fld-title">
        <font color="{$TITLE_COLOR}">Your email address:</font></td>
  
        <td>&nbsp; <font size="-1" color="gray">
          <input type="text" name="rateFormEmail" tabindex="6" maxlength="50" size="16" value="{$RateMe->Email}">
        </font></td></tr>

      {assign var=TITLE_COLOR value="black"}
      {if $RateMe->Messages.TOS != ""}
      {assign var=TITLE_COLOR value="red"}
      {/if}
      <tr valign="Bottom"><td colspan="2">
      &nbsp;
      </td></tr>
    </tbody></table>
  </td>
</tr>
</tbody></table></td></tr>

<tr><td colspan="4" > &nbsp</td></tr>

<tr valign=middle>
<td align=center colspan=4>&nbsp;
  <INPUT TYPE=submit value="Submit Feedback">&nbsp;
</td></tr>

<tr><td colspan=4>

{assign var=ABB2_CELL1 value="FAST FAQs"}
{assign var=ABB2_CELL2 value=#AFFLINX#}
{include file="allseer-bluebar2.tpl"}

</td></tr><tr><td colspan=4 align=center>
    <a target="new" href="http://{$myServer}/help.php?helpCat=RMfeedback">Why provide ratings and comments?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=RMwhydonate">Why donate?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=RMwhodonate">Who can donate?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=RMprivacy">What is Affero's privacy policy?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=RMwhatinfo">What information is required?</a>&nbsp;
</td></tr><tr><td colspan=4 align=center>
    <a target="new" href="http://{$myServer}/help.php?helpCat=RMwhosallseer">Who is Affero?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=RMwhoscharities">Who chose the charities?</a>&nbsp;
    <a target="new" href="http://www.affero.com/cj.html">How do I join without rating or donating?</a>&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=RMhowgetsrc">How do I get the source code?</a>&nbsp;
</td></tr>
</table>
<INPUT TYPE=hidden name=rateFormValidate value="1">
<INPUT TYPE=hidden name=aa value="{$RateMe->serializedEncodedArgAry}">
</FORM>

{include file="footer.tpl"}




