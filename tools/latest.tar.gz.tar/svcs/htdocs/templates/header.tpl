<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<!-- test -- >
<!--  $Name: ORG-TEST $, $Id: header.tpl,v 1.7 2002/09/02 21:32:32 leed Exp $  -->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
   <meta http-equiv="PICS-Label" content="(PICS-1.1">
   <meta name="GENERATOR" content="Mozilla/4.72 [en] (X11; I; Linux 2.2.15-6mdk i686) [Netscape]">
   <title>{$AHD_TITLE|default:"Affero"}</title>
   <base target="_top">
</head>
<body>
