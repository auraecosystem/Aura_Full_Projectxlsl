<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--  $Name: ORG-TEST $, $Id: client-profile-help.tpl,v 1.13 2002/09/02 21:31:53 leed Exp $-->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{assign var=myServer value=$smarty.server.HTTP_HOST}
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<META name="DESCRIPTION" content="Affero FAQs"> 
<META name="KEYWORDS" content="affero, help, volunteer, patron, rate, donate, donation">
<TITLE>AFFERO HELP AND HOW-TO'S
</TITLE>
</HEAD>
<BODY BGCOLOR="#FFFFFF" TEXT="000000" LINK="#0000FF" VLINK="#800080" ALINK="#FF0000">
<A NAME="helptop"></A>
<table width="100%" cellpadding=0 cellspacing=0 border=0>
<tr><td align=left colspan=4> &nbsp;</td></tr>
<tr><td colspan=4>
<tr BGColor="#999999">
<td width="103%" align=left>&nbsp;<b>UPDATE PATRON PREFERENCES FAQs</b></td>
</tr>
<tr><td colspan=4>&nbsp;</td></tr>
</table>
<center>
<form method="get" action="help.php">
<div align="center">
OTHER FAQ'S:
<select name="helpFormSel">
<option value="GNL">General FAQs</option>
<option value="GNLwhoallseer">--Who is Affero?</option>
<option value="GNLcost">--Does it cost anything to join?</option>
<option value="GNLwhatmail">--How do I get additional support?</option>
<option value="GNLwhatbenef">--What are beneficiaries?</option>
<option value="GNLmla">--I am a mailing list administrator. How can I offer this service to my subscribers?</option>
<option value="GNLnpo">--I am a Non Profit Organization.  How can I enable donations to my organization?</option>
<option value="GNLhowedit">--How do I edit my member preferences?</option>
<option value="GNLforgotpass">--I forgot my username and/or password, what do I do?</option>
<option value="JS">Join FAQ's</option>
<option value="JSprivpol">--What is Affero's privacy policy?</option>
<option value="JSinfo">--What information is required?</option>
<option value="JSwho">--Who is Affero?</option>
<option value="JShow">--How do I get the source code?</option>
<option value="LG">Login FAQ's</option>
<option value="LGprivpol">--What is Affero's privacy policy?</option>
<option value="LGinfo">--What information is required?</option>
<option value="LGwho">--Who is Affero?</option>
<option value="LGhow">--How do I get the source code?</option>
<option value="RM">Rate Volunteer Fast FAQs</option>
<option value="RMfeedback">--Why provide ratings and comments?</option>
<option value="RMwhydonate">--Why donate?</option>
<option value="RMwhodonate">--Who can donate?</option>
<option value="RMprivacy">--What is Affero's privacy policy?</option>
<option value="RMwhatinfo">--What information is required?</option>
<option value="RMwhosallseer">--Who is Affero?</option>
<option value="RMwhoscharities">--Who chose the charities?</option>
<option value="RMhowgetsrc">--How do I get the source code?</option>
<option value="EP">Update Volunteer Preferences Fast FAQs</option>
<option value="EPwhynotify">--Why should I be notified?</option>
<option value="EPwhyaddemail">--Why should I add email addresses</option>
<option value="EPwhyprofile">--Why should I add disbursement profiles?</option>
<option value="EPwhatpriv">--What is Affero's privacy policy?</option>
<option value="EPwhyselect">--Why should I select a default disbursement profile?</option>
<option value="EPhowcancel">--What if I no longer want to be a Volunteer?</option>
<option value="EPwhylink">--Why should I add a link in my email sig or web page?</option>
<option value="EPhowsource">--How do I get the source code?</option>
<option value="EE">Volunteer Email Edit Fast FAQs</option>
<option value="EEwhyactivate">--Why do I need to activate each address?</option>
<option value="EEwhyremove">--Why should I remove an address?</option>
<option value="EEwhyadd">--Why should I add other email addresses?</option>
<option value="EEhowsource">--How do I get the source code?</option>
<option value="ACT">Activate Account Fast FAQs</option>
<option value="ACTemail">--Why did I receive an email from Affero?</option>
<option value="ACTregister">--Why register?</option>
<option value="ACTinfo">--What information is required?</option>
<option value="ACTwho">--Who is AllSeer?</option>
<option value="ACTprivPol">--What is Affero's privacy policy?</option>
<option value="ACThow">--How do I get the source code?</option>
<option value="CP">Update Patron Profile Fast FAQs</option>
<option value="CPwhynotify">--Why should I be notified?</option>
<option value="CPwhyaddemail">--Why should I add email addresses?</option>
<option value="CPwhyprovidebill">--Why should I provide billing information?</option>
<option value="CPwhatpriv">--What is Affero's privacy policy?</option>
<option value="CPwhycredit">--Why do I need to provide credit card information each time I provide a gift?</option>
<option value="CPhowprivate">--How Do I keep my gifts private?</option>
<option value="CPhowsource">--How do I get the source code?</option>
<option value="RC">Rate Patron Fast FAQs</option>
<option value="RCwhyfeedbk">--Why provide ratings and comments?</option>
<option value="RCwhatpriv">--What is Affero's privacy policy?</option>
<option value="RChowsource">--How do I get the source code?</option>
<option value="PE">Update Pay Profile Fast FAQs</option>
<option value="PEwhynotactive">--Why should a profile be set not active?</option>
<option value="PEhownewbenes">--How can I suggest new beneficiaries not on the list?</option>
<option value="PExhowsource">--How do I get the source code?</option>
</select>
<input type="submit" value="GO!">
</div>
</form>
<FONT  size=-1 color="gray"><b>&nbsp;</b></FONT>
</CENTER>
<BR>
<P>
<A HREF="#CPwhynotify">Q: Why should I be notified?</A><BR>
<A HREF="#CPwhyaddemail">Q: Why should I add email addresses?</A><BR>
<A HREF="#CPwhyprovidebill">Q: Why should I provide billing information?</A><BR>
<A HREF="#CPwhatpriv">Q: What is Affero's privacy policy?</A><BR>
<A HREF="#CPwhycredit">Q: Why do I need to provide credit card information each time I provide a gift?</A><BR>
<A HREF="#CPhowprivate">Q: How can I keep my gifts private?</A><BR>
<A HREF="#CPhowsource">Q: How do I get the source code?</A><BR>
</P>
<BR>
        <table border="0" cellspacing="0" cellpadding="2" width="100%">
<tr><td bgcolor="#999999">
   <strong>Answers</strong>
 </td></tr>
</table>
  <blockquote>
<table border="0" cellspacing="0" cellpadding="2" width="96.7%">
 <tr><td bgcolor="#999999">
   <a name="CPwhynotify"><strong>Why should I be notified?</strong></a>
 </td></tr>
 <tr><td>
  <blockquote>
<p>These email notifications will inform you of ratings and comments from Volunteers that you rated and/or provide you with details of your charitable donation.<BR><a href="#helptop">Click here to return to top</a><BR></p>
   </blockquote>
 </td></tr>
</table>
<table border="0" cellspacing="0" cellpadding="2" width="96.7%">
 <tr><td bgcolor="#999999">
    <a name="CPwhyaddemail"><strong>Why should I add email addresses?</strong></a>
 </td></tr>
 <tr><td>
  <blockquote>
<p>Individuals often maintain more than one email address.  To consolidate email notifications from Affero, you must add all of your active email addresses to you preferences.<BR><a href="#helptop">Click here to return to top</a><BR></p>
   </blockquote>
 </td></tr>
</table>
<table border="0" cellspacing="0" cellpadding="2" width="96.7%">
 <tr><td bgcolor="#999999">
   <a name="CPwhyprovidebill"><strong>Why should I provide billing information?</strong></a>
 </td></tr>
 <tr><td>
  <blockquote>
<p>Filling out this information simplifies the process for future donations.  This information is stored in the database and populates into the fields thus you will not be required to fill in the information each time you chose to make a charitable donation.<BR><a href="#helptop">Click here to return to top</a><BR></p>
   </blockquote>
 </td></tr>
</table>
<table border="0" cellspacing="0" cellpadding="2" width="96.7%">
 <tr><td bgcolor="#999999">
   <a name="CPwhatpriv"><strong>What is Affero's privacy policy?</strong></a>
 </td></tr>
 <tr><td>
  <blockquote>
<p>Your username and the ratings and comments you provide are public information.  Until you activate your account and provide a username and password, your email address will be disclosed to any member for whom you make a contribution.  Thereafter, your email address and other personal information will not be disclosed unless you choose to disclose this information in a public discussion list or in your username or comments.  You have the option to keep donation information solely between yourself, the Volunteer and the beneficiaries.  To read the privacy policy in its entirety, please click <a href="http://www.affero.com/cpp.html">here</a>.<BR><a href="#helptop">Click here to return to top</a><BR></p>
   </blockquote>
 </td></tr>
</table>
<table border="0" cellspacing="0" cellpadding="2" width="96.7%">
 <tr><td bgcolor="#999999">
   <a name="CPwhycredit"><strong>Why do I need to provide credit card information each time I provide a gift?</strong></a>
 </td></tr>
 <tr><td>
  <blockquote>
<p>Affero does not store credit card information in the database, thus each time you make a donation, you must reenter your credit card information.<BR><a href="#helptop">Click here to return to top</a><BR></p>
   </blockquote>
 </td></tr>
</table>
<table border="0" cellspacing="0" cellpadding="2" width="96.7%">
 <tr><td bgcolor="#999999">
   <a name="CPhowprivate"><strong>How can I keep my gifts private?</strong></a>
 </td></tr>
 <tr><td>
  <blockquote>
<p>Upon registering, the update Patron preferences page includes an option to keep your gift history private.  This gives you the option to keep donation information solely between yourself, the Volunteer and the beneficiaries.<BR><a href="#helptop">Click here to return to top</a><BR></p>
   </blockquote>
 </td></tr>
</table>
<table border="0" cellspacing="0" cellpadding="2" width="96.7%">
 <tr><td bgcolor="#999999">
   <a name="CPhowsource"><strong>How do I get the source code?</strong></a>
 </td></tr>
 <tr><td>
  <blockquote>
<p>At the bottom of every page in the service, you will see a character "(o)".  Click on this to get a tarball of the source.<BR><a href="#helptop">Click here to return to top</a><BR></p>
   </blockquote>
 </td></tr>
</table>
</BLOCKQUOTE>         

<table width="100%" cellpadding=3 cellspacing=0 border=0>
<tr BGColor="#999999">
<td width="50%" align=right>&nbsp;<b>POWERED BY</b> <u><i>affero</i></u>
<tr><td colspan=2 align=center>
</tr>
</table>
</BODY>
</HTML>
