{include file="header.tpl"}
<!--  $Name: ORG-TEST $Name: ORG-TEST $, $Id: activate.tpl,v 1.16 2002/09/02 21:33:47 leed Exp $-->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{config_load file="Smarty.Affero.conf"}
{assign var=myServer value=$smarty.server.HTTP_HOST}

<!-- ..............  HTML GENERATION STARTS HERE  ...................-->

<FORM METHOD=POST ACTION="activate.php">
<table width="100%" cellpadding=3 cellspacing=0 border=0>

<tr><td colspan=2>
{assign var=ABB1_CELL1 value="ACTIVATION for: $NewUser->BarString"}
{include file="allseer-bluebar1.tpl"}
</td></tr>

<!--                Activation error messages here                   -->
{section name=tmsg loop=$NewUser->topMessages}
<tr><td colspan=4>
  <FONT  color="red">
  <b>{$NewUser->topMessages[tmsg]}</b></FONT>
</td></tr>
{if %tmsg.last%}
<tr><td colspan=4>&nbsp;</td></tr>
{/if}
{/section}

{assign var=TITLE_COLOR value="black"}
{if $NewUser->Messages.Login != ""}
{assign var=TITLE_COLOR value="red"}
{/if}
{assign var=RATTR value=" "}
{if $NewUser->authString == "inactivated"}
{assign var=RATTR value="READONLY"}
{/if}

<tr valign=middle>
<td align=right class="fld-title"><FONT  color={$TITLE_COLOR}>Login Name:</FONT></td>
<td>
<INPUT type=TREXT {$RATTR} name=regFormLogin maxlength=15 size=12 value="{$NewUser->Login}">
</td></tr>


{assign var=TITLE_COLOR value="black"}
{if $NewUser->Messages.Password != ""}
{assign var=TITLE_COLOR value="red"}
{/if}
<tr valign=middle>
<td align=right class="fld-title">Password (twice):</td>
<td>
    <table width="50%" cellpadding=3 cellspacing=0 border=0>
    <tr><td>
    <INPUT type=password name=regFormPassword1 maxlength=15 size=12 value="{$NewUser->Password1}">
    </td><td>
    <INPUT type=password name=regFormPassword2 maxlength=15 size=12 value="{$NewUser->Password2}">
    </td></tr>
    </table>    
</td>
</tr>

{assign var=TITLE_COLOR value="black"}
{if $NewUser->Messages.TOS != ""}
{assign var=TITLE_COLOR value="red"}
{/if}
<tr valign=middle>
<td align=right class="fld-title">Accept <a target="new" href="http://www.affero.com/ctos.html">Terms of Service</a>?&nbsp;</td>
<td>
    <table width="15%" cols=3 cellpadding=3 cellspacing=0 border=0>
    <tr>
    <td align=left>&nbsp;<input TYPE="radio" VALUE="Yes" NAME="regFormTOS" {if $NewUser->TOS == "Yes"}checked{/if}> Yes <br></td>
    <td>&nbsp;<input TYPE="radio" VALUE="No" NAME="regFormTOS" {if $NewUser->TOS != "Yes"}checked{/if}> No <br></td>
    </tr>
    </table>
</td></tr>

<tr valign=middle>
<td align=right class="fld-title">&nbsp;</td>
<td>
    <table width="50%" cellpadding=3 cellspacing=0 border=0>
    <tr><td align=center>
    <INPUT TYPE=submit value="Activate Account">
    <FONT face="Arial,Helvetica" size=-1 color="gray"><b>&nbsp;</b></FONT>
    </td></tr>
    </table>    
</td></tr>

<tr><td colspan=2>
{assign var=ABB2_CELL1 value="FAST FAQs"}
{assign var=ABB2_CELL2 value=#AFFLINX#}
{include file="allseer-bluebar2.tpl"}
</tr></td>
<tr><td colspan=2 align=center>
    <a target="new" href="http://{$myServer}/help.php?helpCat=ACTemail">Why did I receive an email from Affero?</a>&nbsp;&nbsp;&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=ACTregister">Why register?</a>&nbsp;&nbsp;&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=ACTprivPol">What is Affero's privacy policy?</a>&nbsp;&nbsp;&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=ACTinfo">What information is required?</a>&nbsp;&nbsp;&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=ACTwho">Who is Affero?</a>&nbsp;&nbsp;&nbsp;
    <a target="new" href="http://{$myServer}/help.php?helpCat=ACThow">How do I get the source code?</a>&nbsp;&nbsp;&nbsp;
</td></tr>
</table>

<!--  ..............  H I D D E N    F I E L D S  .................  -->

<INPUT TYPE=hidden name=regFormValidate value="1">
<INPUT TYPE=hidden name=m value="{$NewUser->Email}">
<INPUT TYPE=hidden name=ac value="{$NewUser->authString}">
<INPUT TYPE=hidden name=ut value="{$NewUser->activationType}">
</FORM>

{include file="footer.tpl"}

