<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!--  $Name: ORG-TEST $, $Id: user-history-help.tpl,v 1.2 2002/09/02 21:34:04 leed Exp $--></td>
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{assign var=myServer value=$smarty.server.HTTP_HOST}
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
                 
  <meta name="DESCRIPTION" content="Affero FAQs">
                  
  <meta name="KEYWORDS" content="affero, faq, help, volunteer, patron, rate, donate, donation">
  <title>AFFERO HELP AND HOW-TO'S</title>
    
</head>
                       <body bgcolor="#ffffff" text="#000000" link="#0000ff" vlink="#800080" alink="#ff0000">
<a name="helptop"></a>
<table width="100%" cellpadding="0" cellspacing="0" border="0">
  <tbody>
    <tr>
      <td align="Left" colspan="4"> &nbsp;</td>
    </tr>
    <tr>
      <td colspan="4"><br>
    </tr>
    <tr bgcolor="#999999">
      <td width="100%" align="Left"><b>MEMBER HISTORY FAQs</b></td>
    </tr>
    <tr>
      <td colspan="4">&nbsp;</td>
    </tr>
  </tbody>
</table>
<center>
<form method="Get" action="help.php">
  <div align="Center"> OTHER FAQ'S:             
  <select name="helpFormSel">
  <option value="GNL">General FAQs</option>
  <option value="GNLwhoallseer">--Who is Affero?</option>
  <option value="GNLcost">--Does it cost anything to join?</option>
  <option value="GNLwhatmail">--How do I get additional support?</option>
  <option value="GNLwhatbenef">--What are beneficiaries?</option>
  <option value="GNLmla">--I am a mailing list administrator. How can I offer
  this service to my subscribers?</option>
  <option value="GNLnpo">--I am a Non Profit Organization.  How can I enable
  donations to my organization?</option>
  <option value="GNLhowedit">--How do I edit my member preferences?</option>
  <option value="GNLforgotpass">--I forgot my username and/or password, what
  do I do?</option>
  <option value="JS">Join FAQ's</option>
  <option value="JSprivpol">--What is Affero's privacy policy?</option>
  <option value="JSinfo">--What information is required?</option>
  <option value="JSwho">--Who is Affero?</option>
  <option value="JShow">--How do I get the source code?</option>
  <option value="LG">Login FAQ's</option>
  <option value="LGprivpol">--What is Affero's privacy policy?</option>
  <option value="LGinfo">--What information is required?</option>
  <option value="LGwho">--Who is Affero?</option>
  <option value="LGhow">--How do I get the source code?</option>
  <option value="RM">Rate Volunteer Fast FAQs</option>
  <option value="RMfeedback">--Why provide ratings and comments?</option>
  <option value="RMwhydonate">--Why donate?</option>
  <option value="RMwhodonate">--Who can donate?</option>
  <option value="RMprivacy">--What is Affero's privacy policy?</option>
  <option value="RMwhatinfo">--What information is required?</option>
  <option value="RMwhosallseer">--Who is Affero?</option>
  <option value="RMwhoscharities">--Who chose the charities?</option>
  <option value="RMhowgetsrc">--How do I get the source code?</option>
  <option value="EP">Update Volunteer Preferences Fast FAQs</option>
  <option value="EPwhynotify">--Why should I be notified?</option>
  <option value="EPwhyaddemail">--Why should I add email addresses</option>
  <option value="EPwhyprofile">--Why should I add disbursement profiles?</option>
  <option value="EPwhatpriv">--What is Affero's privacy policy?</option>
  <option value="EPwhyselect">--Why should I select a default disbursement
  profile?</option>
  <option value="EPwhylink">--Why should I add a link in my email sig or
web page?</option>
  <option value="EPhowcancel">--What if I no longer want to be a Volunteer?</option>
  <option value="EPhowsource">--How do I get the source code?</option>
  <option value="EE">Volunteer Email Edit Fast FAQs</option>
  <option value="EEwhyactivate">--Why do I need to activate each address?</option>
  <option value="EEwhyremove">--Why should I remove an address?</option>
  <option value="EEwhyadd">--Why should I add other email addresses?</option>
  <option value="EEhowsource">--How do I get the source code?</option>
  <option value="ACT">Activate Account Fast FAQs</option>
  <option value="ACTemail">--Why did I receive an email from Affero?</option>
  <option value="ACTregister">--Why register?</option>
  <option value="ACTinfo">--What information is required?</option>
  <option value="ACTwho">--Who is Affero?</option>
  <option value="ACTprivPol">--What is Affero's privacy policy?</option>
  <option value="ACThow">--How do I get the source code?</option>
  <option value="CP">Update Patron Profile Fast FAQs</option>
  <option value="CPwhynotify">--Why should I be notified?</option>
  <option value="CPwhyaddemail">--Why should I add email addresses?</option>
  <option value="CPwhyprovidebill">--Why should I provide billing information?</option>
  <option value="CPwhatpriv">--What is Affero's privacy policy?</option>
  <option value="CPwhycredit">--Why do I need to provide credit card information
  each time I provide a gift?</option>
  <option value="CPhowprivate">--How do I keep my gifts private?</option>
  <option value="CPhowsource">--How do I get the source code?</option>
  <option value="RC">Rate Patron Fast FAQs</option>
  <option value="RCwhyfeedbk">--Why provide ratings and comments?</option>
  <option value="RCwhatpriv">--What is Affero's privacy policy?</option>
  <option value="RChowsource">--How do I get the source code?</option>
  <option value="PE">Update Pay Profile Fast FAQs</option>
  <option value="PEwhynotactive">--Why should a profile be set not active?</option>
  <option value="PEhownewbenes">--How can I suggest new beneficiaries not
  on the list?</option>
  <option value="PExhowsource">--How do I get the source code?</option>
  </select>
  <input type="submit" value="GO!"></div>
</form>
<font size="-1" color="gray"><b>&nbsp;</b></font></center>
<br>
<p><a href="#UHrepsum">Q: What is the Reputation Summary?<br>
</a>
<a href="#UHletters">Q: What do the letters and number after the Affero Profile 
 mean?<br>
</a>
<a href="#UHstatus">Q: How is the status calculated?<br>
</a>
<a href="#UHprivpol">Q: What is Affero's privacy policy?</a>
<br>
<a href="#UHwho">Q: Who is Affero?</a>
<br>
<a href="#UHhow">Q: How do I get the source code?</a>
<br>
<br>
</p>
<br>
<table border="0" cellspacing="0" cellpadding="2" width="100%">
  <tbody>
    <tr>
      <td bgcolor="#999999"><strong>Answers</strong></td>
    </tr>
  </tbody>
</table>
<blockquote>
  <table border="0" cellspacing="0" cellpadding="2" width="100%">
    <tbody>
      <tr>
        <td bgcolor="#999999"><a name="UHrepsum"><strong>What is the Reputation
Summary?</strong></a>
        </td>
      </tr>
      <tr>
        <td>
        <blockquote>
          <p>The Reputation Summary is a snapshot of the activity the Affero
member has had on the Affero system.&nbsp; It reflects the average rating
he has received, average rating he has given to others, total donations he
has made and total donations he has inspired. <br>
          <a href="#helptop">Click here to return to top</a>
          <br>
          </p>
          </blockquote>
          </td>
        </tr>
      </tbody>
    </table>
    <table border="0" cellspacing="0" cellpadding="2" width="100%">
      <tbody>
        <tr>
          <td bgcolor="#999999"><a name="UHletters"><strong>What do the letters
and numbers after the Affero profile mean?</strong></a>
          </td>
        </tr>
        <tr>
          <td>
          <blockquote>
            <p>An Affero member can be both a Volunteer offering expertise
and advice and a Patron providing feedback and donations on behalf of those that have
helped him.&nbsp; The number/letter combination is a display of the rating/donation
levels for that Affero member representing the actions of that member as
either a Patron or a Volunteer.&nbsp; If a member has not received feedback as one or the other, then inactivity (or lack of information)
associated with that role is marked with an asterisk (*).&nbsp;&nbsp;&nbsp;
            <br>
&nbsp;<br>
            <u><b>Rating Levels</b></u>:<br>
* = No Activity<br>
1 = Useless<br>
2 = Neutral <br>
3 = Valuable <br>
4 = Very Valuable <br>
5 = Priceless <br>
            <br>
            <u><b>Donation Levels</b></u>:<br>
* = No or Private Activity<br>
A = $1-5<br>
B = $6-10<br>
C = $11-20 <br>
D = $21-40 <br>
E = $41-80 <br>
F = $81-160 <br>
G = $161-320<br>
H = $321-640 <br>
I = $641-1280 <br>
J = $1281-2560 <br>
K = $2561-5120 <br>
(L-Z)...<br>
&nbsp;<br>
An example is 5C5F5 &#8211;<br>
            <br>
            <b>The first character</b> &#8211; a numeric - represents the average
rating the Affero member has received for his patronage.&nbsp; This is how
others have rated him as a Patron.&nbsp; This is the result of the Affero
member&#8217;s actions as a Patron.<br>
&nbsp;<br>
            <b>The second character</b> &#8211; an alpha &#8211; represents the total
dollar amount in donations that the Affero member has provided to others.&nbsp;
This is the result of the Affero member&#8217;s giving history as a Patron.<br>
            <br>
            <b>The third character</b> &#8211; a numeric &#8211; represents the average
rating the Affero member has received for his volunteerism.&nbsp; This is
how others have rated him as a Volunteer.&nbsp; This is the result of the
Affero member&#8217;s actions as a Volunteer.<br>
            <br>
            <b>The fourth character</b> &#8211; an alpha &#8211; represents the total
dollar amount in donations others have donated on behalf of the Affero member.&nbsp;
This is the result of the Affero member&#8217;s funds raised as a Volunteer.<br>
            <br>
            <b>The fifth character</b> &#8211; a numeric &#8211; represents the average
rating the Affero member has made of others.&nbsp; This is how he, as a Patron,
has rated others.&nbsp; This is the result of the Affero member&#8217;s actions
as a Patron.<br>
            <br>
If any position contains an asterisk (*) &#8211; then there has been no activity<br>
            <br>
So if the profile is 5C5F5 then this would indicate the Affero member is
highly rated by others, highly rates others, has donated between $11-25 dollars
to others and has inspired others to donate $81-160 on his behalf.&nbsp;
It also shows he has highly rated the patrons that have donated to him.&nbsp;
            <br>
            <br>
            <a href="#helptop">Click here to return to top</a>
            <br>
            </p>
            </blockquote>
            </td>
          </tr>
        </tbody>
      </table>
      <table border="0" cellspacing="0" cellpadding="2" width="100%">
        <tbody>
          <tr>
            <td bgcolor="#999999"><a name="UHstatus"><strong>How is the status
calculated?</strong></a>
            </td>
          </tr>
          <tr>
            <td>
            <blockquote>
<p>The numeric characters are an AVERAGE of all the ratings made or
received by a) all members or b) members who have either received or
made a gift (this can be toggled by selecting the Reputation Filter
option just below the Affero Profile title bar).&nbsp; The alpha characters
are a TOTAL of donations made or received.<br>
              <a href="#helptop">Click here to return to top</a>
              <br>
              </p>
              </blockquote>
              </td>
            </tr>
          </tbody>
        </table>
        <table border="0" cellspacing="0" cellpadding="2" width="100%">
          <tbody>
            <tr>
              <td bgcolor="#999999"><a name="UHprivpol"><strong>What is Affero's
privacy policy?</strong></a>
              </td>
            </tr>
            <tr>
              <td>
              <blockquote>
                <p>Your username and the ratings and comments you provide 
are public  information.  Until you activate your account and provide a username 
and password, your email address will be disclosed to any member for whom 
you make a contribution.  Thereafter, your email address and other personal 
information will not be disclosed unless you choose to disclose this information 
in a public discussion list or in your username or comments.  You have the 
option to keep donation information solely between yourself, the volunteer 
and the beneficiaries.  To read the privacy policy in its entirety, please 
click           <a href="http://www.affero.com/cpp.html"> here</a>
                <br>
                <a href="#helptop">Click here to return to top</a>
                <br>
                </p>
                </blockquote>
                </td>
              </tr>
            </tbody>
          </table>
          <table border="0" cellspacing="0" cellpadding="2" width="100%">
            <tbody>
              <tr>
                <td bgcolor="#999999"><a name="UHwho"><strong>Who is Affero?</strong></a>
                </td>
              </tr>
              <tr>
                <td>
                <blockquote>
                  <p>Affero enables recognition of valuable online interactions.
   We provide the means to offer feedback and say "thank you" for support
and  information provided via ratings and monetary donations to non-profit
organizations  without disrupting the natural dialog in the community.<br>
                  <a href="#helptop">Click here to return to top</a>
                  <br>
                  </p>
                  </blockquote>
                  </td>
                </tr>
              </tbody>
            </table>
            <table border="0" cellspacing="0" cellpadding="2" width="100%">
              <tbody>
                <tr>
                  <td bgcolor="#999999"><a name="UHhow"><strong>How do I get
the source code?</strong></a>
                  </td>
                </tr>
                <tr>
                  <td>
                  <blockquote>
                    <p>At the bottom of every page in the service, you will 
see  a character "(o)". Simply click on this to get a tarball of the source.<br>
                    <a href="#helptop">Click here to return to top</a>
                    <br>
                    </p>
                    </blockquote>
                    </td>
                  </tr>
                </tbody>
              </table>
              <table width="100%" cellpadding="3" cellspacing="0" border="0">
                <tbody>
                  <tr bgcolor="#999999">
                    <td width="50%" align="Right">&nbsp;<b>POWERED BY</b><u><i>
   affero</i></u></td>
                  </tr>
                  <tr>
                    <td colspan="2" align="Center"><br>
                    </td>
                  </tr>
                </tbody>
              </table>
              </blockquote>
              </body>
              </html>
