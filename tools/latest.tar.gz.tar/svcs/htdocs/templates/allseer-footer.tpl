<!--  $Name: ORG-TEST $, $Id: allseer-footer.tpl,v 1.7 2002/09/02 21:33:32 leed Exp $  -->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
<center>
<hr noshade size=1 width=640>
<font size=-1><a href="http://{$myServer}/r/ad">How
to Add a List</a> -
<a href="http://{$myServer}/r/cp">Company Info</a>
-
<a href="http://{$myServer}/r/cy">Copyleft Policy</a> -
<a href="http://{$myServer}/r/ts">Terms
of Service</a> -
<a href="http://{$myServer}/r/cb">Contributors</a> -
<a href="http://{$myServer}/r/hr">How to Join</a>
-
<a href="http://{$myServer}/r/ao">How to Add a Beneficiary</a></font>
<p><font size=-1>Copyright &copy; 2001 Affero Inc. All rights reserved.</font>
<br><a href="http://{$myServer}/r/pv">Privacy Policy</a></form></center>
