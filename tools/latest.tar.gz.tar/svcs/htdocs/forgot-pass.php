<?php
//  $Name: ORG-TEST $, $Id: forgot-pass.php,v 1.15 2002/03/19 02:47:07 leed Exp $
////////////////////////////////////////////////////////////////////////
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
include("global.php");
require_once("allseer.UserSqlConn.php");
require_once("allseer.hasher.php");
require_once("allseer.smtpMailer.php");

//phpinfo();

/* Generate password. (i.e. jachudru, cupheki) */
function genpassword($length=6){

    srand((double)microtime()*1000000);
    $vowels = array("a", "e", "i", "o", "u");
    $cons = array("b", "c", "d", "g", "h", "j", "k", "l", "m", "n", "p", "r", "s",
                  "t", "u", "v", "w", "tr", "cr", "br", "fr", "th", "dr", "ch", "ph",
                  "wr", "st", "sp", "sw", "pr", "sl", "cl");

    $num_vowels = count($vowels);
    $num_cons = count($cons);
    for($i = 0; $i < $length; $i++){
        $password .= $cons[rand(0, $num_cons - 1)] . $vowels[rand(0, $num_vowels - 1)];
    }
    return substr($password, 0, $length);
}

$errorMessages= array();
if ($REQUEST_METHOD == "POST"){
    $conn= new UserSqlConn;
    $mailer= new smtpMailer();

    $mailArgs= array();
    $mailArgs['addy']= $formEmail;
    
    if ($newAry= $origAry= $conn->fetchUserAttrsAltEmail($formEmail)) {
        $mailArgs['user_last_prof']= $origAry['user_last_prof'];
        $mailArgs['user_login']= $origAry['user_login'];
        $mailArgs['addy']= $formEmail;
        
        if ($origAry['user_status'] != "activated") {
            $mailer->inactiveUserForgotPasswordU2($mailArgs);
             header ("Location: notice.php?code=" .
                     urlencode("Thank you. An activation email has just been sent to: {$formEmail}"));
            exit;
            
        } else {
            $h= new hasher;
            
            $newAry['user_passwd']= $h->passwordMunge($mailArgs['user_passwd']= genpassword());
            if ($conn->updateUserAttrs($origAry, $newAry)) {
                $mailer->userForgotPasswordU1($mailArgs);
                header ("Location: notice.php?code=" .
                        urlencode("Thank you. An email has just been sent to: {$formEmail}"));
                exit;

            } else {
                header ("Location: notice.php?code=" . urlencode("forgot-pass.php couldn't update user's password"));
                exit;
            }
        }
    } else {
        $errorMessages[]= "The email address you entered is not in affero's database";
    }
    
}

$smarty = new Smarty;
$smarty->assign("ErrorMessages", $errorMessages);
$smarty->display("forgot-pass.tpl");
?>
