<?php
// $Name: ORG-TEST $, $Id: rate-me.php,v 1.43 2002/10/23 22:59:03 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  TODO:  this screen barfs if no m= argument is passed on the
//         request URL.  fix this.
////////////////////////////////////////////////////////////////////////
//  get here by clicking on a "rate me" link
require("global.php");
require("allseer.ratings.php");
require_once("allseer.sessions.php");
$rateSess= new sessionRep();

////////////////////////////////////////////////////////////////////////
//  Url Arguments:
//    $r=  login of ratee
//    $m=  email address of ratee
//    $p=  pay profile
//......................................................................
//                    list related URLarguments
//  ll= mailing email address
//  ls= email subject line
//  lh= email hash identifier
//  lp= pay profile to use with this rating
////////////////////////////////////////////////////////////////////////
//  --either $r or $m must be specified.  $p specifies a payment profile
//  in a way which is very complicated to explain (see below)
//  --$ll is  a mailing list identifier; the email address to which an
//  email must be sent to be published on the list
//  --$ls is the subject line of the original email
//  --$lh is a message identifier (maybe MD5) which is trimmed to 50
//  characters and stored in the rating record
//  --$lp is a pay profile, owned by the list administrator to be
//  applied to any payment made as a result of this rating
////////////////////////////////////////////////////////////////////////
//                        profile selection
//  1. if $r exists and is active then use $r's named profile $p or, if
//     $r has no profile named $p, use $r's default
//  2. if $a exists and is active then use $a's named profile $p or, if
//     $a has no profile named $p, use $a's default
//  3. use the allseer default
////////////////////////////////////////////////////////////////////////
//phpinfo();
//echo("<br>\$GLOBALS..."); var_dump($GLOBALS);

//  at least one of {$r, $m} must be set or the $rateMe->init()
//  function will error out.
$rateMe = new rateMe;
$rateMe->FromForm= isset($rateFormValidate);
if (($msg= $rateMe->init()) != "OK") {
    // WTODO: if we can't build the rateMe object?
    header ("Location: notice.php?code=". urlencode($msg));
    exit;
}

////////////////////////////////////////////////////////////////////////
//  Form processing
if (isset($rateFormValidate)) {
    $rateMe->Value = $rateFormValue;
    $rateMe->TOS = $rateFormTOS;
    $rateMe->Categorize = $rateFormCategorize;
    $rateMe->Comment = stripslashes($rateFormComment);
    $rateMe->Login = $rateFormLogin;
    $rateMe->Password = $rateFormPassword;
    $rateMe->Email = $rateFormEmail;
    $rateMe->Tip = $rateFormTip;

    $rateMe->validateFields();
}

if (!$rateMe->validated()) {
    $smarty = new Smarty;
    $smarty->assign("RateMe", $rateMe);
    $smarty->display("rate-me.tpl");

} else {
    //  update the database here and go on to fill in payment
    //  information
    if ($finalRc= $rateMe->Finalize()) {
        if ($rateMe->Tip != 0) {
            $mySess= new sessionRep();
            $mySess->start();
            
            //  go to payment details page
            $pdArgs =
                 "re=" . urlencode($rateMe->RateeEmail) .
                 "&tip=" . urlencode($rateMe->Tip * 100) .
                 "&tip_oid=" . urlencode($rateMe->TipOID) .
                 "&dbf=1" .
                 "&pid=" . urlencode($rateMe->ProfileObj->profileID) .
                 "&cl=" . urlencode(trim($rateMe->Login));
            
            if (isset($rateMe->extEmail)) {
                $mySess->register("xm", $rateMe->extEmail);
                $mySess->save();
            }
            $pdArgs .= "&ish=" . urlencode($mySess->id);
            header ("Location: payment-details.php?$pdArgs");
            exit;
        } else {
            //  WTODO: if there is no payment on a rateme
            //         page
            header ("Location: notice.php?code=" .
                    urlencode("Thank you. Your feedback has been successfully submitted."));
            exit;
        }
    }
    //  WTODO: if rating insert fails?
    $errArgs =  urlencode("<rate-me.php> Couldn't insert rating");
    header ("Location: notice.php?code=$errArgs");
    exit;
}

?>
