<?php
//  $Name: ORG-TEST $, $Id: project.php,v 1.4 2002/03/19 02:47:07 leed Exp $
////////////////////////////////////////////////////////////////////////
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
include("global.php");


$smarty = new Smarty;
//$smarty->debugging = true;


if ($argProjName && $argProjName != ""){
    $smarty->assign("ProjName", $argProjName);
    $smarty->display("project.tpl");
    
} else {
    $smarty->display("allseer.tpl");
}

?>
