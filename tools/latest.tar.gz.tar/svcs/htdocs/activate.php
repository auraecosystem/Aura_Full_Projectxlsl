<?php
// $Name: ORG-TEST $, $Id: activate.php,v 1.11 2002/10/23 22:59:03 leed Exp $
////////////////////////////////////////////////////////////////////////
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
require_once("global.php");
require_once("allseer.newUser.php");
require_once("allseer.sessions.php");

$newUser = new newUser;
$smarty = new Smarty;

////////////////////////////////////////////////////////////////////////
/////                       URL arguments                          /////
$newUser->Email= $newUser->BarString= isset($m) ? $m : "";
$newUser->authString= isset($ac) ? $ac : "";
$newUser->activationKey = isset($k) ? $k : "";
$newUser->activationType= isset($ut) ? $ut : "";

if (!$newUser->initActivation()){
    //  WTODO:  when initialization fails
    header ("Location: notice.php?code=" .
            urlencode("activate.php <br>") .
            urlencode($newUser->Messages['initActivation']));
    exit;
}

////////////////////////////////////////////////////////////////////////
/////                         Auth Check                           /////
if ($newUser->authCheck() == "activated") {
    //  maybe activate a new email address
    if ($newUser->activationType == "email") {
        //echo("<br>do an email activation...");
        if (isset($u) && isset($h)) {   
            $newUser->compatibleEmailActivate();
        }
    }
    header ("Location: index.php");
    exit;

} elseif ($newUser->authCheck() == "needs-auth") {
    header ("Location: notice.php?code=" . urlencode("activate.php authCheck() oddity"));
    exit;

////////////////////////////////////////////////////////////////////////
/////                         Activation                           /////
} elseif  ($newUser->authCheck() == "auth-complete" || $newUser->authCheck() == "inactivated") {
    if (isset($regFormValidate)) {
        $newUser->Login = $regFormLogin;
        $newUser->Password1 = $regFormPassword1;
        $newUser->Password2 = $regFormPassword2;
        $newUser->TOS= $regFormTOS;
        $newUser->validateActivationFields();
    }

    if (!$newUser->validated()) {
        $smarty = new Smarty;
        $smarty->assign("NewUser", $newUser);
        $smarty->display("activate.tpl");

    } elseif (!$newUser->finalizeActivation()) {
        //  WTODO:  when final activation fails
        header ("Location: notice.php?code=" . urlencode("activate.php \$newUser->finalizeActivation() Failure"));
        exit;

    } else {
        //  redirect to the client profile or to the expert
        //  profile depending on what kind of user is being
        //  activated.
        //  start a session for this user.  log the user on.
        $mySess= new sessionRep;
        
        $mySess->start($newUser->Login);
        $mySess->register("authLogin", TRUE);
        $mySess->save();
        $mySess->destroy();
        
        header("Location: " . $newUser->activateUrl());
        exit;
    }
}

header ("Location: index.php");
exit;
?>