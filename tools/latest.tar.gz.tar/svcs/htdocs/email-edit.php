<?php
//  $Name: ORG-TEST $, $Id: email-edit.php,v 1.6 2002/03/19 02:47:07 leed Exp $
////////////////////////////////////////////////////////////////////////
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
require_once("global.php");
require_once("allseer.editAltEmail.php");
require_once("allseer.sessions.php");

if (!isset($u)) {
     header("Location: notice.php?code=" . urlencode("(eMedit1) Your request cannot be served."));
}

$mySess = new sessionRep;
$em_editor = new em_editor;

//  start a session for this user
$mySess->start($u);
$mySess->authorize($u);

$em_editor->fromForm = (isset($FormValidate));
$em_editor->init($u);

if (isset($FormValidate)) {
    //  move form fields into the edit object
    $em_editor->validateFields();
    
    //  if the database update goes ok then re initialise this screen
    //  and start all over
    if ($em_editor->validated()) {
        if ($em_editor->Finalize()) {
            header("Location: email-edit.php?u=". urlencode($u));
            exit;   
        }
    }
}
$smarty = new Smarty;

$smarty->assign("eMedit", $em_editor);
$smarty->display("email-edit.tpl");
?>
