<?php
// $Name: ORG-TEST $, $Id: join.php,v 1.15 2002/10/23 22:59:03 leed Exp $
////////////////////////////////////////////////////////////////////////
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
//  this will eventually be generalized to handle new clients and
//  new experts.
require_once("global.php");
require_once("allseer.newUser.php");
require_once("allseer.sessions.php");

global $authLogin, $backTo;

$newUser = new newUser;
$smarty = new Smarty;
$mySess= new sessionRep;

////////////////////////////////////////////////////////////////////////
//  URL arguments
$lg = (isset($lg)) ? $lg : FALSE;    //  lg=1 requests a login screen
$ln = (isset($ln)) ? $ln : "";       //  ln=xxx prefills a login name
$newUser->init($lg, $ln);

////////////////////////////////////////////////////////////////////////
//  Session
$mySess->start($ln);
if (isset($backUrl)) {
    $mySess->register("backTo", $backUrl);
}   
if (!$mySess->is_registered("authLogin")) {
    $mySess->register("authLogin", FALSE);
}
$mySess->save();
$mySess->destroy();

////////////////////////////////////////////////////////////////////////
//  Validate Form fields if present.  They won't be present on the
//  first redirect to this script.
if (isset($regFormValidate)) {
    
    $newUser->Email = $regFormEmail;
    if ($newUser->loginScreen) {
        
        if ($newUser->Login != $regFormLogin && $newUser->dbConnection->loginExists($regFormLogin)) {
            $newUser->init(1, $regFormLogin);
        }
        $newUser->Password = $regFormPassword;
        $newUser->Login= $regFormLogin;
        $newUser->validateLoginFields();
        
    } else {
        $newUser->validateJoinFields();
    }
}

if ($newUser->validated()) {
    if ($newUser->loginScreen) {
        //  login screen validation is correct
        $mySess->start($newUser->Login);
        $mySess->register("authLogin", TRUE);
        $mySess->save();
        
        $loc= isset($mySess->sdata['backTo']) ? $mySess->sdata['backTo'] :  $newUser->nextCgi();
        header ("Location: $loc");
        exit;
        
    } elseif ($newUser->dbInsert()) {
        //  db insert succedes
        header ("Location: notice.php?code=" .
                urlencode("Thank you. An activation email has just been sent to: {$newUser->Email}"));
        exit;

    } else {
        //  db insert fails
        header ("Location: notice.php?code=" . urlencode("Join.php dbInsert() Failure"));
        exit;
    }
    
} else {
    
    $smarty = new Smarty;
    $smarty->assign("NewUser", $newUser);
    
    if ($newUser->loginScreen) {
        $smarty->display("login.tpl");

    } else {
        $smarty->display("join.tpl");
    }

}
?>
