<?php
//  $Name: ORG-TEST $, $Id: help.php,v 1.9 2002/09/02 21:31:05 leed Exp $
////////////////////////////////////////////////////////////////////////
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
include("global.php");

$helpSelectorAry= array(
    "ACT" =>   "activate-help.tpl",
    "GNL" =>   "general-help.tpl",
    "RM" =>    "rate-me-help.tpl",
    "RC" =>    "rate-client-help.tpl",
    "EP" =>    "expert-profile-help.tpl",
    "PD" =>    "pay-detail-help.tpl",
    "CP" =>    "client-profile-help.tpl",
    "EE" =>    "email-edit-help.tpl",
    "UH" =>    "user-history-help.tpl",
    "PE" =>    "pay-profile-edit-help.tpl",
    "LG" =>    "login-help.tpl",
    "HH" =>    "html-help.tpl",
    "JS" =>    "join-help.tpl",
    "CP" =>    "client-profile-help.tpl"
    );


if (isset($helpTpl)) {
    $smarty= new Smarty();
    $smarty->display($helpTpl);
    exit;
    
} else if (isset($helpCat)) {
    $myHelpSel= $helpCat;
    
} else if (isset($helpFormSel)) {
    $myHelpSel= $helpFormSel;
    
} else {
    $myHelpSel= "none";
}        
    
preg_match("/[A-Z]*/", $myHelpSel, $matches);
$myTplSelector= $matches[0];
$myHelpScreen= isset($helpSelectorAry[$myTplSelector]) ? $helpSelectorAry[$myTplSelector] : "general-help.tpl";

$urlStr= "help.php?helpTpl=" . urlencode($myHelpScreen);
if ($myHelpSel != "noSuchFragment"){
    $urlStr .= "#" . urlencode($myHelpSel);
}
header("Location: $urlStr");
exit;

?>
