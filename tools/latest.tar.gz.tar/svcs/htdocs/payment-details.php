<?php
// $Name: ORG-TEST $, $Id: payment-details.php,v 1.32 2002/10/11 17:53:17 leed Exp $
////////////////////////////////////////////////////////////////////////
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
//  collect details related to a payument
require_once("global.php");
require_once("allseer.payDetail.php");
require_once("allseer.sessions.php");
require_once("allseer.hasher.php");

$payDetail = new payDetail;
$smarty = new Smarty;

////////////////////////////////////////////////////////////////////////
//  process URL arguments
$re = (isset($re)) ? $re : "";         //  exper e-mail address
$cl = (isset($cl)) ? $cl : "";         //  client login id
$dbf = (isset($dbf)) ? $dbf : 0;       //  client fields from databnase

if (($code= $payDetail->init($re, $cl, $dbf)) != "OK") {
    // WTODO: if we can't build the payDetail object?
    header ("Location: notice.php?code=" . urlencode($code));
    exit;
}

//  set the tip ammount and the tip oid from arguments
if ($payDetail->TipOID= (isset($tip_oid)) ? $tip_oid : FALSE) {
    $payDetail->Tip= ($payDetail->TipOID) ? (isset($tip) ? $tip : 0) : 0;
}
//  pid id the identifier associated with the pay profile
//  for this transaction.
$payDetail->pid= (isset($pid)) ? $pid : FALSE;

//  process URL arguments done
////////////////////////////////////////////////////////////////////////

if (isset($FormValidate)) {
    //var_dump($payDetail);
    $payDetail->validateFields();
}

if (!$payDetail->validated()) {
    include("allseer.arrayLoader.php");
    $arrayLoader = new arrayLoader;

    //echo("Country array..."); $c=$arrayLoader->loadCountryArray(); var_dump($c);
    $smarty->assign("Countries", $arrayLoader->loadCountryArray());
    $smarty->assign("US_States", $arrayLoader->loadUsStatesArray());
    $smarty->assign("PayDetail", $payDetail);
    $smarty->display("pay-detail.tpl");

} else {
    //  update the database here for payment details
    //  and if there was a tip, then do a secure
    //  transaction to trust commerce
    if ($payDetail->dbUpdate()) {
        if ($payDetail->Tip && $payDetail->Tip > 0) {
            $amt= sprintf("%3d.%02d", $payDetail->Tip / 100, $payDetail->Tip % 100);
            $profAry= serialize($payDetail->makeProfileAry());

            $sessAry= array();
            $sessAry['demo']= $payDetailDemo;
            $sessAry['first_name']= $payDetail->First;
            $sessAry['last_name']= $payDetail->Last;
            $sessAry['custemail']= $payDetail->dbUserAttrs['user_fwd_email'];
            $sessAry['company']= $payDetail->Company;
            $sessAry['address']= $payDetail->Address1;
            $sessAry['address2']= $payDetail->Address2;
            $sessAry['phone']= $payDetail->Phone;
            $sessAry['city']= $payDetail->City;
            $sessAry['zip']= $payDetail->Zip;
            $sessAry['state']= $payDetail->State;
            $sessAry['country_id']= $payDetail->Country;
            $sessAry['fax']= $payDetail->Fax;
            $sessAry['ticket']= $payDetail->makeTicket();
            $sessAry['amount']= $amt;
            $sessAry['serialProfAry']= $profAry;
            $sessAry['connectArgs']= $payDetail->dbConnectionArgs();
            $sessAry['tip_oid']= $payDetail->TipOID;
            
            //  start a session for the credit args
            $mySess= new sessionRep;
            $h= new hasher;
            
            $mySess->starth($payDetail->ish);
            
            if ($mySess->is_registered("xm")) {
                $sessAry['xm']= $mySess->sdata["xm"];
            }
            $mySess->register("creditArgs", $sessAry);
            //echo("<br>sessAry...");var_dump($sessAry);
            //echo("<br><br>sdata...");var_dump($mySess->sdata);
            $mySess->save();
            
            $hashedCargs= $h->cloak($payDetail->dbConnectionArgs());
            
            //  pass the id and the hash over to the vault
            $payArgs=
                 "i=" . urlencode($mySess->id) .
                 "&h=" . urlencode($mySess->sdHash) .
                 "&ca=" . urlencode($hashedCargs);
            

            $sStr= $hashedCargs . $mySess->id . $PayDetailsMunger;
            $sArgs= md5($sStr);

            //echo("<br><br>sStr..."); var_dump($sStr);
            //echo("<br><br>sArgs..."); var_dump($sArgs);
            
            $payArgs .= "&s=" . $sArgs;
            
            $mySess->destroy();
            
            header("Location: https://{$paySecureHost}/pay.php?$payArgs");
            exit;

        }
    }
    //  WTODO: if payment detail update fails
    //header ("Location: allseer-home.php");
    //$smarty = new Smarty;
    $smarty->display("debug-show.tpl");
    header ("Location: index.php");
    exit;
}

?>
