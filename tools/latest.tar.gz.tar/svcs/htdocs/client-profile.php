<?php
// $Name: ORG-TEST $, $Id: client-profile.php,v 1.17 2002/03/19 02:47:07 leed Exp $
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  TODO:  this screen barfs if no m= argument is passed on the
//         request URL.  fix this.
////////////////////////////////////////////////////////////////////////
//  get here by clicking on a "rate me" link
//
require_once("global.php");
require_once("allseer.clientProfile.php");
require_once("allseer.sessions.php");

$clientProfile = new clientProfile;
$mySess= new sessionRep;

//  process URL arguments
if (!isset($u)){
    header ("Location: notice.php?code=" . urlencode("(cProf1) Unable to serve request"));
    exit;
}

//  start a session for this user
$mySess->start($u);
$mySess->authorize($u);

if (!$clientProfile->init_private($u)) {
    // WTODO: if we can't build the clientProfile object?
    header ("Location: notice.php?code=" . urlencode("client-profile.php: can't build the clientProfile object"));
    exit;
}

if (isset($FormValidate)) {
    $clientProfile->validateFields();
}

if (!$clientProfile->validated()) {
    include("allseer.arrayLoader.php");
    $arrayLoader = new arrayLoader;
    $smarty = new Smarty;

    $smarty->assign("ClientProfile", $clientProfile);
    $smarty->assign("Countries", $arrayLoader->loadCountryArray());
    $smarty->assign("US_States", $arrayLoader->loadUsStatesArray());
    $smarty->display("client-profile.tpl");

} else {
    //  update the database here
    $dbRc = $clientProfile->dbMaint();
    if (!$dbRc) {
        header ("Location: client-profile.php?u=" . urlencode($clientProfile->uid));
        //header ("Location: notice.php?code=" . urlencode("client.php site 2: database update failure"));
        exit;
    }
    if ($clientProfile->deActivated()) {
        header ("Location: index.php");
        //header ("Location: index.php");
        exit;
    }
    
    //  WTODO: after client profile is updated?
    header ("Location: client-profile.php?u=" . urlencode($clientProfile->uid));
    //header ("Location: index.php");
    exit;

}
header ("Location: notice.php?code=" . urlencode("**client-profile.php line 57**"));
exit;

?>
