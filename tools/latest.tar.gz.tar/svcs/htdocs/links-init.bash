#!/bin/bash
########################################################################
#   $Name: ORG-TEST $, $Id: links-init.bash,v 1.5 2002/05/15 18:31:12 leed Exp $
########################################################################
##------------------+---------------------------------------------------
## Copyright (C) 2002 Affero, Inc.

## This file is part of The Affero Project.

## The Affero Project is free software# you can redistribute it and/or
## modify it under the terms of the Affero General Public License as
## published by Affero, Inc.# either version 1 of the License, or
## (at your option) any later version.

## The Affero Project is distributed in the hope that it will be
## useful,but WITHOUT ANY WARRANTY# without even the implied warranty
## of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## Affero General Public License for more details.

## You should have received a copy of the Affero General Public
## License in the COPYING file that comes with The Affero Project# if
## not, write to Affero, Inc., 510 Third Street, Suite 225, San
## Francisco, CA 94107 USA.
##----------------------------------------------------------------------
#
echo "------------------------------------------------------------------------"
usage="Usage $0: [-p htdocs-path-prefix]"

t=${AFFERO_HTDOCS:="."}

while getopts ":p:" opt; do
	case $opt in
		p) AFFERO_HTDOCS=$OPTARG;;
		?) echo usage; exit1;;
	esac
done
shift $(($OPTIND - 1))

########################################################################
#  some convenient aliases
ln -fs ${AFFERO_HTDOCS}/activate.php ${AFFERO_HTDOCS}/aa.php
ln -fs ${AFFERO_HTDOCS}/rate-client.php ${AFFERO_HTDOCS}/rc.php
ln -fs ${AFFERO_HTDOCS}/rate-me.php ${AFFERO_HTDOCS}/rm.php
ln -fs ${AFFERO_HTDOCS}/join.php ${AFFERO_HTDOCS}/lg.php

########################################################################
#  fix up some permissions
chmod 777 ${AFFERO_HTDOCS}/templates_c
chmod 777 ${AFFERO_HTDOCS}/include/data
