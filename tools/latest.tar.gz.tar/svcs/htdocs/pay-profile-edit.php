<?php
//  $Name: ORG-TEST $, $Id: pay-profile-edit.php,v 1.8 2002/03/19 02:47:07 leed Exp $
////////////////////////////////////////////////////////////////////////
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
require_once("global.php");
require_once("allseer.sessions.php");
require_once("allseer.editPayProf.php");
//phpinfo();

$pp_editor = new pp_editor;
$mySess= new sessionRep;

//  process URL arguments
$pp_editor->fromForm = (isset($FormValidate));

//  start a session for this user
$mySess->start($u);
$mySess->authorize($u);

$pp_editor->init($u);

if (isset($FormValidate)) {
    //  move form fields into the edit object
    //var_dump($HTTP_POST_VARS);
    while (list($var, $value) = each($HTTP_POST_VARS)) {
        if (!strncmp("FormPactiv_", $var, strlen("FormPactiv_"))){
            list($i)= sscanf($var, "FormPactiv_%d");
            $pp_editor->setActiv($i, $value);
        }
    }
    $pp_editor->validateFields();

    //  if the database update goes ok then re initialise this screen
    //  and start all over
    if ($pp_editor->validated()) {
        $pp_editor->dbUpdate();
        header("Location: expert-profile.php?u=$u");
        exit;
    }
}

////////////////////////////////////////////////////////////////////////
//                 select the view profile
//
//     --as the one which was clicked on
//     --or if none was clicked then the one which was
//        set when the update button was last clicked
//     --or if none was set then the one which
//        was the first one retrieved from db
if (isset($v)){
    $pp_editor->setView($v);

} else if (isset($vn) && isset($va)) {
    $pp_editor->viewProfName= $vn;
    $pp_editor->viewProfileSer= urldecode($va);
    $pp_editor->viewProfile= unserialize($pp_editor->viewProfileSer);

} else {
    $pp_editor->setView(1);
}

$smarty = new Smarty;

$smarty->assign("PPedit", $pp_editor);
$smarty->display("pay-profile-edit.tpl");
?>
