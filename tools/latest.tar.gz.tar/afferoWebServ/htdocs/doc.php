<?php
//  $Name: ORG-TEST $, $Id: doc.php,v 1.3 2002/11/22 22:12:37 leed Exp $
///////////////////////////////////////////////////////////////////////
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------

function file_get_contents($filename, $use_include_path = 0) {
  $fd = fopen ($filename, "rb", $use_include_path);
  $contents = fread($fd, filesize($filename));
  fclose($fd);
  return $contents;
}
$docfile= $_GET["file"];

$str = nl2br(preg_replace("/ /", "&nbsp;", htmlentities(file_get_contents("../doc/$docfile"))));

echo("<br><br> $str");
?>

