<!--  $Name: ORG-TEST $, $Id: top-beneficiariesXml.tpl,v 1.3 2002/12/02 22:17:36 leed Exp $-->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free    software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{assign var=myServer value=$smarty.server.HTTP_HOST}

<beneficiaryHofTable>
<tableHeaders>
    <tableTitle>{$TopBeneficiaries->tableTitle}</tableTitle>
    <tableTitle>(by Volunteer choice)</tableTitle>
    <tableDateRange>{$TopBeneficiaries->dpyDateRange}</tableDateRange>
    <tableColumns>
    <col>Organization</col>
    <col>Supporters</col>
    </tableColumns>
</tableHeaders>

<tableData>
{strip}
{section name=i loop=$TopBeneficiaries->benniesAry}
    {assign var=org value=$TopBeneficiaries->benniesAry[i].name}
    {assign var=web value=$TopBeneficiaries->benniesAry[i].web}
    {/strip}
    <hofTableEntry>
        <Organization href="{$web}">{$org}</Organization>
        <Count>{$TopBeneficiaries->benniesAry[i].count}</Count>
    </hofTableEntry>
{/section}
</tableData>
</beneficiaryHofTable>

