<!--  $Name: ORG-TEST $, $Id: top-patronsXml.tpl,v 1.4 2002/12/12 21:00:44 leed Exp $-->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{assign var=myServer value=$smarty.server.HTTP_HOST}

<patronHofTable>
<tableHeaders>
    <tableTitle>{$TopPatrons->tableTitle} {$TopPatrons->tableSubTitle}</tableTitle>
    <tableDateRange>{$TopPatrons->dpyDateRange}</tableDateRange>
    <tableColumns>
    <col>Member</col>
    <col>{$TopPatrons->dataHeader}</col>
    </tableColumns>
</tableHeaders>

<tableData>
    {if $TopPatrons->tableRows > 0}
        {section name=i loop=$TopPatrons->patronsAry}
        {assign var=m value=$TopPatrons->patronsAry[i].login|regex_replace:"/ +/":""}

        <hofTableEntry>
            <Member href="http://{$TopPatrons->historyHost}/user-history.php?u={$m}">{$m}</Member>
            <{$TopPatrons->dataHeader}>{$TopPatrons->patronsAry[i].pdat}</{$TopPatrons->dataHeader}>
        </hofTableEntry>
        {/section}
    {else}
        <hofTableEntry>
        <text>
        During the period specified there are no {$TopPatrons->emptyTableText} on record.
        </text>>
        </hofTableEntry>
    {/if}    
</tableData>
</patronHofTable>
