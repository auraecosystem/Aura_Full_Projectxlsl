
<!--  $Name: ORG-TEST $, $Id: top-patrons.tpl,v 1.6 2002/12/12 21:00:44 leed Exp $-->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{assign var=myServer value=$smarty.server.HTTP_HOST}
{assign var=tabWidth value="153"}

<!-- //////////////  HTML GENERATION STARTS HERE  ////////////////// -->
<table bgcolor="#486591" width={$tabWidth}  border="0" cellspacing="0" cellpadding="2">
<tbody>
    <tr>
      <td valign="Top">
      <div align="Center"><font color="#ffffff">
          <b>{$TopPatrons->tableTitle}<br><small>{$TopPatrons->tableSubTitle}<br>{$TopPatrons->dpyDateRange}</small></b><br>
      </font></div>
      </td>
    </tr>
</tbody>
</table>

<table bgcolor="#cfd9ff" width={$tabWidth} border="0" cellspacing="0" cellpadding="2">
<tbody>
    <tr>
      <td valign="Top" width="75">
      <div align="Left"><font color="#000000"><small>Member</small></font></div></td>
      <td valign="Top" width="75">
      <div align="Right"><font color="#000000"><small>{$TopPatrons->dataHeader}</small></font></div></td>
    </tr>
</tbody>
</table>

<table cellpadding="0" cellspacing="0" border="0" width={$tabWidth} bgcolor="#e6e6e6">
<tbody>
    {if $TopPatrons->tableRows > 0}
        {section name=i loop=$TopPatrons->patronsAry}
            {assign var=log value=$TopPatrons->patronsAry[i].login}
            <tr>
            <td valign="Top" width="130">
                <small><a href="http://{$TopPatrons->historyHost}/user-history.php?u={$log}">{$log}</a><br></small></td>

            <td valign="Top" width="20" align="right"><small>{$TopPatrons->patronsAry[i].pdat}</small><br></td>
            </tr>
        {/section}
    {else}
        <tr><td>
        <font size=-1><i>
        During the period specified there are no {$TopPatrons->emptyTableText} on record.
        </i></font>
        <td><tr>
    {/if}    
</tbody>
</table>


