
<!--  $Name: ORG-TEST $, $Id: top-volunteers.tpl,v 1.6 2002/11/26 22:36:45 leed Exp $-->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{assign var=myServer value=$smarty.server.HTTP_HOST}
{assign var=tabWidth value="153"}

<!-- //////////////  HTML GENERATION STARTS HERE  ////////////////// -->
<table bgcolor="#486591" width={$tabWidth} border="0" cellspacing="0" cellpadding="2">
<tbody>
    <tr>
      <td valign="Top">
      <div align="Center"><font color="#ffffff">
          <b>{$TopVolunteers->tableTitle}<br><small>{$TopVolunteers->tableSubTitle}<br>{$TopVolunteers->dpyDateRange}</small></b><br>
      </font></div>
      </td>
    </tr>
</tbody>
</table>

<table bgcolor="#cfd9ff" width={$tabWidth} border="0" cellspacing="0" cellpadding="2">
<tbody>
    <tr>
      <td valign="Top" width="75">
      <div align="Left"><font color="#000000"><small>Member</small></font></div></td>
      <td valign="Top" width="75">
      <div align="Right"><font color="#000000"><small>{$TopVolunteers->dataHeader}</small></font></div></td>
    </tr>
</tbody>
</table>

<table cellpadding="0" cellspacing="0" border="0" width={$tabWidth} bgcolor="#e6e6e6">
<tbody>
    {if $TopVolunteers->tableRows > 0}
        {section name=i loop=$TopVolunteers->volunteersAry}
            {assign var=log value=$TopVolunteers->volunteersAry[i].login}
            <tr>
            <td valign="Top" width="130">
                <small><a href="http://{$TopVolunteers->historyHost}/user-history.php?u={$log}">{$log}</a><br></small></td>

            <td valign="Top" width="20" align="right"><small>{$TopVolunteers->volunteersAry[i].xdat}</small><br></td>
            </tr>
        {/section}
    {else}
         <tr><td>
         <font size=-1><i>
        During the period specified there are no {$TopVolunteers->emptyTableText} on record.
        </i></font>
        <td><tr>    
    {/if}
</tbody>
</table>


