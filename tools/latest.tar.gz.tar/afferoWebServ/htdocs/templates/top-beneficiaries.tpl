<!--  $Name: ORG-TEST $, $Id: top-beneficiaries.tpl,v 1.4 2002/09/05 19:43:58 leed Exp $-->
<!-- //////////////////////////////////////////////////////////////// -->
<!-- Copyright (C) 2002 Affero, Inc.                                  -->
<!--                                                                  -->
<!-- This file is part of The Affero Project.                         -->
<!--                                                                  -->
<!-- The Affero Project is free    software/ you can redistribute it     -->
<!-- and/or modify it under the terms of the Affero General Public    -->
<!-- License as published by Affero, Inc./ either version 1 of the    -->
<!-- License, or (at your option) any later version.                  -->
<!--                                                                  -->
<!-- The Affero Project is distributed in the hope that it will be    -->
<!-- useful,but WITHOUT ANY WARRANTY/ without even the implied        -->
<!-- warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR          -->
<!-- PURPOSE.  See the Affero General Public License for more         -->
<!-- details.                                                         -->
<!--                                                                  -->
<!-- You should have received a copy of the Affero General Public     -->
<!-- License in the COPYING file that comes with The Affero           -->
<!-- Project/ if not, write to Affero, Inc., 510 Third Street,        -->
<!-- Suite 225, San Francisco, CA 94107 USA.                          -->
<!-- //////////////////////////////////////////////////////////////// -->
{assign var=myServer value=$smarty.server.HTTP_HOST}
{assign var=tWidth value="153"}

<!-- //////////////  HTML GENERATION STARTS HERE  ////////////////// -->
<table bgcolor="#486591" width={$tWidth} border="0" cellspacing="0" cellpadding="0">
<tbody>
    <tr>
      <td valign="Top">
      <div align="Center"><font color="#ffffff">
          <b>{$TopBeneficiaries->tableTitle}<br><small>(by Volunteer choice)<br>{$TopBeneficiaries->dpyDateRange}</small></b><br>
      </font></div>
      </td>
    </tr>
</tbody>
</table>

<table bgcolor="#cfd9ff" width={$tWidth} border="0" cellspacing="0" cellpadding="0">
<tbody>
    <tr>
      <td valign="Top" width="75">
      <div align="Left"><font color="#000000"><small>Organization</small></font></div></td>
      <td valign="Top" width="75">
      <div align="Right"><font color="#000000"><small>Supporters</small></font></div></td>
    </tr>
</tbody>
</table>

<table bgcolor="#e6e6e6" width={$tWidth} border="0" cellspacing="0" cellpadding="0">
<tbody>
    {section name=i loop=$TopBeneficiaries->benniesAry}
        {assign var=org value=$TopBeneficiaries->benniesAry[i].name}
        {assign var=web value=$TopBeneficiaries->benniesAry[i].web}
        <tr>
        <td valign="Top" width="130"><a href="{$web}"><small>{$org}</small></a></td>
        <td valign="Top" width="20" align="right"><small>{$TopBeneficiaries->benniesAry[i].count}</small></td>
        </tr>
    {/section}
</tbody>
</table>


