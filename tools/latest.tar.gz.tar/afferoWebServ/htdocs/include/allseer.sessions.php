<?php
// --------------------------------------------------------------------
//  $Name: ORG-TEST $, $Id: allseer.sessions.php,v 1.23 2002/09/02 21:34:49 leed Exp $
// --------------------------------------------------------------------
//                sessioncookie: session management
//
//  this code is way ripped off from phpClasses.com.  it is based on
//  work done by these people
//
//        Danny Heijl - Danny.Heijl@cevi.be, aug 1999
//        Christoph Kassen - php@chkassen.de, nov 2000
//        Thomas Du - konga.geo@yahoo.com, Jan. 2000
//
//  see the cvs log  for further details.  It has been modified
//  to use the allseer database classes.  This class should be
//  instantiated inn the CGI scripts
//----------------------------------------------------------------------
//     D A N G E R    D A N G E R    D A N G E R    D A N G E R
//----------------------------------------------------------------------
//  this object does it's own database access.
require_once("allseer.hasher.php");
require_once("comm.dbConnection.php");

class sessionRep
{
    var $started= FALSE;

    ////////////////////////////////////////////////////////////////////
    //                       Constructor                              //
    //      MUST BE CALLED BEFORE ANY OUTPUT IS GENERATED             //
    ////////////////////////////////////////////////////////////////////
    //  argument is an array of database connection args
    function sessionRep ($ca= "") {
        global $php_sessid;

        session_start();
        $this->sdata = array();
        $this->conn= new dbConnection();
        $this->cArgs= ($ca == "") ?  $this->conn->dbConnectionArgs() : $ca;
    }

    ////////////////////////////////////////////////////////////////////
    //          loads a session row from the database                 //
    ////////////////////////////////////////////////////////////////////
    function load () {
        global $sessionLogInterval;

        $myRc= FALSE;
        $myConn=& $this->conn;

        $mySessionInterval= isset($sessionLogInterval) ? $sessionLogInterval : "6 hours";
        //echo("<br>\$mySessionInterval= $mySessionInterval");

        $myQuerySel =
             "SELECT val FROM as_sessions " .
             "WHERE sid='$this->id' " .
             "AND created > now()::timestamp - '$mySessionInterval'::interval";

        $myQueryDel =
             "DELETE FROM as_sessions " .
             "WHERE created < now()::timestamp - '$mySessionInterval'::interval";

        if ($myRc= $myConn->openConnection($this->cArgs)) {
            //  do not load a stale session
            //echo("<br>del..."); var_dump($myQueryDel);
            $myConn->executeQuery($myQueryDel);

            //echo("<br>que..."); var_dump($myQuerySel);
            if (isset($this->id) && $myConn->executeQuery($myQuerySel)) {
                $h= new hasher;

                $sessiondata = $myConn->fetchNextRow(0);
                $this->sdHash= $h->sessionMunge($sessiondata[0]);
                $this->sdata= unserialize($sessiondata[0]);
                //echo("<br><br>load sessiondata..."); var_dump($sessiondata);
            }
            $myConn->closeConnection();
        }
        return($myRc);
    }

    ////////////////////////////////////////////////////////////////////
    //      Starts a new session or loads an existing one             //
    ////////////////////////////////////////////////////////////////////
    function start ($sName = "", $sCookie = FALSE) {
        $h= new hasher;
        if (!$this->started) {
            //  if there's no name then make one up
            if ($sName == "") {
                srand ((double) microtime() * 1000000);
                $sName = uniqid(rand());
            }
            //  if there's no session id already, then munge one
            if (!$this->id) {
                $idArg= $sName . session_id();
                $this->id= $h->sessionMunge($idArg);
            }
            $this->load();
            $this->started= TRUE;
        }
    }

    ////////////////////////////////////////////////////////////////////
    //     start a session when the id and a hash are known           //
    ////////////////////////////////////////////////////////////////////
    function starth ($id, $hash= "") {
        $h= new hasher();

        if ($this->started) {
            $this->destroy();
        }
        $this->id= $id;

        //  load this session ($tis->id is set)
        $this->started= $this->load();

        //if the hash doesn't match then go all nonlinear
        if ($this->started && $hash != "" && $hash != $this->sdHash) {
            $this->destroy();
        }
        return($this->started);
    }


    ////////////////////////////////////////////////////////////////////
    //          Makes sure that the user has logged in                //
    ////////////////////////////////////////////////////////////////////
    //  this methodwill make sure that a session is active before
    //  allowing the current state to proceed
    function authorize($user= "") {
        global $SERVER_NAME, $REQUEST_URI, $REQUEST_METHOD;

        //  if there's no valid session in progress, then save a URI
        //  for the current screen, and start a session by redirecting
        //  to the login panel
        if (!isset($this->sdata['authLogin']) || !$this->sdata['authLogin']){
            $this->save();

            //  current browser state
            if ($REQUEST_METHOD == "GET") {
                $this->sdata['..sessBackURL']=  "{$REQUEST_URI}";
            }

            if (isset($this->sdata['..sessBackURL'])) {
                $backURL= "&backUrl=" . urlencode($this->sdata['..sessBackURL']);

            } else {
                $backURL= "";
            }

            //  redirect to login panel
            $loc  = "join.php?lg=1";
            $loc .= ($user != "") ? "&ln=" . urlencode($user) : "";
            $loc .= $backURL;
            header("Location: $loc");
            exit;
        }
    }

    ////////////////////////////////////////////////////////////////////
    //               Registers a session variable                     //
    ////////////////////////////////////////////////////////////////////
    function register ($key, $val) {
        $this->sdata[$key] = $val;
    }

    ////////////////////////////////////////////////////////////////////
    //              Unregisters a session variable                    //
    ////////////////////////////////////////////////////////////////////
    function unregister ($var) {
        unset($this->sdata[$var]);
    }

    ////////////////////////////////////////////////////////////////////
    //              delete all traces of a session                    //
    ////////////////////////////////////////////////////////////////////
    function remove() {
        if (isset($this->id) && $this->id) {
            if ($this->conn->openConnection($this->cArgs)) {
                $sqldate = date("YmdHis", time() - ($gctime * 60));
                $query = "DELETE FROM as_sessions WHERE sid='$this->id'";
                $this->conn->executeQuery($query);
                $this->conn->closeConnection();
            }
            $this->destroy();
        }
    }

    ////////////////////////////////////////////////////////////////////
    //                 Stops a current session                        //
    ////////////////////////////////////////////////////////////////////
    function destroy () {
        global $php_sessid;

        $this->sdata = array();
        $this->id = FALSE;
        $this->started = FALSE;
        $php_sessid = FALSE;
    }

    ////////////////////////////////////////////////////////////////////
    //     Checks if a variable is registered in a session            //
    ////////////////////////////////////////////////////////////////////
    function is_registered ($name) {
        return (isset($this->sdata[$name]) ? 1 : 0);
    }

    ////////////////////////////////////////////////////////////////////
    //                 Saves the session array                        //
    ////////////////////////////////////////////////////////////////////
    function save () {
        $h= new hasher;

        $ts = serialize($this->sdata);
        $es = str_replace("\\", "\\\\", str_replace("'", "''", trim($ts)));
        
        $this->sdHash= $h->sessionMunge($ts);
        //echo("br><br>store sessiondata..."); var_dump($ts);
        

        $myUpdate=
             "UPDATE as_sessions " .
             "SET val='$es', modified= now() " .
             "WHERE sid='$this->id'";

        $myInsert=
             "INSERT INTO as_sessions " .
             "(sid, val, created, modified) " .
             "VALUES ('$this->id', '$es', now(), now())";

        $rc= $this->conn->openConnection($this->cArgs);
        $rc= $this->conn->executeQuery($myUpdate);
        if ($this->conn->getAffectedRows() == 0) {
            $rc= $this->conn->executeQuery($myInsert);
        }

        $this->conn->closeConnection();
    }

    ////////////////////////////////////////////////////////////////////
    //                      garbage collector                         //
    ////////////////////////////////////////////////////////////////////
    //  this needs to be thought out
    function gc ($gctime) {
        if ($this->conn->openConnection($this->cArgs)) {
            $sqldate = date("YmdHis", time() - ($gctime * 60));
            $query = "DELETE FROM as_sessions WHERE created < '$sqldate';";
            $this->conn->executeQuery($query);
            $this->conn->closeConnection();
        }
    }
}
?>
