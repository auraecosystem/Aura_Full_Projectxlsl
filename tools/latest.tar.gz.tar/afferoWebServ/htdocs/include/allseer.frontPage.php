<?php
//  $Name: ORG-TEST $, $Id: allseer.frontPage.php,v 1.7 2002/09/02 21:34:08 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//
require_once("allseer.UserSqlConn.php");
require_once("allseer.arrayLoader.php");
require_once("allseer.hallOfFame.php");

class frontPage
{
    var $dbConnection = FALSE;
    var $hallOFame = FALSE;

    ////////////////////////////////////////////////////////////////////
    //                  C O N S T R U C T O R                         //
    ////////////////////////////////////////////////////////////////////
    function frontPage () {
    }

    ////////////////////////////////////////////////////////////////////
    //  frontPage Object Initialization
    function init () {
        $myRC = FALSE;

        $conn =& $this->dbConnection;
        $hof =& $this->hallOFame;

        if (!$conn = new UserSqlConn) {
            syslog(LOG_ERR, "frontPage: couldn't instantiate dbConnection object");

        } else {
            $myRC = TRUE;
        }
        return($myRC);
    }
}
?>