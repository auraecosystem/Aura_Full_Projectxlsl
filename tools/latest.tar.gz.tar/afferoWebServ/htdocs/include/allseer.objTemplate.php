<?php
//  $Name: ORG-TEST $, $Id: allseer.objTemplate.php,v 1.3 2002/03/19 02:47:07 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//

include_once("comm.dbConnection.php");

class payDetail
{
    var $validationFlag;
    var $Messages;
    
    ////////////////////////////////////////////////////////////////////
    function payDetail () {
        $this->validationFlag = FALSE;
    }

    ////////////////////////////////////////////////////////////////////
    //  edit check all of the form fields
    function validateFields() {
        $this->Messages = array();
        $myRC = TRUE;

        return($myRC);
    }

    ////////////////////////////////////////////////////////////////////
    function validated(){
        return($this->validationFlag);
    }

    ////////////////////////////////////////////////////////////////////
    //  all fields on a ratings screen have been validated.  do the
    //  requisite database updates.
    function dbUpdate() {
        $this->validationFlag = FALSE;

        $conn = new dbConnection();
        $conn->openConnection();
        $myRC = TRUE;

        $conn->closeConnection();
        return($myRC);
    }

    ////////////////////////////////////////////////////////////////////
    function init () {
        return(TRUE);
    }
}
?>