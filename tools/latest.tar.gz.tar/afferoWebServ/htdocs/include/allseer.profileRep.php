<?php
//  $Name: ORG-TEST $, $Id: allseer.profileRep.php,v 1.15 2002/10/04 16:44:44 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//
require_once("allseer.validator.php");
require_once("allseer.UserSqlConn.php");

class profileRep
{
    function profileRep() {
        $this->name= "";
        $this->sum= 0;
        $this->oid= FALSE;
        $this->id= 0;
        $this->proppa= "";
        $this->proppa_tp= "plain";
        $this->array= array();
        $this->dbRows= array();
   }

    function cmp($a, $b) {
        $myRc= 0;            
        if ($a['pc'] != $b['pc']) {
            $myRc= $a['pc'] > $b['pc'] ? -1 : 1;

        } else if (strlen($a['found']) && strlen($b['found'])){
            $myRc= strcmp($a['found'], $b['found']);

        } else if (!strlen($a['found'])) {
            $myRc= 1;

        } else {
             $myRc= -1;
        }
        return($myRc);
    }
    //  check for allowable html
    function safeHTML($text) {
        $checkText= $lowerText= strtolower($text);
        $checkText = str_replace('<!--', '', $checkText);
        $checkText = strip_tags($checkText, '<br><b><i><u><font><a>');
        return($checkText == $lowerText);
    }
    //  multiple failures can be reported!!
    function valid($user, $checkDupe=FALSE) {
        $checker= new asValidator();
        $checker->CLEAR= TRUE;
        $this->Messages= array();

        //  multiple failures can be reported!!
        //if (!$checker->is_ProfileName($this->name) || $checker->is_dupeProfileName($this->name, $user)) {
        if (!$checker->is_ProfileName($this->name)) {
            $this->Messages[]= $checker->ERROR;
        }
        if ($checkDupe && $checker->is_dupeProfileName($this->name, $user)) {
             $this->Messages[]= $checker->ERROR;
        }
        
        if (count($this->array) == 0) {
            $this->Messages[]= "THERE ARE NO PROFILE DETAILS";
        }
        if ($this->totalPerCent() != 100) {
            $this->Messages[]= "TOTAL BENEFICIARY SHARES MUST ADD UP TO 100%";
        }
        for($i=0; $i< count($this->array); $i++) {
            if (($pc= $this->array[$i]['pc']) > 0 && $this->array[$i]['found'] ==  "") {
                $this->Messages[]= "SELECT FOUNDATIONS FOR ALL NON-ZERO ($pc) FRACTIONAL DISBURSEMENTS";
            }
        }
        for($i=0; $i< count($this->array); $i++) {
            if (($pc= $this->array[$i]['pc']) < 0 || $this->array[$i]['pc'] > 100) {
                $this->Messages[]= "PER CENTAGE VALUE MUST BE BETWEEN 0 AND 100. '$pc' IS PROHIBITED";
            }
        }
        if ($this->proppa_tp == "html") {
            if (!$this->safeHTML($this->proppa)) {
                $this->Messages[]= htmlspecialchars("DESCRIPTION HTML CAN ONLY CONTAIN <BR>, <B>, <I>, <A>, <U>, AND <FONT> TAGS");
            }
        }
        //echo("<br>validity..."); var_dump($this);
        unset($checker);
        return(count($this->Messages) == 0);
    }

    //  two objects are the same if they have the same
    //  names and disbursement profiles
    function same($that) {
        $myRc= FALSE;
        if ($myRc =(get_class($this) == get_class($that))) {
            if ($myRc= ($this->name == $that->name)) {
                $this->pRepSort(); reset($this->array);
                $that->pRepSort(); reset($that->array);

                $my=& $this->array;    $j= count($my);
                $your=& $that->array;  $i= count($your);
                
                if ($myRc= (($j= count($my)) == count($your))) {
                    for($i=0; $i<$j; $i++){
                        if (!$myRc= !!((int)$my[$i]['pc'] === (int)$your[$i]['pc'])) {break;}
                        if (!$myRc= !!($my[$i]['found'] === ($your[$i]['found']))){break;}
                    }
                    $myRc= ($i == $j) ? TRUE : $myRc;
                }
            }
        }
        return($myRc);
    }

    //  a profile needs update if the proppa or proppa_tp attributes
    //  are different but are otherwise the same (ie name and profile)
    function needsUpdate($that) {
        $myRc= FALSE;
        if ($this->name == $that->name) { 
            if (trim($this->proppa_tp) != trim($that->proppa_tp)) {
                $myRc= TRUE;
                
            } else if (trim($this->proppa) != trim($that->proppa)) {
                $myRc= TRUE;
            }
        }
        return($myRc);
    }

    //  a profile must be replaced when names match but profile
    //  details are different
    function mustReplace($that) {
        $myRc= (!$this->same($that)) && ($this->name == $that->name);
        return($myRc);
    }
    
    function pRepSort(){
        usort($this->array, array($this, "cmp"));
    }

    function totalPerCent(){
        $this->sum= 0;
        for($i=0; $i< count($this->array); $i++) {
            $this->sum += $this->array[$i]['pc'];
        }
        return($this->sum);
    }
    //  insert detail lines in the database
    function insertDetailArray($conn, $profOID){
        $myRc= TRUE;
        for($i=0; $i< count($this->array); $i++){
            $ln = $this->array[$i];
            if ($ln["pc"] > 0) {
                if (!$conn->insertPayProfileDetail($ln, $profOID)) {
                    $this->Message = "profileRep::dbUpdate: Can't insert detail row" . $conn->getErrorMessage();
                    syslog(LOG_ERR, $this->Message);
                    $myRc= FALSE;
                    break;
                }
            }
        }
        return($myRc);
    }
    
    ////////////////////////////////////////////////////////////////////
    //  all fields have been validated for a new profile.  do the
    //  requisite database updates.
    function addProfile($user, $conn) {
        $this->Message= "";
        $myTransState = "continue";
        $myRC = FALSE;  //  TRUE only if the transaction succeeds

        if (!$myRC= $this->valid($user)) {
            $myTransState = "exit";
            $this->Message = "profileRep::dbUpdate: pay profile is not valid exit now";
            syslog(LOG_ERR, $this->Message);
        }
        //echo("<br>profileRep::addProfile() site 1 conn..."); var_dump($conn);
        //  continue... create a pay profile for the user
        if ($myTransState == "continue") {
            if (!$conn->insertPayProfile($this->name, $this->proppa, $this->proppa_tp, $user)) {
                $this->Message = "profileRep::dbUpdate:  profile insert failure " . $conn->getErrorMessage();
                $myTransState = "rollback";
                
                syslog(LOG_ERR, $this->Message);
                //echo("<br>profileRep::addProfile() name..."); var_dump($this->name);
                //echo("<br>profileRep::addProfile() proppa..."); var_dump($this->proppa);
                //echo("<br>profileRep::addProfile() proppa_tp..."); var_dump($this->proppa_tp);
                //echo("<br>profileRep::addProfile() user..."); var_dump($user);
                //echo("<br>profileRep::addProfile() {$this->Message}..."); 
            } else {
                if (!$this->oid= $myProfOID= $conn->getLastOid()) {
                    $this->Message = "profileRep::dbUpdate: Can't determine profile OID" . $conn->getErrorMessage();
                    $myTransState = "rollback";
                    syslog(LOG_ERR, $this->Message);
                }
            }
        }
        //echo("<br>profileRep::addProfile() site 2 conn..."); var_dump($conn);                
        //  continue... update the expert sequence
        if ($myTransState == "continue") {
            if (!($pprofId= $conn->updatePayProfileSequence($myProfOID))) {
                $this->Message = "profileRep::dbUpdate:  can't update expert sequence " . $conn->getErrorMessage();
                $myTransState = "rollback";
                syslog(LOG_ERR, $this->Message);
            }
        }
        //echo("<br>profileRep::addProfile() site 3 conn..."); var_dump($conn);
        //  now, add the profile detail lines
        if ($myTransState == "continue") {
            if (!$this->insertDetailArray($conn, $myProfOID)) {
                $myTransState = "rollback";
                syslog(LOG_ERR, $this->Message);
            }
        }
        //echo("<br>profileRep::addProfile() site 4 conn..."); var_dump($conn);
        //  returns the pay profile Id (foreign key) associated with
        //  the new profile this is really BAD.  but it is quick and
        //  time is short before a launch.  i really have no excuse...
        $pid= (isset($pprofId) && $pprofId) ? $pprofId : FALSE;
        $myRC= ($myRC && ($myTransState == "continue")) ? $pid : FALSE;
        //echo("<br><br>profileRep::addProfile()..."); var_dump($this->Message);
        //echo("<br>profileRep::addProfile() site 5 conn..."); var_dump($conn);
        return($myRC);
    }
    //  pdate the profile row (ie proppa_tp or proppa of both)
    function updateProfile($conn, $login) {
        $origRow= $conn->fetchUserPayProfile($login, $this->name);
        
        $mySQL=
             "update as_pay_profiles set " .
             "  pprof_proppa_tp='" . $this->proppa_tp ."'," .
             "  pprof_proppa='" . str_replace("\\", "\\\\", str_replace("'", "''", trim($this->proppa))) . "', " .
             "  modified=now() " .
             "where pprof_id='" . $origRow[0]['id'] . "';";
        
        $myRc = $conn->executeQuery($mySQL);
        if (!$myRc) {
            syslog(LOG_ERR, "profileRep.updateProfile: " . $conn->getErrorMessage());
            syslog(LOG_ERR, "profileRep.updateProfile: query<<$mySQL>>");
        }
        return($myRc);
    }
    //  update the profile row (ie proppa_tp or proppa of both)
    function replaceProfileDetails ($conn) {
        $myRC= TRUE;
        //echo("<br><br>db arry..."); var_dump($this->dbRows);
        //echo("<br><br>array...");var_dump($this->array);
        
        if (!$conn->deletePayProfileDetails($this->id)) {
            $myRC= FALSE;
        } else if (!$this->insertDetailArray($conn, $this->oid)) {
            $myRC= FALSE;
        }
        return($myRC);
    }
    
    //  check if this object is empty
    function is_empty() {
        $myRC= TRUE;

        //  all profile details must be empty
        if (count($this->array) != 0) {
            for($i=0; $i< count($this->array); $i++) {
                if (!(($pc= $this->array[$i]['pc']) == 0 && $this->array[$i]['found'] ==  "")) {
                    $myRC= FALSE;
                    break;
                }
            }   
        }
        //  there must be no name
        $myRC= $myRC && ($this->name == "");
        //  and no propaganda
        $myRC= $myRC && ($this->proppa == "");
        
        return($myRC);
    }
    ////////////////////////////////////////////////////////////////////
    function setView ($user, $viewArg) {
        $conn= new UserSqlConn();
        $dbAry =& $this->dbRows;
        
        if ($dbAry= $conn->fetchUserPPDetails($user, $viewArg)) {
            $this->name= $dbAry[0]["name"];
            $this->oid= $dbAry[0]["pprof_oid"];
            $this->id= $dbAry[0]["pprof_id"];
            $this->proppa= $dbAry[0]["proppa"];
            $this->proppa_tp= $dbAry[0]["proppa_tp"];
            $this->array= array();
            
            $vAry=& $this->array;
            for ($i=0; $i< count($dbAry); $i++) {
                $vAry[$i]["pc"]= $dbAry[$i]["pc"];
                $vAry[$i]["found"]= $dbAry[$i]["found"];
            }
        }
        return(TRUE);
    }
    ////////////////////////////////////////////////////////////////////
    function setViewByName ($user, $name) {
        $conn= new UserSqlConn();
        $dbAry =& $this->dbRows;
        
        if ($dbAry= $conn->fetchUserPPDetailsByName($user, $name)) {
            $this->name= $dbAry[0]["name"];
            $this->oid= $dbAry[0]["pprof_oid"];
            $this->id= $dbAry[0]["pprof_id"];
            $this->proppa= $dbAry[0]["proppa"];
            $this->proppa_tp= $dbAry[0]["proppa_tp"];
            $this->array= array();
            
            $vAry=& $this->array;
            for ($i=0; $i< count($dbAry); $i++) {
                $vAry[$i]["pc"]= $dbAry[$i]["pc"];
                $vAry[$i]["found"]= $dbAry[$i]["found"];
            }
        }
        return(TRUE);
    }
}
