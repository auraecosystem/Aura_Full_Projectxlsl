<?
//  $Name: ORG-TEST $, $Id: allseer.hasher.php,v 1.10 2002/03/19 02:47:07 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  
require_once("config.inc.php");

class hasher
{
////////////////////////////////////////////////////////////////////////
//                        C O N S T R U C T O R                       //
////////////////////////////////////////////////////////////////////////
    function hasher () {

    }
    
////////////////////////////////////////////////////////////////////////
//                P R I V A T E    F U N C T I O N S                  //
////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////
//              I N T E R F A C E    F U N C T I O N S                //
//--------------------------------------------------------------------//
    function emailMunge($str, $xtraString="") {
        global $HasherEmailMungerKey;
        
        $scrstr= $HasherEmailMungerKey . trim($str) . $xtraString;
        $result= md5($scrstr);
        
        return($result);
    }
    
    function passwordMunge($str, $xtraString="") {
        global $HasherPasswordMungerKey;
        
        $scrstr= $HasherPasswordMungerKey . trim($str) . $xtraString;
        $result= md5($scrstr);
        
        return($result);
    }
    
    function sessionMunge($str, $xtraString="") {
        global $HasherSessionMungerKey;
        
        $scrstr= $HasherSessionMungerKey . trim($str) . $xtraString;
        $result= md5($scrstr);

        return($result);
    }
    
    function cloak($str) {
        global $HasherCloakerKey;
        
        $result= "";
        //echo("<br>hasher claoker");var_dump($HasherCloakerKey);
        
        for ($j=0; $j <strlen($str); $j++) {
            $result .= ($str[$j] ^ $HasherCloakerKey[$j % strlen($this->cloakerKey)]);            
        }
        return($result);
    }
    
    function deCloak($str) {
        return($this->cloak($str));
    }
}
?>
