<?php
//  $Name: ORG-TEST $, $Id: allseer.editListComps.php,v 1.3 2002/09/02 21:35:46 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//
require_once("allseer.UserSqlConn.php");
require_once("allseer.validator.php");

class lc_editor
{
    ////////////////////////////////////////////////////////////////////
    function lc_editor($s) {
        $this->NewCat= "";
        $this->validationFlag = FALSE;
        $this->Messages = array();
        $this->dbConnection = new UserSqlConn;
    }

////////////////////////////////////////////////////////////////////////
//                 L O C A L     F U N C T I O N S                    //
////////////////////////////////////////////////////////////////////////
    //
    function setValidationFlag($v) {
        $this->validationFlag= !!$v;
    }

    ////////////////////////////////////////////////////////////////////
    //  move HTTP POST variables into object attributes
    function readPostVariables() {
        global $HTTP_POST_VARS;
        $myPostVars= $HTTP_POST_VARS;
        //echo("<br>post vars..."); var_dump($myPostVars);

        //  get rid of some crap
        unset($myPostVars['u']);
        unset($myPostVars['FormValidate']);

        //  set the 'SelectedLIst' property
        if (isset($myPostVars['FormSelectedList'])) {
            $this->setSelectedList($myPostVars['FormSelectedList']);
            unset($myPostVars['FormSelectedList']);
        }
        //  move the actve / inactive flags in to an array.  the
        //  array is used in the setDisplayInfo() method to initialize
        //  screen fields.
        $act= array();
        reset($myPostVars);
        while (list($var, $value) = each($myPostVars)) {
            list($lid, $i)= sscanf($var, "FormScrAct_%d_%d");
            if ($lid != "") {
                $locId= $lid;
                $act[$i]= (!strcasecmp($value,"yes")) ? "t" : "f";
                unset($myPostVars["$var"]);
            }
        }

        $this->ScrAct= array();
        if (count($act) > 0) {
            $this->ScrAct['list_id']= $locId;
            $this->ScrAct['flags']= $act;
        }

        //  and move the rest of the post variables into object
        //  attributes,  mainly for convenience.
        reset($myPostVars);
        while (list($var, $value) = each($myPostVars)) {
            list($attrName)= sscanf($var, "Form%s");
            if ($attrName != "") {
                $this->$attrName= $value;
                unset($myPostVars["$var"]);
            }
        }
        return(TRUE);
    }

////////////////////////////////////////////////////////////////////////
//             I N T E R F A C E    F U N C T I  O N S                //
////////////////////////////////////////////////////////////////////////
    //  return the current state of the validation flag
    function validated(){
        return($this->validationFlag);
    }

    //  read all of the form fields and check them
    function validateFields() {
        $v = new asValidator;
        $v->CLEAR= TRUE;

        $this->Messages= array();
        $vMsgs =& $this->Messages;

        $this->readPostVariables();
        if ($this->NewCat != ""){
            //  split individual categories out of the screen textarea
            $cats = preg_split ("/[\n\t,]+/", $this->NewCat);
            //  throw away zero length strings
            for ($i=0; $i < count($cats); $i++) {
                if (($val= trim($cats[$i])) != "") {
                    $t[]= $val;
                }
            }
            $cats= $t;

            //  construct an array of category names for dupe checking
            $locAry= $this->dbConnection->loadMlistComps($this->SelectedList);
            for ($i=0, $n= count($locAry); $i < $n; $i++) {
                $cNames[]= strtolower($locAry[$i]['cmptcy_descr']);
            }

            //  validate individual categories
            for($i=0, $n= count($cats); $i < $n; $i++) {
                if (!$v->is_validCompetencyInput($cats[$i])) {
                    $vMsgs['NewCat'][]= "'{$cats[$i]}':" . $v->ERROR;

                } else if (in_array(strtolower($cats[$i]), $cNames)) {
                    $vMsgs['NewCat'][]= "'{$cats[$i]}': DUPLICATE CATEGORY";
                }
            }

            //  if all categories were good, the save an array
            //  of them as an object property
            if (!isset($vMsgs['NewCat'])) {
                $this->validatedCats= $cats;
            }
        }
        $this->setValidationFlag((count($this->Messages) == 0));
        return($this->validated());
    }

    ////////////////////////////////////////////////////////////////////
    //  all form fields have been validated.  do the
    //  requisite database updates.
    function Finalize() {
        $myRC = "OK";

        if ($this->validated()) {
            $this->setValidationFlag(FALSE);
            $this->setDisplayInfo();

            //  begin a transaction
            $conn=& $this->dbConnection;
            $conn->openConnection();

            $myTransState = "continue";
            if (!$conn->executeQuery("begin work;")) {
                $myTransState = "exit";
                $this->sqlMessage = "editListComps::Finalize(): " . $conn->getErrorMessage();
                syslog(LOG_ERR, $this->sqlMessage);
            }

            $vCats=& $this->validatedCats;
            $newCats= array();
            if ($myTransState == "continue" && is_array($vCats) && count($vCats) > 0) {
                //  insert new competencies
                for($i=0, $n= count($vCats); $i < $n; $i++) {
                    $mySQL=
                         "insert into as_competencies " .
                         "    (cmptcy_descr, cmptcy_active, created) " .
                         "values " .
                         "    ('$vCats[$i]', 't', now())";

                    if (!$conn->executeQuery($mySQL)) {
                        $myTransState = "rollback";
                        $myRC= $this->sqlMessage = "editListComps::Finalize(): " . $conn->getErrorMessage();
                        syslog(LOG_ERR, $this->sqlMessage);
                        break;
                    }
                    $mySQL= "select * from as_competencies where oid=" . $conn->getLastOid();
                    if (!($newCats[]= $conn->execSingleRowQuery($mySQL))) {
                        $myTransState = "rollback";
                        $myRC= $this->sqlMessage = "editListComps::Finalize(): " . $conn->getErrorMessage();
                        syslog(LOG_ERR, $this->sqlMessage);
                        break;
                    }
                }
            }

            //  attach new competencies to the selected list
            if ($myTransState == "continue" && count($newCats) > 0) {
                for($i=0, $n= count($newCats); $i < $n; $i++) {
                    $mySQL=
                         "insert into as_mlist_comps " .
                         "    (mc_mid, mc_cid, created) " .
                         "values " .
                         "    ('" . $this->SelectedListId . "', '" . $newCats[$i]['cmptcy_id'] . "', now())";

                    if (!$conn->executeQuery($mySQL)) {
                        $myTransState = "rollback";
                        $myRC= $this->sqlMessage = "editListComps::Finalize(): " . $conn->getErrorMessage();
                        syslog(LOG_ERR, $this->sqlMessage);
                        break;
                    }
                }
            }
            //  toggle active states in competency rows as specified in
            //  the UI
            if ($myTransState == "continue" && count($this->Competencies) > 0) {
                $comps=& $this->Competencies;
                for($i=0, $n= count($comps); $i < $n; $i++) {
                    if ($comps[$i]['cmptcy_active'] != $comps[$i]['screen_active']){

                        $mySQL=
                             "update as_competencies " .
                             "set cmptcy_active = '" . $comps[$i]['screen_active'] . "' " .
                             "where cmptcy_id = '" . $comps[$i]['cmptcy_id'] . "'";

                        if (!$conn->executeQuery($mySQL)) {
                            $myTransState = "rollback";
                            $myRC= $this->sqlMessage = "editListComps::Finalize(): " . $conn->getErrorMessage();
                            syslog(LOG_ERR, $this->sqlMessage);
                            break;
                        }
                    }
                }
            }
            //  end of transaction.  commit or rollback.
            if ($myTransState == "continue") {
                if ($conn->executeQuery("commit work;")) {
                    $myTransState = "exit";

                } else {
                    $myTransState = "rollback";
                    $sqlMessage = "editListComps::Finalize(): transaction commit failure" . $conn->getErrorMessage();
                    syslog(LOG_ERR, $this->sqlMessage);
                }
            }
            if ($myTransState == "rollback") {
                syslog(LOG_ERR, "ditListComps::Finalize(): Transaction failure.  Rolling back");
                $conn->executeQuery("rollback");
                $myTransState = "exit";
            }
            $conn->closeConnection();
        }
        return($myRC);
    }

    //  given a list address, return its index in the Lists property
    //  of this object
    function listIndex($name) {
        $retVal= 0;
        for ($i=0; $i < count($this->Lists); $i++) {
            if ($name == $this->Lists[$i]['mlist_name']) {
                $retVal= $i;
                break;
            }
        }
        return($retVal);
    }

    //  given a list address, return its index in the Lists property
    //  of this object
    function is_valid_list($name) {
        $rc= FALSE;
        for ($i=0; $i < count($this->Lists); $i++) {
            if ($name == $this->Lists[$i]['mlist_name']) {
                $rc= TRUE;
                break;
            }
        }

        return($rc);
    }

    //  set the 'SelectedList' property
    function setSelectedList($argSel= "") {
        $this->SelectedList= isset($this->SelectedList) ? $this->SelectedList : "";

        $regSel= "";
        if ($this->sess->is_registered('SelectedList')) {
            $regSel= $this->sess->sdata['SelectedList'];
        }

        if ($argSel != "" && $this->is_valid_list($argSel)) {
            $setSel= $argSel;

        } else if ($regSel != "" && $this->is_valid_list($regSel)) {
            $setSel= $regSel;

        } else if ($this->SelectedList != "" && $this->is_valid_list($this->SelectedList)){
            $setSel= $this->SelectedList;

        } else {
            $setSel= "";
        }
        //  set the name to the name of the selected list.  this
        //  will default to the first element of the Lists property
        //  if the $setSel variable does not contain a vaild name.
        $i= $this->listIndex($setSel);
        $setSel= $this->Lists[$i]['mlist_name'];
        $this->SelectedList= $setSel;
        $this->SelectedListId= $this->Lists[$i]['mlist_id'];

        //  maybe save the session variable
        if ($setSel != $regSel) {
            $this->sess->register('SelectedList', $setSel);
            $this->sess->save();
        }
    }
    ////////////////////////////////////////////////////////////////////
    //  set up stuff for display in the smarty template
    function setDisplayInfo() {
        $this->setSelectedList($this->SelectedList);
        $locAry= $this->dbConnection->loadMlistComps($this->SelectedList);

        //  strip out all of the unwanted crap. this makes debugging
        //  a little easier
        for ($i=0; $i < count($locAry); $i++) {
            if (($val= trim($locAry[$i])) != "") {
                $t[]= array('cmptcy_descr' => $locAry[$i]['cmptcy_descr'],
                            'cmptcy_id' => $locAry[$i]['cmptcy_id'],
                            'cmptcy_active' => $locAry[$i]['cmptcy_active'],
                            'screen_active' => $locAry[$i]['cmptcy_active']);
            }
        }
        $locAry= $t;

        //  now, if the SelectedListId property matches the list
        //  id in the ScrAct array, then set the screen_active
        //  flags as they were reflected in the UI
        if (is_array($this->ScrAct) && count($this->ScrAct) > 0) {
            if ($this->ScrAct['list_id'] == $this->SelectedListId) {
                for ($i=0; $i < count($this->ScrAct['flags']); $i++) {
                    $locAry[$i]['screen_active']= $this->ScrAct['flags'][$i];
                }
            }
        }

        $this->Competencies=  $locAry;
        //var_dump($this->Competencies);
    }

    ////////////////////////////////////////////////////////////////////
    //  all form fields have been validated.  do the
    //  requisite database updates.
    function valid_GetArgs() {
        global $u;

        //  $u must be present
        $myRc= isset($u);
        //  $u must be a valid user id
        $conn=& $this->dbConnection;
        $myRc= ($myRc && !$conn->loginExists($u));
        //  $u must be a list administrator
        $myRc= ($myRc && !$conn->is_listAdmin($u));

        return($myRC);
    }

    ////////////////////////////////////////////////////////////////////
    //  argment is a session object
    function init ($s) {
        global $u;

        $this->sess= &$s;

        $myRc= "OK";
        $conn=& $this->dbConnection;
        if ($myRc == "OK" && !($conn && $conn->openConnection())) {
            $myRc= "Cannot open a database connection";

        } else {
            if ($myRc == "OK" && $REQUEST_METHOD == "GET") {
                if (!$this->valid_GetArgs()) {
                    $myRc= "CGI argments are not valid";
                }
            }

            if ($myRc == "OK") {
                $this->Login= $u;
                //  read all of this administartor's lists out of the db
                $this->Lists= $this->dbConnection->mlistByAdmin($this->Login);
                if (!is_array($this->Lists) || count ($this->Lists) == 0) {
                    $myRc= "No Maling lists";

                } else {
                    for ($i=0; $i < count($this->Lists); $i++) {
                        $this->Lists[$i]['mlist_name']= trim($this->Lists[$i]['mlist_name']);
                    }
                    $this->setSelectedList();
                }
            }
            $conn->closeConnection();
        }
        return($myRc);
    }
}
?>
