<?
//  $Name: ORG-TEST $, $Id: allseer.validator.php,v 1.16 2002/10/11 17:53:17 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  This class abstracts out some SQL functionality frequently
//  with user maintenance
require_once ("externClasses/class.Validator.php3");
require_once("allseer.UserSqlConn.php");

class asValidator extends Validator
{
    var $dbConnection = FALSE;

////////////////////////////////////////////////////////////////////////
//                        C O N S T R U C T O R                       //
////////////////////////////////////////////////////////////////////////
    function asValidator () {
    }
////////////////////////////////////////////////////////////////////////
//                P R I V A T E    F U N C T I O N S                  //
////////////////////////////////////////////////////////////////////////
    function asVconnect() {
        if (!$this->dbConnection) {
            $this->dbConnection= new UserSqlConn();
        }
        return(!!$this->dbConnection);
    }

////////////////////////////////////////////////////////////////////////
//              I N T E R F A C E    F U N C T I O N S                //
//--------------------------------------------------------------------//
//              functions related to the user table                   //
//--------------------------------------------------------------------//
    function is_UnitedStates($str) {
        return($str == "United States");
    }
    
    function is_NoState($state) {
        return($state == "" || $state == "None / Other");
    }
    
    function setNoState($state) {
        return("None / Other");
    }
    

    function is_user_first($str) {
        $myRC= FALSE;
        $myRegex = "^[-a-zA-Z ,'&]*$";

        if($this->CLEAR) { $this->clear_error(); }

        if (($myType= gettype($str)) != "string") {
            $this->ERROR= "OBJECT '$myType' IS NOT STRING";

        } else if (!eregi($myRegex, $str))  {
            $this->ERROR=  "FIRST NAME MUST BE A-Z SPACE OR -";

        } else {
            $myRC= TRUE;
        }
        return($myRC);
    }

    function is_user_last($str) {
        $myRC= FALSE;
        $myRegex = "^[-a-zA-Z ,'&]*$";

        if($this->CLEAR) { $this->clear_error(); }

        if (($myType= gettype($str)) != "string") {
            $this->ERROR= "OBJECT '$myType' IS NOT STRING";

        } else if (!eregi($myRegex, $str))  {
            $this->ERROR=  "LAST NAME MUST BE A-Z SPACE OR ,'&";

        } else {
            $myRC= TRUE;
        }
        return($myRC);
    }

    function is_user_company($str) {
        $myRC= FALSE;
        $myRegex = "^[-a-zA-Z0-9 ,'&#.]*$";

        if($this->CLEAR) { $this->clear_error(); }

        if (($myType= gettype($str)) != "string") {
            $this->ERROR= "OBJECT '$myType' IS NOT STRING";

        } else if (!eregi($myRegex, $str))  {
            $this->ERROR= "COMPANY NAME MUST BE A-Z, 0-9, SPACE OR ,'&-#.";

        } else {
            $myRC= TRUE;
        }
        return($myRC);
    }

    function is_user_address($str) {
        $myRC= FALSE;
        $myRegex = "^[-0-9a-zA-Z ,'&#.]*$";

        if($this->CLEAR) { $this->clear_error(); }

        if (($myType= gettype($str)) != "string") {
            $this->ERROR= "OBJECT '$myType' IS NOT STRING";

        } else if (!eregi($myRegex, $str))  {
            $this->ERROR= "ADDRESS MUST BE A-Z SPACE OR ,'&-#.";

        } else {
            $myRC= TRUE;
        }
        return($myRC);
    }

    function is_user_city($str) {
        $myRC= FALSE;
        $myRegex = '^[-a-zA-Z ]*$';

        if($this->CLEAR) { $this->clear_error(); }

        if (($myType= gettype($str)) != "string") {
            $this->ERROR= "OBJECT '$myType' IS NOT STRING";

        } else if (!eregi($myRegex, $str))  {
            $this->ERROR= "CITY MUST BE A-Z SPACE OR -";

        } else {
            $myRC= TRUE;
        }
        return($myRC);
    }

    function is_user_zip($str) {
        $myRC= FALSE;
        $zipRegex = "^[0-9]*$";
        if($this->CLEAR) { $this->clear_error(); }

        if (($myType= gettype($str)) != "string") {
            $this->ERROR= "OBJECT '$myType' IS NOT STRING";

        } else if (!preg_match("/^([0-9]{5})(-[0-9]{4})?$/",$str, $zipAry)) {
            $this->ERROR= "ZIP/POSTAL CODE MUST BE of the form 99999 or 99999-9999";
            
        } else {
            $myRC= TRUE;
        }
        return($myRC);
    }

    function is_user_phone($str) {
        $myRC= FALSE;
        $myRegex = "^[-/()0-9 +]*$";
        if($this->CLEAR) { $this->clear_error(); }

        if (($myType= gettype($str)) != "string") {
            $this->ERROR= "OBJECT '$myType' IS NOT STRING";

        } else if (!eregi($myRegex, $str))  {
            $this->ERROR= "PHONE MUST BE DIGIT OR SPACE OR ()+-/";

        } else {
            $myRC= TRUE;
        }
        return($myRC);
    }
    //  letter, digit or underbar
    function is_ldu ($str) {
        $myRC= FALSE;
        $lduRegex = "^[0-9a-zA-Z_]*$";
        if($this->CLEAR) { $this->clear_error(); }

        if (($myType= gettype($str)) != "string") {
            $this->ERROR= "Object is '$myType' should be 'string'";

        } else if (!eregi($lduRegex, $str))  {
            $this->ERROR= "String must be composed of letters, digits and underbar";

        } else {
            $myRC= TRUE;
        }
        return($myRC);
    }
    
    //  letter, digit or space
    function is_lds ($str) {
        $myRC= FALSE;
        $myRegex = "^[0-9a-zA-Z ]*$";
        if($this->CLEAR) { $this->clear_error(); }

        if (($myType= gettype($str)) != "string") {
            $this->ERROR= "OBJECT IS '$myType' SHOULD BE 'STRING'";

        } else if (!eregi($myRegex, $str))  {
            $this->ERROR= "STRING MUST BE COMPOSED OF LETTERS, DIGITS AND SPACES";

        } else {
            $myRC= TRUE;
        }
        return($myRC);        
    }
    //----------------------------------------------------------------//
    //          functions related to payment profiles                 //
    //----------------------------------------------------------------//
    function is_ProfileName($str) {
        $myRC = FALSE;
		if($this->CLEAR) { $this->clear_error(); }

        if (strlen($str) == 0) {
            $this->ERROR= "THE DISBURSEMENT PROFILE NAME MUST BE SPECIFIED";

        } else if (!$this->is_ldu($str)) {
            $this->ERROR= "THE DISBURSEMENT PROFILE NAME CAN ONLY INCLUDE LETTERS, NUMBERS, AND UNDERLINES";

        } else {
            $myRC= TRUE;
        }

        return($myRC);
    }
    //  a user may have a number of pay profiles.  no two
    //  may have the same name.
    function is_dupeProfileName($name, $user) {
        $myRC = TRUE;
		if($this->CLEAR) { $this->clear_error(); }

        if ($this->asVconnect()) {
            $conn =& $this->dbConnection;
            if ($myRC= $conn->profileNameExists($name, $user)) {
                $this->ERROR= "THE DISBURSEMENT PROFILE NAME ALREADY EXISTS, PLEASE CHOOSE ANOTHER NAME";
            }
        }
        return($myRC);
    }
////////////////////////////////////////////////////////////////////////
//                         Save this for later
////////////////////////////////////////////////////////////////////////
//    //  check if a foundation name is in the database
//    function is_valid_foundation($f) {
//        $myRc= FALSE;
//        if (count($this->foundAry) == 0 && $this->asVconnect()) {
//            $this->foundAry= $this->dbConnection->buildFoundationArray();
//        }
//        if (count($this->foundAry) > 0 ) {
//            foreach($this->foundAry as $k => $v){
//                $myRc= TRUE;
//                echo("<br>validator::is_valid_foundation(\$k, \$v)..."); var_dump($k); var_dump($v);
//            }
//        }
//    }

    //----------------------------------------------------------------//
    //       some miscellaneous and various kinds of crap             //
    //----------------------------------------------------------------//
    //  make sure that an email is (syntacticly) valid
    function is_validEmail($email) {
        $myRegex = "^[0-9a-z]([-_.]?[0-9a-z])*@[0-9a-z]([-.]?[0-9a-z])*\\.[a-wyz][a-z](g|l|m|pa|t|u|v)?$";

        if($this->CLEAR) { $this->clear_error(); }

        if (!$myRc= eregi($myRegex, $email)) {
            $this->ERROR= "INVALID EMAIL ADDRESS";
        }
        return($myRc);
    }
    //  check for a syntactically valid Competency
    function is_validCompetencyInput($comp) {
        if (!$myRc= $this->is_lds($comp)) {
            $this->ERROR= "COMPETENCY MUST BE LETTERS DIGITS OR SPACE";
        }
        return($myRc);
    }
}
?>
