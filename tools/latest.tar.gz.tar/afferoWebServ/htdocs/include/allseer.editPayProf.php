<?php
//  $Name: ORG-TEST $, $Id: allseer.editPayProf.php,v 1.17 2002/09/02 21:35:50 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//
require_once("allseer.UserSqlConn.php");
require_once("allseer.arrayLoader.php");
require_once("allseer.validator.php");

class pp_editor
{
    //  fields used by the View Profile Screen section
    var $viewProfName = FALSE;
    var $viewProfile = FALSE;
    var $viewProfileSer = FALSE;   //serialized
    var $currentProfileAry = FALSE;
    var $uid = FALSE;
    var $validationFlag = FALSE;
    var $Messages = FALSE;

    ////////////////////////////////////////////////////////////////////
    function pp_editor () {
        $this->validationFlag = FALSE;
        $this->Messages = array();
    }

////////////////////////////////////////////////////////////////////////
//                 L O C A L     F U N C T I O N S                    //
////////////////////////////////////////////////////////////////////////
    function setValidationFlag($v) {
        $this->validationFlag= !!$v;
    }

////////////////////////////////////////////////////////////////////////
//             I N T E R F A C E    F U N C T I  O N S                //
////////////////////////////////////////////////////////////////////////
    //  return the current state of the validation flag
    function validated(){
        return($this->validationFlag);
    }

    //  edit check all of the form fields
    function validateFields() {
        $myMsgs =& $this->Messages;
        $myMsgs= array();
        //  nothing to do since the screen was redesigned
        $this->setValidationFlag((count($this->Messages) == 0));
        return($this->validated());
    }
    //  returns true if a batabase update is required
    function needsDBUpdate() {
        $needsIt= FALSE;
        $cProfile=& $this->currentProfileAry;

        for ($i=0; $i<count($cProfile) && !$needsIt; $i++) {

            $f= ($cProfile[$i]["active"] == 't') ? 'Y' : 'N';
            $needsIt= !($f == $cProfile[$i]["display"]);

        }
        return($needsIt);
    }

    ////////////////////////////////////////////////////////////////////
    //  all fields have been validated for a new profile.  do the
    //  requisite database updates.
    function dbUpdate() {
        $this->validationFlag = FALSE;
        $myRC= TRUE;

        if ($this->needsDBUpdate()) {
            $conn = new UserSqlConn();
            $conn->openConnection();

            $myTransState = "continue";
            $myRC = FALSE;  //  TRUE only if the transaction succeeds

            //  start the transaction
            if (!$conn->executeQuery("begin work;")) {
                $myTransState = "exit";
                $this->sqlMessage = "editPayProf::dbUpdate: close site 1==>" . $conn->getErrorMessage();
                syslog(LOG_ERR, $this->sqlMessage);
            }

            $cProfile=& $this->currentProfileAry;
            for ($i=0; $i<count($cProfile) && $myTransState == "continue"; $i++) {
                $f= ($cProfile[$i]["display"] == 'Y') ? 't' : 'f';
                if ($f != $cProfile[$i]["active"]) {
                    if (!$conn->updatePayProfileActive($cProfile[$i]['oid'], $f)) {
                        $myTransState = "rollback";
                        $this->sqlMessage = "editPayProf::dbUpdate: close site 2==>" . $conn->getErrorMessage();
                        syslog(LOG_ERR, $this->sqlMessage);
                    }
                }
            }

            //  end of transaction.  commit or rollback.
            //echo("<br>EOT \$myTransState = $myTransState");
            if ($myTransState == "continue") {
                if ($conn->executeQuery("commit work;")) {
                    $myRC = TRUE;

                } else {
                    $myTransState = "rollback";
                    $this->sqlMessage = "editPayProf::dbUpdate: Transaction commit failure" . $conn->getErrorMessage();
                    syslog(LOG_ERR, $this->sqlMessage);
                }
            }

            if ($myTransState == "rollback") {
                syslog(LOG_ERR, "editPayProf::dbUpdate: Transaction failure.  Rolling back");
                $conn->executeQuery("rollback");
                $myTransState = "exit";
            }
            $conn->closeConnection();
        }

        return($myRC);
    }
    ////////////////////////////////////////////////////////////////////
    function setView ($viewArg) {

        $conn= new UserSqlConn();

        $this->viewProfName = FALSE;
        $this->viewProfile = FALSE;
        $this->viewProfileSer = FALSE;
        $this->viewProfileProppa = FALSE;

        if ($dbAry= $conn->fetchUserPPDetails($this->uid, $viewArg)) {
            $this->viewProfName= $dbAry[0]["name"];
            $this->viewProfProppa= $dbAry[0]["proppa"];
            $this->viewProfProppaType= $dbAry[0]["proppa_tp"];
            $this->viewProfile= array();

            $vAry=& $this->viewProfile;
            for ($i=0; $i< count($dbAry); $i++) {
                $vAry[$i]["pc"]= $dbAry[$i]["pc"];
                $vAry[$i]["found"]= $dbAry[$i]["found"];
            }
            $this->viewProfileSer= serialize($this->viewProfile);
        }
        return(TRUE);
    }

    ////////////////////////////////////////////////////////////////////
    function setActiv($i, $val) {
        $this->currentProfileAry[$i]["display"]= $val == "Yes" ? "Y" : "N";
    }

    ////////////////////////////////////////////////////////////////////
    function init ($uid, $conn= FALSE) {
        $this->uid= $uid;

        $arrayLoader = new arrayLoader;
        $this->Foundations = $arrayLoader->loadFoundations();

        ///////////////////////////////////////////////////////////////
        $this->currentProfileAry= array();
        $cProfile=& $this->currentProfileAry;

        if (!$conn) {
            $conn= new UserSqlConn();
        }

        $cProfile= $conn->fetchUserPayProfiles($uid);
        for ($i=0; $i < count($cProfile) ; $i++) {
            $conn->stripShit($cProfile[$i]);

            $id= $cProfile[$i]["id"];
            $cProfile[$i]["display"]= ($cProfile[$i]["active"] == 't') ? 'Y' : 'N';
            $cProfile[$i]["viewArgs"]= "u=$uid&v=$id";
        }

        ///////////////////////////////////////////////////////////////
        $this->activeProfileAry= array();
        $aProfile=& $this->activeProfileAry;
        for ($i=0; $i < count($cProfile); $i++) {
            if ($cProfile[$i]["active"] == 't') {
                $aProfile[]= $cProfile[$i];
            }
        }

        return(TRUE);
    }
}
?>
