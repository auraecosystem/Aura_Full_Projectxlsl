<?php
//  $Name: ORG-TEST $, $Id: allseer.clientProfile-save.php,v 1.4 2002/09/02 21:35:30 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  This is a class for validating client user fields from a form     //
//  and, updating the database client user information attributes     //
//  apprpriately.                                                     //
////////////////////////////////////////////////////////////////////////
require_once("allseer.UserSqlConn.php");
require_once("allseer.validator.php");

class clientProfile
{
    ////////////////////////////////////////////////////////////////////
    //  Constructor
    function clientProfile () {
        $this->Messages = array();
        $this->dbConnection = new UserSqlConn;
    }

########################################################################
##   Private Functions   ###############################################
########################################################################
    ////////////////////////////////////////////////////////////////////
    //  get a user row from the database for this client.  use the row
    //  to initialize form fields.
    ////
    //  TODO:  add Tip financials:  tips this month and tips this year
    ////
    function initFormFields() {
        $myRc = TRUE;

        // make sure that the login exists and read user attributes
        $conn = &$this->dbConnection;
        if (!$myRc = $conn->loginExists($this->uid)) {
            syslog(LOG_ERR, "clientProfile::initFormFields: no user login for '$this->uid'");

        } else if (!$myRc = $this->origUserRow= $myRow = $conn->fetchUserAttrs($this->uid)) {
            syslog(LOG_ERR, "clientProfile::initFormFields: can't read user data for '$this->uid'");

        } else {
            $this->First =      $myRow['user_first_nm'] ? $myRow['user_first_nm'] : FALSE;
            $this->Last =       $myRow['user_last_nm'] ? $myRow['user_last_nm'] : FALSE;
            $this->Email =      $myRow['user_fwd_email'] ? $myRow['user_fwd_email'] : FALSE;
            $this->Company =    $myRow['user_company'] ? $myRow['user_company'] : FALSE;
            $this->Address1 =   $myRow['user_address1'] ? $myRow['user_address1'] : FALSE;
            $this->Address2 =   $myRow['user_address2'] ? $myRow['user_address2'] : FALSE;
            $this->City =       $myRow['user_city'] ? $myRow['user_city'] : FALSE;
            $this->Zip =        $myRow['user_postal_cd'] ? $myRow['user_postal_cd'] : FALSE;
            $this->State =      $myRow['user_state_prov'] ? $myRow['user_state_prov'] : FALSE;
            $this->Country =    $myRow['user_country'] ? $myRow['user_country'] : FALSE;
        }
        
        //  read client attributes
        if ($myRc) {
            if (!$myRc= $this->origClientRow= $myRow = $conn->fetchClientAttrs($this->uid)) {
                syslog(LOG_ERR, "clientProfile::initFormFields: can't read client data for '$this->uid'");

            } else {
                $this->TipHistory =  $myRow['client_tip_history'] ? $myRow['client_tip_history'] : "Private";
                $this->RateNotify =  $myRow['client_rate_notify'] ? $myRow['client_rate_notify'] : 'f';
                $this->GiftNotify =  $myRow['client_gift_notify'] ? $myRow['client_gift_notify'] : 'f';
                
                if ($myClid = $myRow['client_uid']) {
                    $this->tipsMonth = ((float)$conn->clientMonthlyTips($myClid)) / 100;
                    $this->tipsYear  = ((float)$conn->clientYearlyTips($myClid)) / 100;
                }
            }
        }
        ///////////////////////////////////////////////////////////////
        //  build a list of e-mail addresses associated with this
        //  user.  make sure that the current forwarding e-mail
        //  address is first on the list.
        ////
        
        if ($myRc= ($myRc && $emailAry= $conn->fetchAltEmailArray($this->uid))) {
            if (count($emailAry) > 1) {
                //  only keep the active addresses.  put the forwarding
                //  email address in the first array element.
                $first= array();
                for($i=0; $i<count($emailAry); $i++) {
                    if ($emailAry[$i]['activep'] == "t") {
                        if ($emailAry[$i]['addy'] == $myUserRow['user_fwd_email']) {
                            $first[]= $emailAry[$i];
                            
                        } else {
                            $r[]= $emailAry[$i];
                        }
                    }
                }
                $emailAry= array_merge($first, $r);
            }
            $this->emailSelectionAry= $emailAry;
        }
        return($myRc);
    }

    ////////////////////////////////////////////////////////////////////
    //  get data from form fields and update the appropriate data base
    //  tables.
    function updateDBFields() {
        $myRc = TRUE;
        $this->validationFlag = FALSE;
        //  Make sure that the login exists.  This is actually a
        //  sanity check.  should never get here, so bitch on
        //  the log.
        $conn = &$this->dbConnection;

        if (!$conn->loginExists($this->uid)) {
            $myRc = FALSE;
            syslog(LOG_ERR, "clientProfile::updateDBFields:  No such user '$this->uid'");

        } else {
            ////////////////////////////////////////////////////////////
            //  everything in this branch is a database transaction.  The
            //  variable $myTransState is it's state variable.
            ////
            //  move selected screen attributes into an array and use them
            //  to update the user table.
            $myTransState = "continue";
            $myRc = FALSE;  //  TRUE only if the transaction succeeds

            //  start the transaction
            if (!$conn->executeQuery("begin work;")) {
                $myTransState = "exit";
                $this->sqlMessage = "clientProfile::updateDBFields: close site 1==>" . $conn->getErrorMessage();
                syslog(LOG_ERR, $this->sqlMessage);

            }
            
            //  continue... read user fields
            $orig=& $this->origUserRow;
            if (!$orig && $myTransState == "continue" && !$orig = $conn->fetchUserAttrs($this->uid)) {
                $this->sqlMessage = "clientProfile::updateDBFields: fetchUserAttrs() failed" . $conn->getErrorMessage();
                $myTransState = "rollback";
                syslog(LOG_ERR, $this->sqlMessage);
            }

            //  continue... update user fields
            if ($myTransState == "continue") {
                $newRow = array();
                //  map object attribute names on to user row
                //  attribute names
                $myMap = array (
                    "user_passwd"       => "Password1",
                    "user_first_nm"     => "First",
                    "user_last_nm"      => "Last",
                    "user_fwd_email"    => "Email",
                    "user_company"      => "Company",
                    "user_address1"     => "Address1",
                    "user_address2"     => "Address2",
                    "user_city"         => "City",
                    "user_postal_cd"    => "Zip",
                    "user_state_prov"   => "State",
                    "user_country"      => "Country"
                    );

                while(list($db, $frm)= each($myMap)) {
                    if ($this->$frm) {
                        $newRow["$db"]= $frm;
                }

                if (!($myRc= $conn->updateUserAttrs($orig, $newRow))) {
                    $this->sqlMessage = "clientProfile::updateDBFields: user attr update failure " . $conn->getErrorMessage();
                    $myTransState = "rollback";
                    syslog(LOG_ERR, $this->sqlMessage);
                }
            }
            
            //  continue... read client fields
            $orig=& $this->origClientRow;
            if ($myTransState == "continue") {
                if (count($orig) == 0 && !($orig= $conn->fetchClientAttrs($this->uid))) {
                    $this->sqlMessage = "clientProfile::updateDBFields: fetchClientAttrs() failed" . $conn->getErrorMessage();
                    $myTransState = "rollback";
                    syslog(LOG_ERR, $this->sqlMessage);
                }
            }
    
            //  continue... update the client fields
            if ($myTransState == "continue") {
                $newRow = array();
                $newRow['client_tip_history'] = ($this->TipHistory == "Public") ? 'Public' : 'Private';
                $newRow['client_rate_notify'] = ($this->RateNotify == 't') ? 't' : 'f';
                $newRow['client_gift_notify'] = ($this->GiftNotify == 't') ? 't' : 'f';
                
                if (!($myRc= $conn->updateClientAttrs($orig, $newRow))) {
                    $this->sqlMessage = "clientProfile::updateDBFields: Client attr update failure " . $conn->getErrorMessage();
                    $myTransState = "rollback";
                    syslog(LOG_ERR, $this->sqlMessage);
                }
            }
            //  end of transaction.  commit or rollback.
            if ($myTransState == "continue") {
                if ($conn->executeQuery("commit work;")) {
                    $myRc = TRUE;
                
                } else {
                    $myTransState = "rollback";
                    $this->sqlMessage = "clientProfile::updateDBFields: Transaction commit failure" . $conn->getErrorMessage();
                    syslog(LOG_ERR, $this->sqlMessage);
                }
            }
            if ($myTransState == "rollback") {
                syslog(LOG_ERR, "clientProfile::updateDBFields: Transaction failure.  Rolling back");
                $conn->executeQuery("rollback");
                $myTransState = "exit";
            }
        }
        return($myRc);
    }


    ////////////////////////////////////////////////////////////////////
    //  move HTTP POST variables into object attributes
    function readPostVariables() {
        global $HTTP_POST_VARS;
        $myPostVars= $HTTP_POST_VARS;

        $this->RateNotify= isset($myPostVars['FormRateNotify']) ? $myPostVars['FormRateNotify'] : FALSE;
        unset($myPostVars['FormRateNotify']);

        $this->GiftNotify= isset($myPostVars['FormGiftNotify']) ? $myPostVars['FormGiftNotify'] : FALSE;
        unset($myPostVars['FormGiftNotify']);

        //  get rid of some crap
        unset($myPostVars['u']);
        unset($myPostVars['FormValidate']);

        //  and move the rest of the post variables into object
        //  attributes,  mainly for convenience.
        reset($myPostVars);
        while (list($var, $value) = each($myPostVars)) {
            list($attrName)= sscanf($var, "Form%s");
            if ($attrName != "") {
                $this->$attrName= $value;
                unset($myPostVars["$var"]);
            }
        }

        //echo("<br>clientProfile::readPostVariables() \$HTTP_POST_VARS --post-- "); var_dump($myPostVars);
        return(TRUE);
    }

########################################################################
##   Interface Functions   #############################################
########################################################################
    ////////////////////////////////////////////////////////////////////
    //  edit check all of the form fields
    function validateFields() {
        $this->Messages = array();
        $this->readPostVariables();
        
        $v= new asValidator();
        $v->CLEAR= TRUE;

        ////////////////////////////////////////////////////////////////
        ////////////////    billing fields    //////////////////////////
        if ($this->First == "" ) {
            $this->Messages['First'] = $this->billMessages[]= "FIRST NAME IS REQUIRED";
            
        } elseif (!$v->is_user_first($this->First))  {
            $this->Messages['First'] = $this->billMessages[]= $v->ERROR;
        }
    
        ////////////////////////////////////////////////////////////////
        if ($this->Last == "" ) {
            $this->Messages['Last'] = $this->billMessages[]= "LAST NAME IS REQUIRED";
            
        } elseif (!$v->is_user_last($this->Last))  {
            $this->Messages['Last'] = $this->billMessages[]= $v->ERROR;
        }

        ////////////////////////////////////////////////////////////////
        if ($this->Company == "" ) {
            $this->Messages['Company'] = $this->billMessages[]= "COMPANY NAME IS REQUIRED";
                    
        } elseif (!$v->is_user_company($this->Company))  {
            $this->Messages['Company'] = $this->billMessages[]= $v->ERROR;
        }

        ////////////////////////////////////////////////////////////////
        if ($this->Address1 == "" ) {
            $this->Messages['Address1'] = $this->billMessages[]= "ADDRESS IS REQUIRED";
                            
        } elseif (!$v->is_user_address($this->Address1))  {
            $this->Messages['Address1'] = $this->billMessages[]= $v->ERROR;
        }

        if ($this->Address2 != "" && !$v->is_user_address($this->Address2)) {
            $this->Messages['Address2'] = $this->billMessages[]= $v->ERROR;
        }

        ////////////////////////////////////////////////////////////////
        if ($this->City == "" ) {
            $this->Messages['City'] = $this->billMessages[]= "CITY IS REQUIRED";
                            
        } elseif (!$v->is_user_city($this->City))  {
            $this->Messages['City'] = $this->billMessages[]= $v->ERROR;
        }

        ////////////////////////////////////////////////////////////////
        if ($this->Zip == "" ) {
            $this->Messages['Zip'] = $this->billMessages[]= "ZIP/POSTAL CODE IS REQUIRED";
                                    
        } elseif (!$v->is_user_zip($this->Zip))  {
            $this->Messages['Zip'] = $this->billMessages[]= $v->ERROR;
        }

        ////////////////////////////////////////////////////////////////
        if ($this->State == "" ) {
            $this->Messages['State'] = $this->billMessages[]= "STATE/PROVINCEIS IS REQUIRED";
        }
        ////////////////////////////////////////////////////////////////
        if ($this->Country == "" ) {
            $this->Messages['Country'] = $this->billMessages[]= "COUNTRY IS REQUIRED";
        }

        ////////////////////////////////////////////////////////////////
        ///////////////////    security    /////////////////////////////
        $this->pswdMessages= array();
        if (!($this->Password1 == "" && $this->Password2 == "")) {
            if ($this->Password1 != $this->Password2)  {
                $this->Messages['Password'] = $this->pswdMessages[]= "PASSWORDS MUST MATCH";

            } elseif (!eregi("^[0-9a-zA-Z_]*$", $this->Password1))  {
                $this->Messages['Password'] = $this->pswdMessages[]= "PASSWORD MUST BE LETTERS, DIGITS AND UNDERSCORE";

            } elseif (strlen($this->Password1) < 6) {
                $this->Messages['Password'] = $this->pswdMessages[]= "PASSWORD MUST BE AT LEAST 6 CHARACTERS";
            }
        }
        $this->validationFlag = (count($this->Messages) == 0);

        return($this->validated());
    }
    ////////////////////////////////////////////////////////////////////
    function validated(){
        return($this->validationFlag);
    }
    ////////////////////////////////////////////////////////////////////
    function setUserLogin($uid){
        $this->uid= $uid;
        return(TRUE);
    }
    ////////////////////////////////////////////////////////////////////
    function init_private($uid) {
        $myRC = TRUE;

        $this->uid = $uid;
        $myRC = $this->initFormFields();
        return($myRC);
    }
    ////////////////////////////////////////////////////////////////////
    //
    function dbMaint() {
        $this->validationFlag = FALSE;
        $myRC = TRUE;
        $conn = &$this->dbConnection;
        $conn->openConnection();

        $myRC = $this->updateDBFields();

        $conn->closeConnection();
        return($myRC);
    }
}
?>