<?
require_once("allseer.variousFunctions.php");

//  $Name: ORG-TEST $, $Id: config.inc.php,v 1.22 2002/05/03 20:32:42 leed Exp $
////////////////////////////////////////////////////////////////////////
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
//                             Logging
define_syslog_variables();
openlog("ALLSEER-WEB", LOG_ODELAY, LOG_USER);
error_reporting(E_ALL & ~(E_WARNING | E_NOTICE));

////////////////////////////////////////////////////////////////////////
//                        Database Settings
//
//  defaults are overridden in host local config files
$dbhost = "localhost";         //   database host machine
$dbname = "allseer";           //   name of the database.
$dbuname = "allseer";          //   user name
$dbpass = "";                  //   password used to acce

////////////////////////////////////////////////////////////////////////
//                           Payment Related
$paySecureHost = "vault.affero.net";  //https: for payments.  testing only
$curlProg= "/usr/local/bin/curl";
$payDetailDemo = "y";

$MINIMUM_TIP  = "5";
$MAXIMUM_TIP = "1000";

////////////////////////////////////////////////////////////////////////
//              Local (per server host) configuration
preg_match("/^([^\/.]*)/", $HTTP_SERVER_VARS["SERVER_NAME"], $splitAry);
$testHost= $splitAry[0];

////////////////////////////////////////////////////////////////////////
//                     MD5 Keys and stuff like that
$HasherCloakerKey =
    "But born, alas, in an evil time," .
    "I missed that pleasant haven," .
    "For the hair has grown on my upper lip" .
    "And the clergy are all clean-shaven." .
    "                   --G.Orwell";

$HasherEmailMungerKey=
    "I dreamt I dwelt in marble halls," .
    "And woke to find it true;" .
    "I wasn't born for an age like this;" .
    "Was Smith? Was Jones? Were you?" .
    "                   --G.Orwell";
$HasherPasswordMungerKey=
    "It is forbidden to dream again;" .
    "We maim our joys or hide them:" .
    "Horses are made of chromium steel" .
    "And little fat men shall ride them." .
    "                   --G.Orwell";

$HasherSessionMungerKey=
    "I am the worm who never turned," .
    "The eunuch without a harem;" .
    "Between the priest and the commissar" .
    "I walk like Eugene Aram;" .
    "                   --G.Orwell";

$PayDetailsMunger= "FluffyBunny";
////////////////////////////////////////////////////////////////////////
//                                 Misc
$sessionLogInterval= "6 hours";
$configgedForLive= FALSE;

$logMail= false;
$dpyMail= false;
$sendMail= true;
$dumpargsMail= false;

////////////////////////////////////////////////////////////////////////
//                          Branch Identifier
//  If the global $CVSBranchId is set then it's value is displayed
//  in a centered red box on the home page
if (file_exists("{$HTTP_SERVER_VARS['DOCUMENT_ROOT']}/CVS/Tag")) {
    $tagAry= file("{$HTTP_SERVER_VARS['DOCUMENT_ROOT']}/CVS/Tag");
    preg_match("/(.)(.*)/", $tagAry[0], $tagMatches);
    if (isset($tagMatches[2])) {
        if ($tagMatches[1] == "T"){
            $CVSBranchId= "Branch-- ";
            
        } else if ($tagMatches[1] == "N"){
            $CVSBranchId= "Tag-- ";
            
        } else if ($tagMatches[1] == "D"){
            $CVSBranchId= "Date-- ";
            
        } else {
            $CVSBranchId= "UNK-- ";
        }
        $CVSBranchId .= $tagMatches[2];
    }   
}
//  host dependent shit.  load  a host dependent config
//  file if it exists
$localConfig= "config-local.{$testHost}.inc";
if (include_path_file_exists($localConfig)) {
    include($localConfig);
}

?>
