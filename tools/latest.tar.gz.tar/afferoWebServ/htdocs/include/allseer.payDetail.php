<?php
//  $Name: ORG-TEST $, $Id: allseer.payDetail.php,v 1.30 2002/11/25 17:50:49 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//
require_once("allseer.profileObject.php");
require_once("allseer.UserSqlConn.php");

class payDetail
{

    ////////////////////////////////////////////////////////////////////
    function payDetail () {
        $this->validationFlag= FALSE;
        $this->TOS= "UNCHECKED";
        $this->dbUserAttrs= array();
    }

    ////////////////////////////////////////////////////////////////////
    //  move HTTP POST variables into object attributes
    function readPostVariables() {
        global $HTTP_POST_VARS;
        $myPostVars= $HTTP_POST_VARS;

        //  get rid of some crap
        unset($myPostVars['FormValidate']);

        //  and move the rest of the post variables into object
        //  attributes,  mainly for convenience.
        reset($myPostVars);
        while (list($var, $value) = each($myPostVars)) {
            list($attrName)= sscanf($var, "Form%s");
            if ($attrName != "") {
                $this->$attrName= $value;
                unset($myPostVars["$var"]);
            }
        }
        return(TRUE);
    }    
    
########################################################################
##   Interface Functions   #############################################
########################################################################
    ////////////////////////////////////////////////////////////////////
    //  edit check all of the form fields
    function validateFields() {
        include_once("allseer.validator.php");
        
        $v= new asValidator();
        $v->CLEAR= TRUE;
        
        $this->Messages = array();
        $this->readPostVariables();
        
        $origUserRow=& $this->dbUserAttrs;
        ////////////////////////////////////////////////////////////////
        ////////////////    billing fields    //////////////////////////
        $this->billMessages= array();
        if (!isset($this->First) || $this->First == "") {
            $this->Messages['First'] = $this->billMessages[]= "FIRST NAME IS REQUIRED";
            
        } else if ($this->First != $this->origUserRow['user_first_nm'] && !$v->is_user_first($this->First))  {
            $this->Messages['First'] = $this->billMessages[]= $v->ERROR;
        }
        ////////////////////////////////////////////////////////////////
        if (!isset($this->Last) || $this->Last == "") {
            $this->Messages['Last'] = $this->billMessages[]= "LAST NAME IS REQUIRED";
            
        } else if ($this->Last != $this->origUserRow['user_last_nm'] && !$v->is_user_last($this->Last))  {
            $this->Messages['Last'] = $this->billMessages[]= $v->ERROR;
        }
        ////////////////////////////////////////////////////////////////
        if (!isset($this->Phone) || $this->Phone == "") {
            $this->Messages['Phone'] = $this->billMessages[]= "PHONE NUMBER IS REQUIRED";
            
        } else if ($this->Phone != $this->origUserRow['user_phone_nm'] && !$v->is_user_phone($this->Phone))  {
            $this->Messages['Phone'] = $this->billMessages[]= $v->ERROR;
        }
        ////////////////////////////////////////////////////////////////
        if ($this->Company != $this->origUserRow['user_company'] && !$v->is_user_company($this->Company))  {
            $this->Messages['Company'] = $this->billMessages[]= $v->ERROR;
        }
        ////////////////////////////////////////////////////////////////
        if (!isset($this->Address1) || $this->Address1 == "") {
            $this->Messages['Address1'] = $this->billMessages[]= "ADDRESS IS REQUIRED";
            
        } else if ($this->Address1 != $this->origUserRow['user_address1'] && !$v->is_user_address($this->Address1))  {
            $this->Messages['Address1'] = $this->billMessages[]= $v->ERROR;
        }

        if ($this->Address2 != "" && !$v->is_user_address($this->Address2)) {
            $this->Messages['Address2'] = $this->billMessages[]= $v->ERROR;
        }
        ////////////////////////////////////////////////////////////////
        if (!isset($this->City) || $this->City == "") {
            $this->Messages['City'] = $this->billMessages[]= "CITY IS REQUIRED";

        } else if ($this->City != $this->origUserRow['user_city'] && !$v->is_user_city($this->City))  {
            $this->Messages['City'] = $this->billMessages[]= $v->ERROR;
        }
        ////////////////////////////////////////////////////////////////
        if (!isset($this->Country) || $this->Country== "") {
            $this->Messages['Country'] = $this->billMessages[]= "COUNTRY IS REQUIRED";
        }
        ////////////////////////////////////////////////////////////////
        if ($v->is_UnitedStates($this->Country)) {
            if (!isset($this->State) || $v->is_NoState($this->State)) {
                $this->Messages['State'] = $this->billMessages[]= "STATE IS REQUIRED";
            }
        } else {
            $this->State= $v->setNoState();
        }
        ////////////////////////////////////////////////////////////////
        if (!isset($this->Zip) || $this->Zip == "") {
            $this->Messages['Zip'] = $this->billMessages[]= "ZIP/POSTAL CODE IS REQUIRED";
            
        } else if ($v->is_UnitedStates($this->Country) && ($this->Zip != $this->origUserRow['user_postal_cd'] && !$v->is_user_zip($this->Zip)))  {
            $this->Messages['Zip'] = $this->billMessages[]= $v->ERROR;
        }
        ////////////////////////////////////////////////////////////////
        if (isset($this->TOS) && $this->displayTOS && $this->TOS == "UNCHECKED") {
            $this->Messages['TOS'] = $this->billMessages[]= "YOU MUST ACCEPT THE TERMS OF SERVICE IN ORDER TO CONTINUE";
        }
        
        
        $this->validationFlag = !count($this->Messages);
        return($this->validated());
    }

    ////////////////////////////////////////////////////////////////////
    //  get a user row from the database for this client.  use the row
    //  to initialize form fields.
    function initUserFormFields() {

        // Create a new DB connection.
        $conn = new UserSqlConn();
        $myRow = $this->dbUserAttrs = $conn->fetchUserAttrs($this->cl);

        $this->First =    $myRow['user_first_nm'] ? $myRow['user_first_nm'] : FALSE;
        $this->Last =     $myRow['user_last_nm'] ? $myRow['user_last_nm'] : FALSE;
        $this->Company =  $myRow['user_company'] ? $myRow['user_company'] : FALSE;
        $this->Address1 = $myRow['user_address1'] ? $myRow['user_address1'] : FALSE;
        $this->Address2 = $myRow['user_address2'] ? $myRow['user_address2'] : FALSE;
        $this->City =     $myRow['user_city'] ? $myRow['user_city'] : FALSE;
        $this->Zip =      $myRow['user_postal_cd'] ? $myRow['user_postal_cd'] : FALSE;
        $this->State =    $myRow['user_state_prov'] ? $myRow['user_state_prov'] : FALSE;
        $this->Country =  $myRow['user_country'] ? $myRow['user_country'] : FALSE;
        $this->Phone =    $myRow['user_phone'] ? $myRow['user_phone'] : FALSE;        
    }
    
    ////////////////////////////////////////////////////////////////////
    //  update a client user row from the form fields.
    //  TODO:  put in code to do this only if it is required.
    function updateUserAttrs($conn) {
        $newUserAttrs= array();
        
        $newUserAttrs["user_first_nm"] =    $this->First ? str_replace("\\", "\\\\", str_replace("'", "''", trim($this->First))) : "";
        $newUserAttrs["user_last_nm"] =     $this->Last ? str_replace("\\", "\\\\", str_replace("'", "''", trim($this->Last))) : "";
        $newUserAttrs["user_company"] =     $this->Company ? str_replace("\\", "\\\\", str_replace("'", "''", trim($this->Company))) : "";
        $newUserAttrs["user_address1"] =    $this->Address1 ? str_replace("\\", "\\\\", str_replace("'", "''", trim($this->Address1))) : "";
        $newUserAttrs["user_address2"] =    $this->Address2 ? str_replace("\\", "\\\\", str_replace("'", "''", trim($this->Address2))) : "";
        $newUserAttrs["user_city"] =        $this->City ? str_replace("\\", "\\\\", str_replace("'", "''", trim($this->City))) : "";
        $newUserAttrs["user_postal_cd"] =   $this->Zip ? $this->Zip : "";
        $newUserAttrs["user_state_prov"] =  $this->State ? $this->State : "";
        $newUserAttrs["user_country"] =     $this->Country ? $this->Country : "";
        $newUserAttrs["user_phone"] =       $this->Phone ? $this->Phone : "";

        if (!($myRc= $conn->updateUserAttrs($this->dbUserAttrs, $newUserAttrs))) {
            $this->sMessage = "payD.updateUserAttrs " . $conn->getErrorMessage();
            syslog(LOG_ERR, $this->sMessage);
        }
        return($myRc);
    }
    
    ////////////////////////////////////////////////////////////////////
    function validated(){
        return($this->validationFlag);
    }
    
    ////////////////////////////////////////////////////////////////////
    function makeProfileAry(){
        $profo= new profileObject();
        $profo->profileID= $this->pid;
        $myRc= $profo->consProfileAry();
        //echo("<br><br>profile ary..."); var_dump($myRc);
        return($myRc);
    }
    
    ////////////////////////////////////////////////////////////////////
    function dbConnectionArgs() {
        $conn= new UserSqlConn();
        return($conn->dbConnectionArgs());
    }
    
    ////////////////////////////////////////////////////////////////////
    //  all fields on a ratings screen have been validated.  do the
    //  requisite database updates.
    function dbUpdate() {
        $this->validationFlag = FALSE;
        $conn = new UserSqlConn();
        $conn->openConnection();
            
        $myRC = TRUE;
        //  if the database row is not present, then re read it
        if (!count($this->dbUserAttrs)) {
            $this->dbUserAttrs = $conn->fetchUserAttrs($this->cl);
        }
        //  only update database fields for active users
        if ($conn->loginActive($this->cl)) {
            $this->updateUserAttrs($conn);
        }
        
        $conn->closeConnection();
        return($myRC);
    }
    
    ////////////////////////////////////////////////////////////////////
    //  generate a string which will be written to the trustCommerce
    //  transaction database.  Currently this string is
    //  p=<profile_id>,t=<tip_id>
    function makeTicket() {
        $conn = new UserSqlConn();
        $myRC = "";

        $myAry= $conn->fetchTipProfileIds($this->TipOID);
        if (count($myAry) == 1) {
            $myRC= sprintf("p=%d,t=%d", $myAry[0]['profile_id'], $myAry[0]['tip_id']);
        }
        return($myRC);
    }

    ////////////////////////////////////////////////////////////////////
    //  save URL arguments  if $dbf is true, then set initial client
    //  fields from the datgabase if they exist.
    function init ($re, $cl, $dbf) {
        global $ish;
        $myRC= "OK";
        
        $this->re = $re;
        $this->cl = $cl;

        $this->displayTOS= (preg_match("/^Flo\.[0-9]{6}/", $cl));
        
        if ($dbf){
            $this->initUserFormFields();
        }
        if (isset($ish)) {
            $this->ish= $ish;
        } else {
            $myRC= "Internal error.  session id is missing";
        }
        
        return($myRC);
    }
}
?>