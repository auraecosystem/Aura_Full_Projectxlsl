<?php
//  $Name: ORG-TEST $, $Id: allseer.nuts.php,v 1.5 2002/09/02 21:34:18 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  insert a new user into the database.  this is abstracted because
//  there are a number of seprate places where new users
//  might be created
////////////////////////////////////////////////////////////////////////
require_once("allseer.UserSqlConn.php");
require_once("allseer.smtpMailer.php");

class nuts
{
    ////////////////////////////////////////////////////////////////////
    function nuts($conn= FALSE) {
        $this->localConn= !$conn;
        $this->dbConnection= $conn ? $conn : new UserSqlConn();
    }
    ////////////////////////////////////////////////////////////////////
    function userSkel($myArgs) {
        $trans = "success";
        $conn=& $this->dbConnection;
        
        if ($this->localConn) {
            $conn->openConnection();
        }
        if (!$conn->executeQuery("begin work;")) {
            $trans = "exit";
            $this->sMessage = "nuts::userSkel() close site 1==>" . $conn->getErrorMessage();
            syslog(LOG_ERR, $this->sMessage);

        }
        if ($trans == "success" && !$conn->insertUserRow($myArgs['user_login'], $myArgs['user_fwd_email'], $myArgs['user_passwd'])) {
            $trans = "rollback";
            $this->sMessage = "nuts::userSkel() rollback site 1==>" . $conn->getErrorMessage();
            syslog(LOG_ERR, $this->sMessage);
                    
        }
        if ($trans == "success" && !$conn->insertEmailRow($myArgs['user_fwd_email'])) {
            $trans = "rollback";
            $this->sMessage = "nuts::userSkel() rollback site 2==>" . $conn->getErrorMessage();
            syslog(LOG_ERR, $this->sMessage);

        }
        if ($trans == "success" && !$conn->insertExpertRow($myArgs['user_fwd_email'])) {
            $trans = "rollback";
            $this->sMessage = "nuts::userSkel() rollback site 3==>" . $conn->getErrorMessage();
            syslog(LOG_ERR, $this->sMessage);

        }
        if ($trans == "success" && !$conn->insertClientRow($myArgs['user_fwd_email'])) {
            $trans = "rollback";
            $this->sMessage = "nuts::userSkel() rollback site 4==>" . $conn->getErrorMessage();
            syslog(LOG_ERR, $this->sMessage);
            
        }
        
        if ($trans == "success") {
            $trans = ($conn->executeQuery("commit work;")) ? "success" : "exit";
            
        } else if ($trans == "rollback") {
            $conn->executeQuery("rollback work");
        }
        if ($this->localConn) {
            $conn->closeConnection();
        }
        return(!strcmp($trans, "success"));
    }
}
?>
