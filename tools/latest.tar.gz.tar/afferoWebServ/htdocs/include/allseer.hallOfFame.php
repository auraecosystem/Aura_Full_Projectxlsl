<?php
//  $Name: ORG-TEST $, $Id: allseer.hallOfFame.php,v 1.10 2002/03/19 02:47:07 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  this class loads array definitions from require files if they     //
//  exist.  if tthey do not exist, then they are built and stored in  //
//  $DOCUMENT_ROOT/include/data/<name>.php                            //
////////////////////////////////////////////////////////////////////////
require_once("allseer.UserSqlConn.php");
require_once("allseer.arrayLoader.php");

class hallOfFame
{
    var $experts = FALSE;
    var $clients = FALSE;
    var $foundations = FALSE;
    
    //  for summary aggregations
    var $timeFrame = FALSE;          //  "week" or "year"
    var $summaryType = FALSE;        //  "client" of "expert"
    var $columnThree = FALSE;        //  Column three heading
    
    //  constructor
    function hallOfFame() {
    }

////////////////////////////////////////////////////////////////////////
//                 L O C A L     F U N C T I O N S                    //
////////////////////////////////////////////////////////////////////////
    function genExpertsArray() {
        $arrayLoader = new arrayLoader;

        if ($myExperts = $arrayLoader->loadExpertHOF("wk")) {
            for ($i = 0; $i < sizeof($myExperts); $i++) {
                $myExperts[$i]["avg"] = round($myExperts[$i]["avg"], 1);
                $myExperts[$i]["login"] = trim($myExperts[$i]["login"]);
            }
        }
        return($myExperts);
    }

    function genClientsArray() {
        $arrayLoader = new arrayLoader;

        if ($myClients = $arrayLoader->loadClientHOF("wk")) {
            for ($i = 0; $i < sizeof($myClients); $i++) {
                $myClients[$i]["avg"] = round($myClients[$i]["avg"], 1);
                $myClients[$i]["bux"] /= 100;
                $myClients[$i]["login"] = trim($myClients[$i]["login"]);

            }
        }
        return($myClients);
    }
    //  booleans
    function is_expert() {
        return($this->summaryType == "Expert");
    }
    function is_client() {
        return($this->summaryType == "Client");
    }

////////////////////////////////////////////////////////////////////////
//              I N T E R F A C E    F U N C T I O N S                //
////////////////////////////////////////////////////////////////////////

    function frontPageInitialize(){
        $myRc = FALSE;

        $myExperts =& $this->experts;
        $myClients =& $this->clients;
        $myFoundations =& $this->foundations;
        $arrayLoader = new arrayLoader;

        $myExperts = $this->genExpertsArray();
        $myClients = $this->genClientsArray();

        $myFoundations = $arrayLoader->loadWeeksBeneficiariesHOF();

        $myRc = ($myExperts && $myClients && $myFoundations);
        return($myRc);
    }

    function setTimeFrame($tf) {
        $myRC =& $this->timeFrame;

        if ($tf == "Weekly" || $tf == "weekly" || $tf == "Week" || $tf == "week") {
            $myRC = "Weekly";

        } else if ($tf == "Yearly" || $tf == "yearly" || $tf == "Year" || $tf == "year") {
            $myRC = "Yearly";

        } else {
            $myRC = FALSE;
        }
        return($myRC);
    }

    function setSummaryType($tp) {
        $myRC =& $this->summaryType;

        if ($tp == "Client" || $tp == "client") {
            $myRC= "Client";

        } else if ($tp == "Expert" || $tp == "expert") {
            $myRC= "Expert";

        } else {
            $myRC= FALSE;
        }
        return($myRC);
    }

    function getSummary() {
        $type =& $this->summaryType;
        $myRc= FALSE;
        
        if ($this->is_expert()) {
            $myRC= $this->genExpertsArray();
            $this->columnThree= "Ratings";

        } else if ($this->is_client()){
            $myRC= $this->genClientsArray();
            $this->columnThree= "Donations";

        }
        return($myRC);
    }
}
?>