<?php
//  $Name: ORG-TEST $, $Id: allseer.newUser.php,v 1.40 2002/10/23 22:59:03 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  This is a class for validating user fields from a form and, in    //
//  the case of new users, for inserting a new user row in the        //
//  database.                                                         //
////////////////////////////////////////////////////////////////////////
//  TODO  --there's a lotta dead code in here.  clean it out.
require_once("allseer.UserSqlConn.php");
require_once("allseer.editAltEmail.php");
require_once("allseer.profileRep.php");
require_once("allseer.hasher.php");
require_once("allseer.nuts.php");
require_once("allseer.smtpMailer.php");
require_once("allseer.validator.php");
require_once("allseer.variousFunctions.php");

class newUser
{
    //  form fields
    var $Login = FALSE;
    var $Password = FALSE;
    var $Email = FALSE;
    var $Name, $Ident = FALSE;

    //other form variables
    var $BarString = FALSE;

    //  internal variables
    var $validationFlag = FALSE;
    var $alreadyInserted = FALSE;
    var $loginScreen = FALSE;
    var $activationScreen = FALSE;
    var $userRow = FALSE;
    var $dbConnection = FALSE;

    var $Messages;

    var $validLoginRegex;
    var $validPasswordRegex;

    ////////////////////////////////////////////////////////////////////
    function newUser () {
        $this->validLoginRegex = "^[0-9a-zA-Z_]*$";
        $this->validPasswordRegex = "^[0-9a-zA-Z_]*$";

        $this->BarString= "";
        $this->authString= "";

        $this->dbConnection= new UserSqlConn();
        $this->userRow= array();
        $this->Messages = array();

        $this->iProfileArgs= array();
        $this->serializedProfileArgs= serialize($this->iProfileArgs);
    }
    ////////////////////////////////////////////////////////////////////
    function init($lg, $ln) {
        $this->BarString= "";
        $this->authString= "";
        //echo("<br><br>newUser::init() entry...");
        $this->loginScreen = !!$lg;
        if ($this->loginScreen && strlen($ln) > 0 ) {
            $conn = $this->dbConnection;

            if ($conn->loginExists($ln)) {
                $this->Login = $ln;

                $this->userRow= $conn->fetchUserAttrs($ln);
                if (is_array($this->userRow)) {
                    $this->authString= $this->userRow['user_status'];
                }
            }
        }

        //echo("<br><br>newUser::init() look for args...");
        if (!$this->loginScreen) {
            //  this is a join screen.  set up profile initialization
            //  args.
            $this->iProfileArgs= array();
            if ($_SERVER['REQUEST_METHOD'] == 'GET') {
                if (isset($_GET['p'])) {
                    $this->iProfileArgs['p']= explode(",", $_GET['p']);
                    if (isset($_GET['u'])) {
                        $this->iProfileArgs['u']= $_GET['u'];
                    }
                }
                //echo("<br><br>iProfileArgs..."); print_r($this->iProfileArgs);

            } else if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['spa'])) {
                $this->iProfileArgs= unserialize(urldecode($_POST['spa']));
            }
            $this->serializedProfileArgs= urlencode(serialize($this->iProfileArgs));
        }
        //echo("<br><br>newUser::init() init done...");
    }
    ////////////////////////////////////////////////////////////////////
    function nextUrl() {
        if ($this->activationType == "client") {
            $loc= "client-profile.php?u=" . urlencode($this->Login);

        } elseif ($this->activationType == "expert") {
            $loc= "expert-profile.php?u=" . urlencode($this->Login);

        } else {
            $loc= "error.php?code=" . urlencode("newUser::nexturl() can't determine user type");
        }
        return($loc);
    }

    ////////////////////////////////////////////////////////////////////
    function activateUrl() {
        $loc= "expert-profile.php?u=" . urlencode($this->Login);
        return($loc);
    }

    ////////////////////////////////////////////////////////////////////
    // initialization for account activation                          //
    function initActivation($email, $code, $key) {
        $hashObj= new hasher();
        $conn=& $this->dbConnection;
        $ary=& $this->userRow;

        $this->Messages= array();

        //  get a user row out of the database and set the auth
        //  string
        $myMessages= ($this->Email == "") ? "No Email address.  " : "";
        $ary= $conn->fetchUserAttrsAltEmail($this->Email);

        if ($ary) {
            $this->authString= ($this->authString == "") ? $ary['user_status'] : $this->authString;
        }
        $myMessages .= ($this->authString== "") ? " No authString." : "";

        //  maybe do authorization
        if ($myMessages == "" && ($this->authString == "needs-auth" || $this->authString == "inactivated")) {
            if ($this->activationKey != "") {
                if ($hashObj->emailMunge($this->Email, "client") == $this->activationKey) {
                    $this->activationType= "client";

                } elseif ($hashObj->emailMunge($this->Email, "expert") == $this->activationKey) {
                    $this->activationType= "expert";

                } else {
                    $this->activationType= "";
                    $myMessages= "This activation link has expired";
                }
                if ($this->authString == "inactivated") {
                    $this->Login= $ary['user_login'];

                } else if ($this->activationType != "") {
                    $this->authString= "auth-complete";
                }
            }

        } elseif ($myMessages == "" && ($this->authCheck() == "activated")) {
            //  might need to activate an e-mail address
            if ($hashObj->emailMunge($this->Email, "email") == $this->activationKey) {
                $this->activationType= "email";
            }
        }

        $this->Messages['initActivation']= ($myMessages == "") ? "OK" : $myMessages;
        return($myMessages == "");
    }
    ////////////////////////////////////////////////////////////////////
    function authCheck() {
        return($this->authString);
    }

    ////////////////////////////////////////////////////////////////////
    function compatibleEmailActivate() {
        global $u, $h;

        $hasher= new hasher;
        $eMedit= new em_editor;
        $conn =& $this->dbConnection;

        if (($hasher->emailMunge($u) == $h) && !$eMedit->is_dbDuplicateEmail($this->Email)) {
            if ($conn->insertAltEmail($u, $this->Email)) {
                $this->emailActivate();
            }
        }
    }
    ////////////////////////////////////////////////////////////////////
    function emailActivate() {
        $myRC= TRUE;
        $conn =& $this->dbConnection;

        if ($myRC= !!($altEmail= $conn->fetchAltEmailRow($this->Email))) {
            if ($altEmail['amail_activep'] != 't') {
                ($myRC= !!$conn->setAltEmailRowActivation($this->Email, 't'));
            }
        }
        return($myRC);
    }

    ////////////////////////////////////////////////////////////////////
    function passwordCrypter() {
        $h= new hasher;
        return($h->passwordMunge($this->Password));
    }

    ////////////////////////////////////////////////////////////////////
    function finalizeActivation() {
        $conn =& $this->dbConnection;
        $orig= $updates= $this->userRow;

        $updates['user_login']= $this->Login;
        $updates['user_passwd']= $this->passwordCrypter();
        $updates['user_status']= "activated";
        $this->nextCgiType= $orig['user_last_prof'];

        if ($myRC= $conn->updateUserAttrs($orig, $updates)) {
            $this->emailActivate();
        }
        return($myRC);
    }

    ////////////////////////////////////////////////////////////////////
    //////               V A L I D A T I O N                      //////
    ////////////////////////////////////////////////////////////////////
    function validateAuthorizationFields() {
        $hashObj = new hasher();
        $this->Messages = array();
        if ($this->Ident != $hashObj->emailMunge($this->Email)) {
            $this->Messages['Ident'] = "Authorization Failure";
        }
        $this->validationFlag = !count($this->Messages);
    }

    function validateActivationFields() {
        $this->Messages = array();
        $this->topMessages= array();
        $v= new asValidator();

        $conn =& $this->dbConnection;

        //////                     L O G I N
        if ($this->Login == "") {
            $this->Messages['Login'] = $this->topMessages[]= "A Login is required";

        } elseif (!eregi($this->validLoginRegex, $this->Login))  {
            $this->Messages['Login'] = $this->topMessages[]= "Login must be letters, digits and underscore";

        }
        if ($this->authString != "inactivated" && $conn->loginExists($this->Login) ) {
            $this->Messages['Login'] = $this->topMessages[]= "Use a different login.  This one is taken.";

        } else if ($this->authString != "inactivated" && placeholderUserName($this->Login) ) {
            $this->Messages['Login'] = $this->topMessages[]= "Use a different login.  This one is taken.";
        }
        if ($this->authString == "inactivated" && $this->Login != $this->userRow['user_login']) {
            $this->Messages['Login'] = $this->topMessages[]= "You may not change your login name";
            $this->Login= $this->userRow['user_login'];
        }
        //////                 P A S S W O R D
        $this->Password= "";
        if ($this->Password1 == "" && $this->Password2 == "") {
            $this->Messages['Password'] = $this->topMessages[]= "A Password is required";

        } elseif ($this->Password1 != $this->Password2)  {
            $this->Messages['Password'] = $this->topMessages[]= "Passwords must match";

        } elseif (!eregi($this->validPasswordRegex, $this->Password1))  {
            $this->Messages['Password'] = $this->topMessages[]= "Password must be letters, digits and underscore";

        } elseif (strlen($this->Password1) < 6)  {
            $this->Messages['Password'] = $this->topMessages[]= "Password must be at least 6 characters in length";

        } else {
            $this->Password= $this->Password1;
        }
        $this->Password2= $this->Password1= $this->Password;

        //////                  T O S
        if ($this->TOS != "Yes") {
            $this->Messages['TOS'] = $this->topMessages[]= "You must accept the terms af service in order to register";
        }
        $this->validationFlag = !count($this->Messages);
    }

    function validateLoginFields() {
        $this->Messages = array();
        $this->regMessages= array();

        $conn =& $this->dbConnection;
        $h= new hasher();
        
        //////                L O G I N
        if ($this->Login == "") {
            $this->Messages['Login'] = "A Login is required";

        } elseif (!eregi($this->validLoginRegex, $this->Login))  {
            $this->Messages['Login'] = "Login must be letters, digits and underscore";

        } elseif ($this->loginScreen && !$conn->loginExists($this->Login) ) {
            $this->Messages['Login'] = $this->regMessages[] = "INVALID (<i>Please note: Username and Password fields are case sensitive</i>)";

        } elseif (!$conn->loginActive($this->Login)) {
            $this->Messages['Login'] = "Account access Denied";
        }

        //////             P A S S W O R D
        if ($conn->loginExists($this->Login) && !$conn->passwordMatch($this->Login, $h->passwordMunge($this->Password))) {
            $this->Messages['Password'] = $this->regMessages[] = "Invalid Login --Username and Password fields are case sensitive";

        } elseif ($this->Password == "") {
            $this->Messages['Password'] = "A Password is required";

        } elseif (!eregi($this->validPasswordRegex, $this->Password))  {
            $this->Messages['Password'] = "Password must be letters, digits and underscore";

        }
        //////                E M A I L
        if (!$this->loginScreen) {
            if ($this->Email == "") {
                if (!$conn->loginExists($this->Login)) {
                    $this->Messages['Email'] = "An Email Address is required";
                }

            } elseif (!$v->is_validEmail($this->Email))  {
                $this->Messages['Email'] = "Email is not valid";
            }
        }
        $this->validationFlag = !count($this->Messages);
        return($this->validated());
    }

    function validateJoinFields() {
        $this->Messages = array();
        $conn =& $this->dbConnection;
        $v= new asValidator();

        //////                E M A I L
        if (!$v->is_validEmail($this->Email))  {
            $this->Messages['Email']= $this->regMessages[]= "EMAIL ADDRESS IS NOT VALID";

        } else {
            $canUseIt= FALSE;

            $priUserAry= $conn->fetchUserAttrsEmail($this->Email);
            $altEmailAry= $conn->fetchAltEmailRow($this->Email);

            if (!is_array($priUserAry)  || count($priUserAry) == 0) {
                if (!is_array($altEmailAry) || count($altEmailAry) == 0 || $altEmailAry['amail_activep'] != "t") {
                    $canUseIt= TRUE;
                    if (is_array($altEmailAry) &&  count($altEmailAry) > 0) {
                        $this->alreadyInserted= !$conn->removeAltEmail($this->Email);
                    }
                }
            }
        }

        //  if any of the conditions above are not satisfied then
        //  oops.. it's an dupe email error
        if (!$canUseIt) {
            if (is_array($priUserAry) && count($priUserAry) > 0 && $priUserAry['user_status'] != "activated") {
                $mailer= new smtpMailer();
                $mailAry['addy']= $this->Email;
                $mailAry['act_type']= $priUserAry['user_last_prof'];
                $mailer->newUserA0($mailAry);
                $canUseIt= TRUE;

                $this->Messages['Email']= $this->regMessages[]= "The Email address you have entered is pending activation.  " .
                     "A new activation has just been sent.  Please check your email account to complete " .
                     "the activation and get your login & password";
            } else {
                $this->Messages['Email']= $this->regMessages[]= "EMAIL ADDRESS IS IN USE.  PICK ANOTHER ONE.";
            }

        }
        $this->validationFlag = !count($this->regMessages);

        return($this->validated());
    }

    ////////////////////////////////////////////////////////////////////
    function validated(){
        return($this->validationFlag);
    }

    //  generate URLs for user activation
    function nextCgi() {
        global $HTTP_SERVER_VARS;

        $myRc= "http://" . $HTTP_SERVER_VARS['HTTP_HOST'];
        $myRc= "";

        if ($this->authCheck() == "activated" ) {
            $myRc .= ($this->userRow['user_last_prof'] == "client") ? "/client-profile.php" : "/expert-profile.php";
            $myRc .= "?u=" . $this->userRow['user_login'];

        } else {
            $myRc .= "/error.php?code=" . urlencode("Can't determine next cgi auth check is " . $this->authCheck());
        }
        return($myRc);
    }

    ////////////////////////////////////////////////////////////////////
    function initNewUserProfiles($login) {
        //  clone the inital profiles and associate the clones with a
        //  new user
        $myOtherUser= $this->iProfileArgs['u'];
        reset($this->iProfileArgs['p']);
        $conn= new UserSqlConn();
        $conn->openConnection();

        foreach($this->iProfileArgs['p'] as $p) {
            $rep= new profileRep();
            $rep->setViewByName($myOtherUser, $p);

            if ($rep->valid($login)) {
                //  add a profile.  each one is atomic: either added
                //  or not added.
                $transState="continue";
                if (!$conn->executeQuery("begin work;")) {
                    $this->inpMessage = "newUser::initNewUserProfiles() no Xaction " . $conn->getErrorMessage();
                    syslog(LOG_ERR, $this->inpMessage);
                    $transState="exit";

                } else {
                    //  add the profile.  there are several database
                    //  steps in the $rep->addProfile() method
                    if (!$profId= $rep->addProfile($login, $conn)) {
                        $transState="rollback";

                    }
                    //  maybe set this profile as the default for this
                    //  user
                    if ($transState == "continue" && !isset($setDefault) && ($modExpert= $origExpert= $conn->fetchExpertAttrs($login))) {
                        $modExpert['expert_profile']= $profId;
                        if ($conn->updateExpertAttrs($origExpert, $modExpert)){
                            $setDefault= TRUE;
                        }
                    }
                }
                //  either commit the transaction or roll it back.  if
                //  $transState has the value "exit" thenn that
                //  transaction was never even begun so don't do
                //  either of these steps.
                if ($transState == "continue") {
                    $conn->executeQuery("commit work;");

                } else if ($transState == "rollback") {
                    $conn->executeQuery("rollback work;");
                }

                unset($rep);
            }
        }
        $conn->closeConnection();
        unset($conn);
    }


    ////////////////////////////////////////////////////////////////////
    function dbInsert() {
        $this->validationFlag = FALSE;
        $myRc= FALSE;
        //echo("<br><br>newUser::dbInsert()...");

        $conn =& $this->dbConnection;
        $cc = !!$conn->openConnection();
        if ($cc && $this->activationScreen) {
            $newUserRow= $this->userRow;
            $newl= $newUserRow['user_login']= trim($this->Login);
            $newUserRow['user_passwd']= $this->passwordCrypter();

            if (!$myRc= $conn->updateUserAttrs($this->userRow, $newUserRow)) {
                $this->sMessage = "newUser::dbInsert()  couldn't update user row" . $conn->getErrorMessage();
                syslog(LOG_ERR, $this->sMessage);

            } else {
                $this->sMessage = "newUser::dbInsert()  activation successful for {$newl}";
                syslog(LOG_ERR, $this->sMessage);
            }

        } else if ($cc && !$this->loginScreen && !$this->alreadyInserted) {
            //echo("<br><br>newUser::dbInsert() new skeleton...");
            $nuts= new nuts($conn);
            $skelArgs= array();

            //  create a new user skeleton in the database and
            //  possibly set up profiles
            $skelArgs['user_login']= $myUserLogin = "Joe." . $conn->anonUserSeq($conn);
            $skelArgs['user_fwd_email']= $this->Email;
            $skelArgs['user_passwd']= "";

            if (($myRc= !!$nuts->userSkel($skelArgs)) && count($this->iProfileArgs) > 0) {
                $this->initNewUserProfiles($myUserLogin);
            }
            //echo("<br><br>newUser::dbInsert() skel rc..."); var_dump($myRc);

            $this->emailNeedsA0= TRUE;
        }

        if ($cc) {
            $conn->closeConnection();
        }

        if ($this->emailNeedsA0) {
            $mailer= new smtpMailer();
            $mailAry['addy']= $this->Email;
            $mailAry['act_type']= "expert";
            $mailer->newUserA0($mailAry);
        }
        return($myRc);
    }
}
?>