<?
//  $Name: ORG-TEST $, $Id: allseer.UserSqlConn.php,v 1.86 2002/12/13 20:06:50 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  This class abstracts out some SQL functionality frequently
//  with user maintenance
require_once ("comm.dbConnection.php");

class UserSqlConn extends dbConnection
{
    var $localOpenFlag = FALSE;
////////////////////////////////////////////////////////////////////////
//                        C O N S T R U C T O R                       //
////////////////////////////////////////////////////////////////////////
    function UserSqlConn(){
        parent::dbConnection();
        //echo("<br><br>SQLC: DEBUG==> Constructor entry");
        //syslog(LOG_ERR, "SQLC: DEBUG==> Constructor entry");
    }

////////////////////////////////////////////////////////////////////////
//                P R I V A T E    F U N C T I O N S                  //
////////////////////////////////////////////////////////////////////////
    //  open a connection unless the connection is  already
    //  opened.
    function localOpen(){
        $loRc = TRUE;
        if ($this->localOpenFlag = !$this->connection) {
            $loRc = !!$this->openConnection();
        }
        return($loRc);
    }
    //  if the connection was opened locally then close it otherwise
    //  don't fuck with it.
    function localClose() {
        if ($this->localOpenFlag) {
            $this->closeConnection();
            $this->localOpenFlag = FALSE;
        }
    }
    //  exec a query --opening a local connection if required.  make sure
    //  that only a single row is returned.  trim the results.
    function execSingleRowQuery($query, $shitOut= FALSE) {
        $myRow = FALSE;
        if ($this->localOpen()) {
            // Execute the query.
            $this->executeQuery($query);

            if (($myCount = $this->getNumRows()) == 1) {
                $myRow = $this->fetchNextRow(0);
                if ($shitOut) {
                    $this->stripShit($myRow);
                }
                foreach($myRow as $k => $v) {
                    $myRow[$k] = trim($v);
                }
            }
            $this->localClose();
        }
        return($myRow);
    }
    //  given two arrays of table attributes, return an array whose
    //  members are attributes from the second array whose values
    //  differ from the corresponding attributes of the first
    //  array.
    function attrSieve($orig, $new) {
        $result = array();
        $oKeys = array_keys($orig);

        foreach($new as $k => $v) {
            if (in_array($k, $oKeys) && !($v == $orig[$k])) {
                $result[$k] = $v;
            }
        }
        return($result);
    }
    //  return a string as used in an SQL interval calculation
    //  based on the actual argument
    function SQLFrame($tm) {
        $myRc = FALSE;
        if ($tm == 'wk') {
            $myRc = '1 weeks';

        } else if ($tm == 'yr') {
            $myRc = '1 years';
        }
        return($myRc);
    }
    //  execute a query and then return all of it's results in an
    //  array.
    function arrayFromQuery($afqSQL, $rt= PGSQL_BOTH) {
        $myRc = FALSE;
        if ($this->localOpen()) {

            if ($this->executeQuery($afqSQL)) {
                $myRc = array();

                for ($i = 0; $i < $this->getNumRows(); $i++) {
                    $myRc[$i] = $this->fetchNextRow($i, $rt);
                }

            } else {
                syslog(LOG_ERR,'SQLC.arrayFromQuery: SQL failed <<SQL>><<' . $afqSQL. '>>');
                syslog(LOG_ERR,'SQLC.arrayFromQuery: ' . $this->getErrorMessage());
            }
            $this->localClose();

        } else {
            syslog(LOG_ERR, 'SQLC.arrayFromQuers: localOpen failed');
        }
        return($myRc);
    }


////////////////////////////////////////////////////////////////////////
//              I N T E R F A C E    F U N C T I O N S                //
////////////////////////////////////////////////////////////////////////
    //  take out all of the numeric keys in an array
    function stripShit(&$array){
        for($i=0; $i<count($array); $i++)
            if (isset($array[$i])) unset($array[$i]);
    }

    //  return a boolean indicating whether or not this login
    //  alreeady exists in the database
    function loginExists($login) {
        $myCount = 0;
        $myLogin = trim($login);

        if ($this->localOpen()) {

            $mySQL = 'Select * from as_user where user_login = \'' . $myLogin. "'";

            // Execute the query.
            $this->executeQuery($mySQL);
            $myCount = $this->getNumRows();

            $this->localClose();
        }
        return($myCount == 1);
    }
    //  return a boolean indicating whether or not this login
    //  administers a mailing list
    function is_listAdmin($login) {
        $myCount = 0;
        $myLogin = trim($login);

        if ($this->localOpen()) {

            $mySQL =
                 'Select distinct u.* ' .
                 'from as_user u, ' .
                 '     as_mail_lists m, ' .
                 '     as_expert x ' .
                 'where ' .
                 '     m.mlist_admin = x.expert_id and ' .
                 '     x.expert_uid = u.user_id and ' .
                 '     u.user_login = \'' . $myLogin . '\'';

            // Execute the query.
            $this->executeQuery($mySQL);
            $myCount = $this->getNumRows();
            $this->localClose();
        }
        return($myCount == 1);
    }
    //  return a boolean indicating whether or not this login
    //  is active in the database
    function loginActive($login) {
        $myCount = 0;
        $myLogin = trim($login);

        if ($this->localOpen()) {
            $mySQL =
                 'Select * from as_user ' .
                 'where user_login = \'' . $myLogin . '\' and user_status = \'activated\'';

            // Execute the query.
            $this->executeQuery($mySQL);
            $myCount = $this->getNumRows();

            $this->localClose();
        }
        return($myCount == 1);
    }
    //  return all of the attributes in as_user associated with the
    //  passed user id
    function fetchUserAttrs($login) {
        $myLogin = trim($login);

        $myRow = $this->execSingleRowQuery('Select * from as_user where user_login = \'' . $myLogin . '\'');
        return($myRow);
    }
    //  return all of the attributes in as_user associated with the
    //  passed user id
    function fetchUserAttrsUID($id) {
        $myId = trim($id);

        $myRow = $this->execSingleRowQuery('Select * from as_user where user_id = \'' . $myId . '\'');
        return($myRow);
    }

    //  return all of the attributes in as_user associated with the
    //  passed email address
    function fetchUserAttrsEmail($email) {
        $myEmail = trim($email);

        $myRow = $this->execSingleRowQuery('Select * from as_user where user_fwd_email = \'' . $myEmail . '\'');
        return($myRow);
    }

    //  return all of the attributes in as_user associated with the
    //  passed alternate email address
    function fetchUserAttrsAltEmail($email) {
        $myEmail = trim($email);
        $mySQL=
             'select ' .
             '    u.* ' .
             'from ' .
             '    as_user u, ' .
             '    as_alt_email a ' .
             'where ' .
             '    a.amail_email=\'' . $myEmail . '\' and ' .
             '    u.user_id=a.amail_uid';

        $myRow = $this->execSingleRowQuery($mySQL);
        return($myRow);
    }

    //  return all of the attributes in as_client associated with the
    //  passed user login
    function fetchClientAttrs($login) {
        $mySQL =
             'Select * from as_client ' .
             'where client_uid = (select user_id ' .
             'from as_user where user_login = \'' .trim($login) . '\')';

        return($this->execSingleRowQuery($mySQL));
    }

    //  return all of the attributes in as_expert associated with the
    //  passed user id
    function fetchExpertAttrs($login) {
        $mySQL =
             'Select * from as_expert ' .
             'where expert_uid = (select user_id ' .
             'from as_user where user_login = \'' .trim($login) . '\')';

        $ary= $this->execSingleRowQuery($mySQL);

        //echo("<br>UserSqlConn::fetchExpertAttrs()= ");
        //var_dump($ary);
        return($ary);
    }

    //  check if a password matches what is in the database
    function passwordMatch($login, $password) {
        $myCount = 0;
        $myLogin = trim($login);
        $myPassword = trim($password);

        if ($this->localOpen()) {

            $mySQL =
                 ' Select * from as_user' .
                 ' where trim(user_login) = \'' . $myLogin . '\'' .
                 ' and trim(user_passwd) = \'' . $myPassword . '\'';

            //echo("<br>UserSqlConn::passwordMatch() \$mySQL = $mySQL");
            // Execute the query.
            $this->executeQuery($mySQL);
            $myCount = $this->getNumRows();

            $this->localClose();
        }
        return($myCount == 1);
    }
    //  insert a new user row with minimal attributes
    function insertUserRow($login, $email, $password) {

        if ($myRc = $this->localOpen()) {
            $mySQL =
                 'insert into as_user ' .
                 '(user_login, user_fwd_email, user_passwd, created) ' .
                 "values('$login', '" . $email . "', '" . $password . "', now())";

            $myRc = $this->executeQuery($mySQL);
            $this->localClose();
        }
        return($myRc);
    }
    //  insert a new e-mail address.  user row must
    //  already exist
    function insertEmailRow($email) {
        if ($myRc = $this->localOpen()) {
            $mySQL =
                 'insert into as_alt_email ' .
                 '(amail_uid, amail_email, created) ' .
                 "select u.user_id, '$email', now() " .
                 'from as_user u ' .
                 'where u.user_fwd_email = \'' . $email . '\'';

            $myRc = $this->executeQuery($mySQL);
            $this->localClose();
        }
        return($myRc);
    }
    //  insert a new altername e-mail address.  user row must
    //  already exist
    function insertAltEmail($user, $email) {
        if ($myRc = $this->localOpen()) {
            $mySQL =
                 'insert into as_alt_email ' .
                 '(amail_uid, amail_email, created) ' .
                 'select u.user_id, \'' . $email . '\', now() ' .
                 'from as_user u ' .
                 "where u.user_login = '$user';";

            $myRc = $this->executeQuery($mySQL);
            $this->localClose();
        }
        return($myRc);
    }

    // return true or false: this profile name already
    //  exists for this user
    function profileNameExists($name, $user) {
        $mySQL=
             'select p.pprof_id ' .
             'from as_pay_profiles p, ' .
             '  as_user u, ' .
             '  as_expert x ' .
             'where ' .
             '  u.user_login = \'' . $user . '\' and ' .
             '  x.expert_uid = u.user_id and ' .
             '  p.pprof_name = \'' . $name . '\' and ' .
             '  p.pprof_expert_id = x.expert_id';

        $myDBresults= $this->arrayFromQuery($mySQL);
        return((count($myDBresults) != 0));
    }

    //  return an array of beneficiaries and percentages
    //  associated with the pay profile whose identifier
    //  is passed.
    function profilePercentageAry($profid) {
        $mySQL=
             'select  ' .
             '    f.foundation_name as bene, ' .
             '    f.foundation_id as fid, ' .
             '    f.foundation_url as url, ' .
             '    p. ppd_percent as pct ' .
             'from as_pprof_details p,  ' .
             '    as_foundations f ' .
             'where  ' .
             '    p.ppd_prof = \'' . $profid . '\' and  ' .
             '    f.foundation_id = p.ppd_found';

        $myDBresults= $this->arrayFromQuery($mySQL, PGSQL_ASSOC);
        return($myDBresults);
    }

    //  insert a new pay profile row
    function insertPayProfile($name, $proppa, $proppa_tp, $uid) {
        if ($myRc = $this->localOpen()) {
            //echo("<br><br>UserSqlConn::insertPayProfile() entrez...");

            $escProppa= str_replace("\\", "\\\\", str_replace("'", "''", trim($proppa)));

            $mySQL =
                 'insert into as_pay_profiles ' .
                 '(pprof_expert_id, pprof_name,  pprof_proppa,  pprof_proppa_tp, created) ' .
                 "select x.expert_id, '$name', '$escProppa', '$proppa_tp', now() " .
                 'from as_user u, ' .
                 ' as_expert x ' .
                 'where u.user_login = \'' . $uid . '\' ' .
                 'and x.expert_uid=u.user_id';

            if (!$myRc = $this->executeQuery($mySQL)) {
                syslog(LOG_ERR, 'SQLC.insertPayProfile: ' . ($m= $this->getErrorMessage()));
                syslog(LOG_ERR, 'SQLC.insertPayProfile: <<SQL>><<' . $mySQL . '>>');
                //echo("<br><br>insertPayProfile() $mySQL");
                //echo("<br><br>insertPayProfile() ...\$m...");var_dump($m);
            }

            $this->localClose();
        }
        return($myRc);
    }
    ////////////////////////////////////////////////////////////////////
    //  insert a new pay profile detail row
    //
    //  ary = array("pc" => <num>, found => <name>)
    //  oid = oid for a pay profile row
    function insertPayProfileDetail($ary, $oid) {
        if ($myRc = $this->localOpen()) {
            $myPct = $ary["pc"];
            $myFound = str_replace("\\", "\\\\", str_replace("'", "''", trim($ary["found"])));
            $mySQL =
                 'insert into as_pprof_details ' .
                 '    (ppd_prof, ppd_found, ppd_percent, created) ' .
                 'select p.pprof_id, f.foundation_id, \'' . $myPct . '\', now() ' .
                 'from ' .
                 '    as_pay_profiles p, ' .
                 '    as_foundations f ' .
                 'where ' .
                 'p.oid=\'' . $oid . '\' and ' .
                 'trim(f.foundation_name)=\'' . $myFound . '\'';

            if (!$myRc = $this->executeQuery($mySQL)) {
                syslog(LOG_ERR, 'SQLC.insertPayProfileDetail: ' . ($m= $this->getErrorMessage()));
                syslog(LOG_ERR, 'SQLC.insertPayProfileDetail: <<SQL>><<' . $mySQL . '>>');
            }

            $this->localClose();
        }
        return($myRc);
    }
    function deletePayProfileDetails($prof_id) {
        if ($myRc = $this->localOpen()) {

            $mySQL =
                 "delete from as_pprof_details where ppd_prof='$prof_id'";

            if (!$myRc = $this->executeQuery($mySQL)) {
                syslog(LOG_ERR, 'SQLC.deletePayProfileDetails: ' . $this->getErrorMessage());
                syslog(LOG_ERR, 'SQLC.deletePayProfileDetails: <<SQL>><<' . $mySQL . '>>');
            }

            $this->localClose();
        }
        return(!!$myRc);
    }

    //  This is an array of pay profile details defined by an
    //  expert whose user name is passed as an argument and a
    //  sequence number identifying the profile
    function fetchUserPPDetails($user, $seq) {
        $myRc = FALSE;

        $mySQL =
             'select ' .
             '    pd.ppd_percent as pc, ' .
             '    f.foundation_name as found, ' .
             '    p.pprof_name as name, ' .
             '    p.pprof_proppa as proppa, ' .
             '    trim(p.pprof_proppa_tp) as proppa_tp, ' .
             '    p.pprof_id, ' .
             '    p.oid as pprof_oid, ' .
             '    pd.ppd_id ' .

             'from ' .
             '    as_user u, ' .
             '    as_expert x, ' .
             '    as_pay_profiles p, ' .
             '    as_foundations f, ' .
             '    as_pprof_details pd ' .

             'where ' .
             '    u.user_login=\'' . $user . '\' and ' .
             '    x.expert_uid=u.user_id and ' .
             '    p.pprof_expert_id=x.expert_id and ' .
             '    p.pprof_xseq=\'' . $seq . '\' and ' .
             '    pd.ppd_prof=p.pprof_id and ' .
             '    f.foundation_id=pd.ppd_found ' .

             'order by ppd_id';


        $myRc = $this->arrayFromQuery($mySQL);
        return($myRc);
    }

    //  This is an array of pay profile details defined by an
    //  expert whose user name is passed as an argument and a
    //  profile name
    function fetchUserPPDetailsByName($user, $pname) {
        $myRc = FALSE;

        $mySQL =
             'select ' .
             '    pd.ppd_percent as pc, ' .
             '    f.foundation_name as found, ' .
             '    p.pprof_name as name, ' .
             '    p.pprof_proppa as proppa, ' .
             '    trim(p.pprof_proppa_tp) as proppa_tp, ' .
             '    p.pprof_id, ' .
             '    p.oid as pprof_oid, ' .
             '    pd.ppd_id ' .

             'from ' .
             '    as_user u, ' .
             '    as_expert x, ' .
             '    as_pay_profiles p, ' .
             '    as_foundations f, ' .
             '    as_pprof_details pd ' .

             'where ' .
             '    u.user_login=\'' . $user . '\' and ' .
             '    x.expert_uid=u.user_id and ' .
             '    p.pprof_expert_id=x.expert_id and ' .
             '    trim(p.pprof_name)=\'' . trim($pname)  . '\' and ' .
             '    pd.ppd_prof=p.pprof_id and ' .
             '    f.foundation_id=pd.ppd_found ' .

             'order by ppd_id';


        $myRc = $this->arrayFromQuery($mySQL);
        return($myRc);
    }

    //  This is an array of pay profiles defined by an
    //  expert whose user name is passed as an argument
    function fetchTipProfileIds($oid) {
        $myRc = FALSE;

        $mySQL =
             'select ' .
             '    tip_id, ' .
             '    tip_profile_id as profile_id ' .
             'from ' .
             '    as_tips ' .
             'where ' .
             '    oid=\'' . $oid . '\'';

        $myRc = $this->arrayFromQuery($mySQL);

        //echo("<br>UserSqlConn::fetchTipProfileIds() returns..."); var_dump($myRc);
        return($myRc);
    }
    //  insert a mnew expert
    function insertExpertRow($email) {
        if ($myRc = $this->localOpen()) {
            $mySQL =
                 'insert into as_expert ' .
                 '(expert_uid, created) ' .
                 'select u.user_id, now()' .
                 'from as_user u ' .
                 'where u.user_fwd_email = \'' . $email .'\'';

            if (!$myRc = $this->executeQuery($mySQL)) {
                syslog(LOG_ERR, 'SQLC.insertExpertRow: ' . $this->getErrorMessage());
                syslog(LOG_ERR, 'SQLC.insertExpertRow: <<SQL>><<' . $mySQL . '>>');
            }
            $this->localClose();
        }
        return($myRc);
    }
    //  put a new client in the system
    function insertClientRow($email) {
        if ($myRc = $this->localOpen()) {
            $mySQL =
                 'insert into as_client ' .
                 '(client_uid, client_public, created) ' .
                 'select u.user_id, \'true\', now()' .
                 'from as_user u ' .
                 'where u.user_fwd_email = \'' . $email . '\'';

            $myRc = $this->executeQuery($mySQL);
            if (!$myRc){
                syslog(LOG_ERR, 'SQLC.insertClientRow: ' . $this->getErrorMessage());
                syslog(LOG_ERR, 'SQLC.insertClientRow: <<SQL>><<' . $mySQL . '>>');
            }

            $this->localClose();
        }
        return($myRc);
    }
    //  update user attributes.  arguments are arrays of database
    //  attributes.  remove from the $new array any attributes
    //  which haven't changed then construct a SQL update command
    //  for those which are left.
    function updateUserAttrs($orig, $new) {
        if ($myRc = $this->localOpen()) {
            $myLogin = $orig['user_login'];
            $updAttrs = $this->attrSieve($orig, $new);

            if (count($updAttrs)) {
                $mySQL = 'update  as_user set ';

                foreach($updAttrs as $k => $v) {
                    $mySQL = $mySQL . "$k = " . ($v == "" ? "NULL," : "'$v', ");
                }

                $mySQL = $mySQL . "modified = now() where user_login = '$myLogin'";
                $myRc = $this->executeQuery($mySQL);
                if (!$myRc) {
                    syslog(LOG_ERR, 'SQLC.updateUserRow: ' . $this->getErrorMessage());
                    syslog(LOG_ERR, 'SQLC.updateUserRow: query<<' . $mySQL . '>>');
                }
            }
            $this->localClose();
        }
        return($myRc);
    }

    //  update client attributes.  arguments are arrays of database
    //  attributes.  remove from the $new array any attributes
    //  which haven't changed then construct a SQL update command
    //  for those which are left.
    function updateClientAttrs($orig, $new) {
        if ($myRc = $this->localOpen()) {
            $oKeys = array_keys($orig);

            if (!($myCid = $orig['client_id'] ? $orig['client_id'] : FALSE)) {
                syslog(LOG_ERR, 'SQLC.updateClientRow: client_id could not be determined');
                $myRc = FALSE;

            } else {
                $updAttrs = $this->attrSieve($orig, $new);

                if (count($updAttrs)) {
                    $mySQL = 'update  as_client set ';

                    foreach($updAttrs as $k => $v) {
                        $mySQL = $mySQL . "$k = " . ($v == "" ? "NULL," : "'$v', ");
                    }

                    $mySQL = $mySQL . "modified = now() where client_id = '$myCid'";
                    $myRc = $this->executeQuery($mySQL);
                    if (!$myRc) {
                        syslog(LOG_ERR,'SQLC.updateClientRow: <<SQL>><<' . $mySQL . '>>');
                        syslog(LOG_ERR, 'SQLC.updateClientRow: ' . $this->getErrorMessage());
                    }
                }
            }
            $this->localClose();
        }
        return($myRc);
    }

    //  update expert attributes.  arguments are arrays of database
    //  attributes.  remove from the $new array any attributes
    //  which haven't changed then construct a SQL update command
    //  for those which are left.
    function updateExpertAttrs($orig, $new) {
        if ($myRc = $this->localOpen()) {
            $oKeys = array_keys($orig);

            if (!($myEid = $orig['expert_id'] ? $orig['expert_id'] : FALSE)) {
                syslog(LOG_ERR, 'SQLC.updateExpertRow: expert_id could not be determined');
                $myRc = FALSE;

            } else {
                $updAttrs = $this->attrSieve($orig, $new);

                if (count($updAttrs)) {
                    $mySQL = 'update  as_expert set ';

                    foreach($updAttrs as $k => $v) {
                        $mySQL = $mySQL . "$k = " . ($v == "" ? "NULL," : "'$v', ");
                    }

                    $mySQL = $mySQL . "modified = now() where expert_id = '$myEid'";

                    $myRc = $this->executeQuery($mySQL);
                    if (!$myRc) {
                        syslog(LOG_ERR, 'SQLC.updateExpertRow: $myRc .= ' . $this->getErrorMessage());
                        syslog(LOG_ERR, 'SQLC.updateExpertRow: <<SQL>><<' . $mySQL . '>>');
                    }
                }
            }
            $this->localClose();
        }
        return($myRc);
    }

//  update a rating table row
    function updateRatingAttrs($orig, $new) {
        if ($myRc = $this->localOpen()) {

            $myRid= $orig["rating_id"];
            $updAttrs = $this->attrSieve($orig, $new);

            if (count($updAttrs)) {
                $mySQL = "update  as_ratings set ";

                foreach($updAttrs as $k => $v) {
                    $mySQL = $mySQL . "$k = " . ($v == "" ? "NULL," : "'$v', ");
                }

                $mySQL = $mySQL . "modified = now() where rating_id = '$myRid'";
                $myRc = $this->executeQuery($mySQL);
                if (!$myRc) {
                    syslog(LOG_ERROR, "SQLC.updateUserRow: " . $this->getErrorMessage());
                    syslog(LOG_ERROR, "SQLC.updateUserRow: query<<$mySQL>>");
                }
            }
            $this->localClose();
        }
        return($myRc);
    }

    //  get sum of tip ammounts for this client this month
    function clientMonthlyTips($clid) {
        if ($myRc = $this->localOpen()) {

            $mySQL =
                 'select ' .
                 '    sum(tip_amt) from as_tips where tip_grantor =' . "'$clid' and " .
                 '    extract(month from created) = extract(month from now())';

            $myRc = $this->executeQuery($mySQL);
            if ($myRc) {
                $myArray = $this->fetchNextRow(0);
                $myRc = $myArray[0];
            }
            $this->localClose();
        }

        return($myRc);
    }

    //  get sum of tip ammounts for this client for the last year
    function clientYearlyTips($clid) {
        if ($myRc = $this->localOpen()) {
            $mySQL =
                 'select ' .
                 '    sum(tip_amt) from as_tips ' .
                 'where ' .
                 '    tip_grantor =' . "'$clid' " .
                 '    and created > now()::timestamp - \'1 years\'::interval';

            $myRc = $this->executeQuery($mySQL);
            if ($myRc) {
                $myArray = $this->fetchNextRow(0);
                $myRc = $myArray[0];
            }
            $this->localClose();
        }
        return($myRc);
    }

    //  build  a competency array and pass back as return value or false
    function buildCompetencyArray() {
        if ($myRc = $this->localOpen()) {
            $mySQL =
                 'select ' .
                 '    cmptcy_descr, ' .
                 '    cmptcy_id from as_competencies ' .
                 'order by cmptcy_descr';

            if ($myRc = $this->executeQuery($mySQL) ) {
                $myRc = array();
                for ($i = 0; $i < $this->getNumRows(); $i++) {
                    $loopRow = $this->fetchNextRow($i);
                    $myRc[$i]["cmptcy_descr"] = $loopRow["cmptcy_descr"];
                    $myRc[$i]["cmptcy_id"] = $loopRow["cmptcy_id"];
                }
            }
            $this->localClose();
        }
        return($myRc);
    }
    //  build  a foundation array and pass back as return value or false
    function buildFoundationArray() {
        if ($myRc = $this->localOpen()) {
            $mySQL =
                 'select ' .
                 '    foundation_name as name, ' .
                 '    foundation_id from as_foundations ' .
                 'order by foundation_id';

            if ($myRc = $this->executeQuery($mySQL) ) {
                $myRc = array();
                for ($i = 0; $i < $this->getNumRows(); $i++) {
                    $loopRow = $this->fetchNextRow($i);
                    $myRc[$i]["name"] = $loopRow["name"];
                }
            }
            $this->localClose();
        }
        return($myRc);
    }

    ////////////////////////////////////////////////////////////////////
    //                       insert a rating
    //  argAry(
    //    value,       .rating value from rating form
    //    comment,     .rating comment
    //    category,    .
    //    raterEmail,  .
    //    rateeEmail,  .
    //    rid,         .reference id (ie to another rating)
    //    mlid,        .foreign key (as_mail_lists)
    //    ls,     subj .>  list arguments from rating screen
    //    lh)     hash .>
    function insertRating($argAry) {
        if ($myRc = $this->localOpen()) {
            $keys= array("value", "comment", "category", "raterEmail", "rateeEmail", "rid", "mlid", "ls", "lh");

            while(list($key, $val)= each($keys)) {
                $av= $argAry[$val];
                $$val= isset($argAry[$val]) ? $argAry[$val] : "";
            }
            $category= ($category == "") ? "NULL" : $category;
            $rid= ($rid == "") ? "NULL" : $rid;
            $mlid= ($mlid == "") ? "NULL" : $mlid;

            $mySQLEscapedComment= str_replace("\\", "\\\\", str_replace("'", "''", trim($comment)));
            $mySQLEscapedMsgid= str_replace("\\", "\\\\", str_replace("'", "''", trim($lh)));
            $mySQLEscapedSubj= str_replace("\\", "\\\\", str_replace("'", "''", trim($ls)));

            $mySQL =
                 'insert into as_ratings ' .
                 '    (rating_rator, ' .
                 '    rating_ratee, ' .
                 '    rating_value, ' .
                 '    rating_rid, ' .
                 '    rating_msgid, ' .
                 '    rating_subj, ' .
                 '    rating_descr, ' .
                 '    rating_category, ' .
                 '    rating_mlist, ' .
                 '    created) ' .
                 'select ' .
                 '    u1.user_id, ' .
                 '    u2.user_id, ' .
                 "    '$value', " .
                 "    $rid, " .
                 "    '$mySQLEscapedMsgid', " .
                 "    '$mySQLEscapedSubj', " .
                 "    '$mySQLEscapedComment', " .
                 "    $category, " .
                 "    $mlid, " .
                 '    now() ' .
                 'from ' .
                 '    as_user u1, ' .
                 '    as_user u2 ' .
                 'where ' .
                 "    u1.user_fwd_email = '$raterEmail' and " .
                 "    u2.user_fwd_email = '$rateeEmail'";

            if (!$myRc = $this->executeQuery($mySQL)) {
                syslog(LOG_ERR, "SQLC.insertRating: FAILURE..." . $this->getErrorMessage());
                syslog(LOG_ERR, "SQLC.insertRating: <<SQL>><<$mySQL>>");
            }
            $this->localClose();
        }
        return($myRc);
    }

    //  check for an existing rating
    function originalRatingExists($oid) {
        $myCount= 0;

        if ($this->localOpen()) {

            $mySQL =
                 'select * ' .
                 'from as_ratings ' .
                 'where ' .
                 'oid = \'' . $oid . '\' and ' .
                 'rating_rid is NULL';

            // Execute the query.
            $this->executeQuery($mySQL);
            $myCount = $this->getNumRows();

            $this->localClose();
        }
        return($myCount == 1);
    }

    //  read a rating row
    function fetchRatingAttrs($rid) {
        $mySQL = "select * from as_ratings where rating_id = $rid";
        return($this->execSingleRowQuery($mySQL, TRUE));
    }

    //  check for an existing rating by this rater for this ratee
    //  which references a given rating
    function duplicateRatingExists($oid) {
        $myCount= 0;

        if ($this->localOpen()) {

            $mySQL =
                 'select r1.rating_id ' .
                 'from as_ratings r1, as_ratings r2 ' .
                 'where ' .
                 'r1.oid =' . "'$oid' and " .
                 'r2.rating_rator = r1.rating_ratee and ' .
                 'r2.rating_ratee = r1.rating_rator and ' .
                 'r2.rating_rid = r1.rating_id';

            // Execute the query.
            $this->executeQuery($mySQL);
            $myCount = $this->getNumRows();

            $this->localClose();
        }
        return($myCount == 1);
    }

    //  get all of the ratings applied to a user along with some
    //  ancilliary information
    function fetchRatingsAppliedToUser($login) {
        if ($myRc = $this->localOpen()) {
            $myLogin= trim($login);

            $mySQL=
                 'select ' .
                 '    uc.user_login as rator_name, ' .
                 '    uc.user_status as rator_status, ' .
                 '    c.client_tip_history, ' .
                 '    jt.* ' .

                 'from ' .
                 '    (select ' .
                 '        t.tip_amt, ' .
                 '        r.* ' .

                 '    from ' .
                 '        as_ratings r left outer join as_tips t ' .
                 '    on (r.rating_id=t.tip_rating)) jt, ' .
                 '    as_client c, ' .
                 '    as_user uc, ' .
                 '    as_user u ' .

                 'where ' .
                 '    jt.rating_ratee = u.user_id and ' .
                 '    c.client_uid = jt.rating_rator and ' .
                 '    uc.user_id = jt.rating_rator and ' .
                 '    u.user_login = ' . "'$myLogin'";

            // Execute the query.
            $myRc = $this->arrayFromQuery($mySQL, PGSQL_ASSOC);
            $this->localClose();
        }
        return($myRc);
    }

    //  get all of the ratings made by a user along with some
    //  ancilliary information
    function fetchRatingsMadeByUser($login) {
        if ($myRc = $this->localOpen()) {
            $myLogin= trim($login);

            $mySQL=
                 'select ' .
                 '    uc.user_login as ratee_name, ' .
                 '    uc.user_status as ratee_status, ' .
                 '    c.client_tip_history as client_tip_history, ' .
                 '    jt.* ' .

                 'from ' .
                 '    (select ' .
                 '        t.tip_amt, ' .
                 '        r.* ' .

                 '    from ' .
                 '        as_ratings r left outer join as_tips t ' .
                 '    on (r.rating_id=t.tip_rating)) jt, ' .
                 '    as_user uc, ' .
                 '    as_client c, ' .
                 '    as_user u ' .

                 'where ' .
                 '    jt.rating_rator = u.user_id and ' .
                 '    uc.user_id = jt.rating_ratee and ' .
                 '    c.client_uid = u.user_id and ' .
                 '    u.user_login = \'' . $myLogin . '\'';

            // Execute the query.
            $myRc = $this->arrayFromQuery($mySQL, PGSQL_ASSOC);
            $this->localClose();
        }
        return($myRc);
    }

    //  fetch total tips given and received
    function ratersInfo($login){
        if ($myRc = $this->localOpen()) {
            $myLogin= trim($login);

            $mySQL=
                 'select  ' .
                 '    a.given_amt, a.given_count,  ' .
                 '    b.recvd_amt, b.recvd_count ' .
                 'from  ' .
                 '    (select  ' .
                 '        1 as jcol,  ' .
                 '        sum(t.tip_amt) as given_amt,  ' .
                 '        count(u.user_login) as given_count,  ' .
                 '        max(u.user_id) as id ' .
                 '    from  ' .
                 '        as_tips t,  ' .
                 '        as_user u  ' .
                 '    where  ' .
                 '        u.user_login=' . "'$myLogin' " .
                 '        and t.tip_amt > 0 ' .
                 '        and t.tip_grantor=u.user_id) as a  ' .
                 'join  ' .
                 '    (select  ' .
                 '        1 as jcol,  ' .
                 '        sum(t.tip_amt) as recvd_amt,  ' .
                 '        count(u.user_login) as recvd_count,  ' .
                 '        max(u.user_id) as id ' .
                 '    from  ' .
                 '        as_tips t,  ' .
                 '        as_user u  ' .
                 '    where  ' .
                 '        u.user_login=' . "'$myLogin' " .
                 '        and t.tip_amt > 0 ' .
                 '        and t.tip_recipient=u.user_id) as b  ' .
                 'on (a.jcol=b.jcol)';

            // Execute the query.
            $myRc = $this->arrayFromQuery($mySQL, PGSQL_ASSOC);
            $this->localClose();
        }
        return($myRc);
    }

    //  this should really, really be in a database table with FKs and
    //  everything!!
    function fetchRatingDescriptions(){
        $ratings= array(
            array('rating_descr' => 'Priceless', 'rating_val' => '5'),
            array('rating_descr' => 'Very Valuable', 'rating_val' => '4'),
            array('rating_descr' => 'Valuable', 'rating_val' => '3'),
            array('rating_descr' => 'Neutral', 'rating_val' => '2'),
            array('rating_descr' => 'Useless', 'rating_val' => '1'));

        return($ratings);
    }

    //  insert a trust commerce transaction row.  Argument is an array
    //  of values from a secure transaction which has been completed.
    //  there are really two database updates here but thye do *not*
    //  comprise an atomic transaction.
    function insertTCX($valueAry) {
        if ($myRc = $this->localOpen()) {

            $myName = str_replace("\\", "\\\\", str_replace("'", "''", trim($valueAry['name'])));
            $myTid = str_replace("\\", "\\\\", str_replace("'", "''", trim($valueAry['transid'])));
            $myBDate = str_replace("\\", "\\\\", str_replace("'", "''", trim($valueAry['billdate'])));
            $myCard = str_replace("\\", "\\\\", str_replace("'", "''", trim($valueAry['card'])));
            $myStatus = str_replace("\\", "\\\\", str_replace("'", "''", trim($valueAry['status'])));
            $myVary = str_replace("\\", "\\\\", str_replace("'", "''", trim($valueAry['packed'])));
            $myOid = $valueAry['tip_oid'];

            $mySQL =
                 'insert into as_tc_xactions ' .
                 '(' .
                 '    tcx_tip_id, ' .
                 '    tcx_name, ' .
                 '    tcx_transid, ' .
                 '    tcx_transdate, ' .
                 '    tcx_cardtp, ' .
                 '    tcx_transstatus, ' .
                 '    tcx_valarray, ' .
                 '    created) ' .

                 'select ' .
                 '    t.tip_id, ' .
                 '    \'' . $myName    . '\', ' .
                 '    \'' . $myTid     . '\', ' .
                 '    \'' . $myBDate   . '\', ' .
                 '    \'' . $myCard    . '\', ' .
                 '    \'' . $myStatus  . '\', ' .
                 '    \'' . $myVary    . '\', ' .
                 '    now() ' .
                 'from ' .
                 '    as_tips t ' .
                 'where ' .
                 '    t.oid=\'' . $myOid . '\'';

            $myRc = $this->executeQuery($mySQL);

            //////////////////////////
            $amt= $valueAry['amount'] * 100;
            $mySQL2= 'update as_tips set tip_amt=\'' . $amt . '\' where oid=\'' . $myOid . '\'';
            $myRc2 = $this->executeQuery($mySQL2);

            //////////////////////////
            $this->localClose();
        }
        return($myRc && $myRc2);
    }
    //  insert a row in the beneficiaries percengtages table
    function insertBPCT($valueAry, $fid, $pct) {
        if ($myRc = $this->localOpen()) {

            $myOid = $valueAry['tip_oid'];
            $myFid = $fid;
            $myPct = $pct;

            $mySQL =
                 'insert into as_bpct ' .
                 '(' .
                 '    bpct_tip, ' .
                 '    bpct_foundation, ' .
                 '    bpct_percent, ' .
                 '    created) ' .

                 'select ' .
                 '    t.tip_id, ' .
                 '    \'' . $myFid    . '\', ' .
                 '    \'' . $myPct     . '\', ' .
                 '    now() ' .
                 'from ' .
                 '    as_tips t ' .
                 'where ' .
                 '    t.oid=\'' . $myOid . '\'';

            $myRc = $this->executeQuery($mySQL);
            //////////////////////////
            $this->localClose();
        }
        return($myRc);
    }

    //  remove some expert competencies
    function removeExpertCompetencies($xid, $ary) {
        if ($myRc = $this->localOpen()) {
            while($myRc && list($index, $comp) = each($ary)){
                $mySQL = 'delete from as_expert_competencies ' .
                     'where xcmp_expert = \'' . $xid . '\' ' .
                     'and xcmp_cmptcy = \'' . $comp . '\'';

                $myRc = $this->executeQuery($mySQL);
                if (!$myRc) {
                    syslog(LOG_ERR,'SQLC.removeExpertCompetencies: insert failed <<SQL>><<' . $mySQL . '>>');
                    syslog(LOG_ERR, 'SQLC.removeExpertCompetencies: ' . $this->getErrorMessage());
                }
            }
            $this->localClose();
        }
        return($myRc);
    }

    //  remove an alt email address
    function removeAltEmail($email) {
        if ($myRc = $this->localOpen()) {
            $mySQL=
                 'delete from as_alt_email ' .
                 'where amail_email=\'' . $email .'\'';

            if (!$myRc = $this->executeQuery($mySQL)) {
                syslog(LOG_ERR,'SQLC.removeAltEmail: insert failed <<SQL>><<' . $mySQL . '>>');
                syslog(LOG_ERR, 'SQLC.removeAltEmail: ' . $this->getErrorMessage());
            }
            $this->localClose();
        }
        return($myRc);
    }

    //  get the next sequence number for a new anonymous user
    function anonUserSeq() {
        $myRc = FALSE;
        if ($this->localOpen()) {
            if ($this->executeQuery('select nextval(\'as_anon_user_seq\')')){
                $myArray = $this->fetchNextRow(0);
                $myRc = sprintf('%06d', $myArray['nextval']);
            }
            $this->localClose();
        }
        return($myRc);
    }

    //  utility function used by HOF accessors
    function buildMlistClause($attr, $lists) {
        $mlistClause= "";
        if (is_array($lists) && count($lists) > 0) {
            $listString  = "";
            foreach($lists as $list) {
                $listString .= (strlen($listString) > 0) ? " or " : "";
                $listString .= "mlist_name='$list'";
            }
            if (strlen($listString) > 0) {

                $mlistClause=
                     "    $attr in (select mlist_id " .
                     "    from as_mail_lists " .
                     "    where $listString)";
            } else {
                $mlistClause= "";
            }

        }
        return($mlistClause);
    }

    //  get this weeks expert Hall O' Fame data
    function privateReadExpertHOF($from, $to, $lists) {
        $myRc = FALSE;
        $Mclause=  $this->buildMlistClause("rating_mlist", $lists);
        $Mclause .= (strlen($Mclause) > 0) ? " and " : "";

        $mySQL =
             'select ' .
             '    trim(u.user_login) as login, ' .
             '    (sum(tab.tip_amt) / 100) as xdat ' .

             'from ' .
             '    (select ' .
             '        x.tip_recipient, ' .
             '        x.tip_amt, ' .
             '        xr.rating_mlist ' .
             '    from ' .
             '        as_tips x, ' .
             '        as_ratings xr ' .
             '    where ' .
             '        xr.rating_id = x.tip_rating and ' .
             '        x.tip_amt > 0 and ' .
             '        x.created > (select abstime(' . $from . ')) and ' .
             '        x.created <= (select abstime(' . $to  . '))) tab, ' .
             '    as_user u ' .

             'where ' . $Mclause .
             '    tab.tip_recipient=u.user_id and ' .
             "    u.user_status='activated' " .

             'group by u.user_login ' .
             'order by xdat desc ';

        $myRc = $this->arrayFromQuery($mySQL, PGSQL_ASSOC );
        if (!$myRc) {
            syslog(LOG_ERR,'SQLC.removeExpertCompetencies: insert failed <<SQL>><<' . $mySQL . '>>');
            syslog(LOG_ERR, 'SQLC.removeExpertCompetencies: ' . $r= $this->getErrorMessage());
        }

        return($myRc);
    }
    function generateBennieSet($bennies) {
        $myRc="";
        if (is_array($bennies) && count($bennies) > 0) {
            foreach($bennies as $b) {
                $myRc .= ((strlen($myRc) > 0) ? ", " : "") . $b;
            }
        }
        return($myRc);
    }

    //  expert hall of fame but only consider donations made to the
    //  indicated beneficiaries.  the $bennies array must exist and it
    //  must be non empty
    function readExpertHOFdonations($from, $to, $lists, $bennies= array()) {
        $myRc = FALSE;

        $bennieSet= $this->generateBennieSet($bennies);
        if ($bennieSet != "") {
            $Bclause= "xp.bpct_foundation in (" . $bennieSet  . " ) and ";
        } else {
            $Bclause= "";
        }

        $Mclause=  $this->buildMlistClause("rating_mlist", $lists);
        $Mclause .= (strlen($Mclause) > 0) ? " and " : "";

        $mySQL =
             'select ' .
             '    trim(u.user_login) as login, ' .
             '    (sum(tab.tip_amt) / 100) as xdat ' .

             'from ' .
             '    (select ' .
             '        x.tip_recipient, ' .
             '        (x.tip_amt * xp.bpct_percent) / 100 as tip_amt, ' .
             '        xr.rating_mlist ' .
             '    from ' .
             '        as_tips x, ' .
             '        as_ratings xr, ' .
             '        as_bpct xp ' .
             '    where ' . $Bclause .
             '        xr.rating_id = x.tip_rating and ' .
             '        x.tip_amt > 0 and ' .
             '        xp.bpct_tip =  x.tip_id and ' .
             '        x.created > (select abstime(' . $from . ')) and ' .
             '        x.created <= (select abstime(' . $to  . '))) tab, ' .
             '    as_user u ' .

             'where ' . $Mclause .
             '    tab.tip_recipient=u.user_id and ' .
             "    u.user_status='activated' " .

             'group by u.user_login ' .
             'order by xdat desc ';

        $myRc = $this->arrayFromQuery($mySQL, PGSQL_ASSOC );
        return($myRc);
    }

    //  read only the number of mebmers who have done ratings
    function readExpertHOFcounts($from, $to, $lists, $bennies=array(), $filter="all") {
        $myRc = FALSE;

        //  construct a clause to scree by maling lists
        $Mclause= $this->buildMlistClause("xr.rating_mlist", $lists);
        $Mclause .= (strlen($Mclause) > 0) ? " and " : "";
        //  maybe constructa  clause to filter by comments
        $Cclause= "";
        if ($filter == "text") {
            $Cclause= "trim(xr.rating_descr) <> '' and ";
        }

        $bennieSet= $this->generateBennieSet($bennies);
        if ($bennieSet == "") {
            $mySQL=
                 'select ' .
                 '    u.user_login as user, ' .
                 '    xr.rating_ratee as ratee, ' .
                 '    xr.rating_rator as rator ' .
                 'from  ' .
                 '    as_ratings xr, ' .
                 '    as_user u, ' .
                 '    as_user u2 ' .
                 'where  ' . $Mclause . $Cclause .
                 '    u.user_id = xr.rating_ratee and ' .
                 "    u.user_status = 'activated' and " .
                 '    u2.user_id = xr.rating_rator and ' .
                 "    u2.user_status = 'activated' and " .
                 '    xr.rating_rid is null and' .
                 '    xr.created > (select abstime(' . $from . ')) and ' .
                 '    xr.created <= (select abstime(' . $to  . ')) ' .
                 ' order by ratee ' .
                 '';

        } else {
            $mySQL=
                 'select ' .
                 '    u.user_login as user, ' .
                 '    xr.rating_ratee as ratee, ' .
                 '    xr.rating_rator as rator ' .

                 'from  ' .
                 '    as_ratings xr, ' .
                 '    as_user u, ' .
                 '    (select distinct ' .
                 '        u.user_id as uid, ' .
                 '        f.foundation_id as fid ' .
                 '    from ' .
                 '        as_pprof_details pd, ' .
                 '        as_pay_profiles pp, ' .
                 '        as_user u, ' .
                 '        as_expert x, ' .
                 '        as_foundations f ' .
                 '    where ' .
                 '        pp.pprof_expert_id = x.expert_id and ' .
                 '        x.expert_uid = u.user_id and ' .
                 '        pd.ppd_prof = pp.pprof_id and ' .
                 '        f.foundation_id = pd.ppd_found) uf, ' .
                 '    as_user u2 ' .

                 'where  ' . $Mclause . $Cclause .
                 '    u.user_id = xr.rating_ratee and ' .
                 "    u.user_status = 'activated' and " .
                 '    u.user_id = uf.uid and ' .
                 '    uf.fid in (' . $bennieSet . ') and ' .
                 '    u2.user_id = xr.rating_rator and ' .
                 "    u2.user_status = 'activated' and " .
                 '    xr.rating_rid is null and' .
                 '    xr.created > (select abstime(' . $from . ')) and ' .
                 '    xr.created <= (select abstime(' . $to  . ')) ' .
                 ' order by ratee ' .
                 '';
        }
        $myRc = $this->arrayFromQuery($mySQL, PGSQL_ASSOC );
        //echo("<br><br>SQL..."); var_dump($mySQL);

        if (!$myRc) {
            syslog(LOG_ERR,'SQLC.removeExpertCompetencies: insert failed <<SQL>><<' . $mySQL . '>>');
            syslog(LOG_ERR, 'SQLC.removeExpertCompetencies: ' . $r= $this->getErrorMessage());
        }

        return($myRc);
    }

    function readExpertHOFvalues($from, $to, $lists, $bennies= array()) {
        return(array(array('login'=> "testv", 'xdat'=>100)));

    }

    //  client hall of fame
    function readClientHOF($from, $to, $lists, $bennies=array()) {
        $myRc = FALSE;

        if (is_array($bennies) && count($bennies) > 0) {
            return($this->readBennieClientHOF($from, $to, $lists, $bennies));
        }

        $Mclause=  $this->buildMlistClause("rating_mlist", $lists);
        $Mclause .= (strlen($Mclause) > 0) ? " and " : "";

        $mySQL =
             'select ' .
             '    trim(u.user_login) as login, ' .
             '    (sum(tab.tip_amt) / 100) as pdat ' .

             'from ' .
             '    (select ' .
             '        x.tip_grantor, ' .
             '        x.tip_amt, ' .
             '        xr.rating_mlist ' .
             '    from ' .
             '        as_tips x, ' .
             '        as_ratings xr ' .
             '    where ' .
             '        xr.rating_id = x.tip_rating and ' .
             '        x.tip_amt > 0 and ' .
             '        x.created > (select abstime(' . $from . ')) and ' .
             '        x.created <= (select abstime(' . $to  . '))) tab, ' .
             '    as_user u, ' .
             '    as_client c ' .

             'where ' . $Mclause .
             '    tab.tip_grantor=u.user_id and ' .
             "    u.user_status='activated'  and " .
             '    c.client_uid=u.user_id and ' .
             "    c.client_tip_history='Public' " .

             'group by u.user_login ' .
             'order by pdat desc ';

        $myRc = $this->arrayFromQuery($mySQL, PGSQL_ASSOC );
        return($myRc);
    }

    //  read only the number of mebmers who have done ratings
    function readClientHOFcounts($from, $to, $lists, $filter="all") {
        $myRc = FALSE;

        //  construct a clause to screen by maling lists
        $Mclause= $this->buildMlistClause("xr.rating_mlist", $lists);
        $Mclause .= (strlen($Mclause) > 0) ? " and " : "";

        //  maybe constructa  clause to filter by comments
        $Cclause= "";
        if ($filter == "text") {
            $Cclause= "trim(xr.rating_descr) <> '' and ";
        }

        $mySQL=
             'select ' .
             '    u.user_login as user, ' .
             '    xr.rating_ratee as ratee, ' .
             '    xr.rating_rator as rator ' .
             'from  ' .
             '    as_ratings xr, ' .
             '    as_user u, ' .
             '    as_user u2 ' .
             'where  ' . $Mclause . $Cclause .
             '    u.user_id = xr.rating_rator and ' .
             "    u.user_status = 'activated' and " .
             '    u2.user_id = xr.rating_ratee and ' .
             "    u2.user_status = 'activated' and " .
             '    xr.rating_rid is null and' .
             '    xr.created > (select abstime(' . $from . ')) and ' .
             '    xr.created <= (select abstime(' . $to  . ')) ' .
             ' order by ratee ' .
             '';
        $myRc = $this->arrayFromQuery($mySQL, PGSQL_ASSOC );
        //echo("<br><br>SQL..."); var_dump($mySQL);

        if (!$myRc) {
            syslog(LOG_ERR,'SQLC.removeExpertCompetencies: insert failed <<SQL>><<' . $mySQL . '>>');
            syslog(LOG_ERR, 'SQLC.removeExpertCompetencies: ' . $r= $this->getErrorMessage());
        }
        return($myRc);
    }

    //  client hall of fame but only consider donations made to the
    //  indicated beneficiaries.  the $bennies array must exist and it
    //  must be non empty
    function readBennieClientHOF($from, $to, $lists, $bennies) {
        $myRc = FALSE;

        $bennieSet= "";
        foreach($bennies as $b) {
            $bennieSet .= ((strlen($bennieSet) > 0) ? "," : "") . $b;
        }
        $Mclause=  $this->buildMlistClause("rating_mlist", $lists);
        $Mclause .= (strlen($Mclause) > 0) ? " and " : "";

        $mySQL =
             'select ' .
             '    trim(u.user_login) as login, ' .
             '    (sum(tab.tip_amt) / 100) as pdat ' .

             'from ' .
             '    (select ' .
             '        x.tip_grantor, ' .
             '        (x.tip_amt * xp.bpct_percent) / 100 as tip_amt, ' .
             '        xr.rating_mlist ' .
             '    from ' .
             '        as_tips x, ' .
             '        as_ratings xr, ' .
             '        as_bpct xp ' .
             '    where ' .
             '        xr.rating_id = x.tip_rating and ' .
             '        x.tip_amt > 0 and ' .
             '        xp.bpct_tip =  x.tip_id and ' .
             '        xp.bpct_foundation in (' . $bennieSet  .' ) and ' .
             '        x.created > (select abstime(' . $from . ')) and ' .
             '        x.created <= (select abstime(' . $to  . '))) tab, ' .
             '    as_user u, ' .
             '    as_client c ' .

             'where ' . $Mclause .
             '    tab.tip_grantor=u.user_id and ' .
             "    u.user_status='activated'  and " .
             '    c.client_uid=u.user_id and ' .
             "    c.client_tip_history='Public' " .

             'group by u.user_login ' .
             'order by pdat desc ';

        $myRc = $this->arrayFromQuery($mySQL, PGSQL_ASSOC );
        return($myRc);
    }

    //  deprecated... allows existing code to work
    function readWeeksExpertHOF() {
        return($this->readExpertHOF("wk"));
    }


    //  read a list of alternate email addresses for a given
    //  user
    function fetchAltEmailArray($uLogin) {
        $myRc = FALSE;

        $mySQL =
             'select  ' .
             '    a.amail_email as addy, ' .
             '    a.amail_activep as activep ' .
             'from  ' .
             '    as_alt_email a, ' .
             '    as_user u ' .
             'where  ' .
             '    u.user_login=\'' . $uLogin . '\' and ' .
             '    u.user_id=a.amail_uid ';

        $myRc = $this->arrayFromQuery($mySQL);
        return($myRc);
    }
    // read the email attributes associated with an email address
    function fetchAltEmailRow($email) {
        $myRc = FALSE;

        $mySQL =
             'select  * ' .
             'from  ' .
             '    as_alt_email ' .
             'where  ' .
             '    amail_email=\'' . $email .'\'';

        $myRc = $this->execSingleRowQuery($mySQL);
        return($myRc);
    }

    //  set the active state of an alternate email row
    function setAltEmailRowActivation($email, $state) {
        $myState= ($state == 't') ? 't' : 'f';

        if ($myRc = $this->localOpen()) {
            $mySQL =
                 'update as_alt_email ' .
                 'set ' .
                 '    amail_activep=\'' . $myState . '\' ' .
                 'where  ' .
                 '    amail_email=\'' . $email . '\'';

            $myRc = $this->executeQuery($mySQL);
            if (!$myRc) {
                syslog(LOG_ERR, 'SQLC.setAltEmailRowActivation() ' . $this->getErrorMessage());
                syslog(LOG_ERR, 'SQLC.setAltEmailRowActivation() query<<' . $mySQL . '>>');
            }
            $this->localClose();
        }
        return($myRc);
    }

    //  Get this user's default pay profile if there is one`
    function fetchUserDefaultPayProfile($user) {
        $myRc = FALSE;

        $mySQL =
             'select ' .
             '    p.pprof_name as name ' .
             'from ' .
             '    as_pay_profiles p, ' .
             '    as_user u, ' .
             '    as_expert x ' .
             'where ' .
             '    u.user_login=\'' . $user . '\' and ' .
             '    x.expert_uid=u.user_id and ' .
             '    p.pprof_id=x.expert_profile and ' .
             '    p.pprof_active = \'t\' and ' .
             '    p.pprof_expert_id=x.expert_id';

        $myRc = $this->arrayFromQuery($mySQL);
        //echo("<br>Default user profile...");
        //var_dump($myRc);

        return($myRc);
    }
    function fetchUserPayProfile($user, $profname) {
        $myRc = FALSE;

        $mySQL =
             'select ' .
             '    p.pprof_id as id, ' .
             '    \'' . $user . '\' as proppa_writer, ' .
             '    u.user_status, ' .
             '    p.pprof_proppa as proppa, ' .
             '    trim(p.pprof_proppa_tp) as proppa_tp ' .
             'from ' .
             '    as_pay_profiles p, ' .
             '    as_user u, ' .
             '    as_expert x ' .
             'where ' .
             '    u.user_login=\'' . $user . '\' and ' .
             '    x.expert_uid=u.user_id and ' .
             '    p.pprof_active = \'t\' and ' .
             '    p.pprof_name = \'' . $profname . '\' and ' .
             '    p.pprof_expert_id=x.expert_id ';

        $myRc = $this->arrayFromQuery($mySQL);
        //echo("<br>Default user profile...");
        //var_dump($myRc);

        return($myRc);
    }

//  This is an array of pay profiles defined by an
//  expert whose user name is passed as an argument
    function fetchUserPayProfiles($user) {
        $myRc = FALSE;

        $mySQL =
             'select ' .
             '    p.pprof_active as active, ' .
             '    p.pprof_name as name, ' .
             '    p.pprof_id as pindex, ' .
             '    p.pprof_xseq as id, ' .
             '    p.oid as oid ' .
             'from ' .
             '    as_pay_profiles p, ' .
             '    as_user u, ' .
             '    as_expert x ' .
             'where ' .
             '    u.user_login=\'' . $user. '\' and ' .
             '    x.expert_uid=u.user_id and ' .
             '    p.pprof_expert_id=x.expert_id ' .
             'order by ' .
             '    name';

        $myRc = $this->arrayFromQuery($mySQL);
        //var_dump($myRc);

        return($myRc);
    }
    // set the sequence number for this pay profile.  this
    // is a fragment of a transaction which must be executed
    // after the pay profile row has been inserted.
    function updatePayProfileSequence($oid) {
        $mySQL =
             'update as_pay_profiles  ' .
             'set pprof_xseq=  ' .
             '    (select count(p2.oid)  ' .
             '        from  ' .
             '            as_pay_profiles p1,  ' .
             '            as_pay_profiles p2  ' .
             '        where  ' .
             '            p1.oid=\'' . $oid . '\' and  ' .
             '            p2.pprof_expert_id=p1.pprof_expert_id)  ' .
             'where  ' .
             ' oid=\'' . $oid . '\'';

        $pprofId= 0;
        if ($myRc = $this->executeQuery($mySQL)) {
            if ($ary= $this->execSingleRowQuery('select pprof_id from as_pay_profiles where oid=\'' . $oid . '\'')){
                $pprofId= $ary['pprof_id'];
                //echo("<br>UserSqlConn::updatePayProfileSequence() \$pprofId is $pprofId");
            }
        }

        return($pprofId);
    }
    //  set the state of the profile active flag
    function updatePayProfileActive($oid, $flag) {
        $myRc = FALSE;
        $mySQL =
             'update as_pay_profiles  ' .
             'set pprof_active=\'' . $flag . '\' ' .
             'where oid=\'' . $oid  . '\'';
        $myRc = $this->executeQuery($mySQL);
        return($myRc);
    }
    //  This is an array of beneficiaries in the
    //  expert public profile of the user whose login
    //  is passed as an argument
    function fetchExpertBeneficiaries($uid) {
        $myRc = FALSE;

        $mySQL =
             'select  ' .
             '    f.foundation_name as name,  ' .
             '    pd.ppd_percent as pct ' .

             'from  ' .
             '    as_pay_profiles pp,  ' .
             '    as_pprof_details pd,  ' .
             '    as_expert x,  ' .
             '    as_foundations f,  ' .
             '    as_user u  ' .

             'where  ' .
             '    u.user_login=\'' . $uid . '\' and  ' .
             '    x.expert_uid = u.user_id and  ' .
             '    pp.pprof_id = x.expert_profile and  ' .
             '    pd.ppd_prof = pp.pprof_id and  ' .
             '    pd.ppd_found = f.foundation_id';

        $myRc = $this->arrayFromQuery($mySQL);

        return($myRc);
    }

    //  get the beneficiaries Hall O' Fame data
    function readBeneficiaryHOF() {
        $myRc = FALSE;

        $mySQL =
             'select ' .
             '    t.*, ' .
             '    f2.foundation_url as web ' .
             'from ' .
             '    (select count(*) as count, name ' .
             '    from ' .
             '        (select ' .
             '            f.foundation_name as name ' .
             '        from ' .
             '            as_pay_profiles p, ' .
             '            as_pprof_details pp, ' .
             '            as_foundations f ' .
             '        where ' .
             '            pp.ppd_prof = p.pprof_id and ' .
             '            f.foundation_id = pp.ppd_found) u ' .
             '    group by name) t, ' .
             '    as_foundations f2 ' .
             'where f2.foundation_name = t.name ' .
             'order by count desc ';

        $myRc = $this->arrayFromQuery($mySQL, PGSQL_ASSOC );
        return($myRc);
    }
    //  get the beneficiaries Hall O' Fame data
    function privateReadPatronBeneficiaryHOF($from, $to, $user, $fids) {
        $myRc = FALSE;

        $locUser= trim($user);

        $bennieSet= $this->generateBennieSet($bennies);
        if ($bennieSet != "") {
            $Bclause= "xp.bpct_foundation in (" . $bennieSet  . " ) and ";
        } else {
            $Bclause= "";
        }

        $mySQL =
             'select ' .
             '    f.foundation_name as name, ' .
             '    f.foundation_url as web, ' .
             '    t.count / 100 as count ' .
             'from ' .
             '    (select ' .
             '        xp.bpct_foundation as found, ' .
             '        sum((x.tip_amt * xp.bpct_percent) / 100) as count ' .
             '    from ' .
             '        as_tips x, ' .
             '        as_ratings xr, ' .
             '        as_user u, ' .
             '        as_client c, ' .
             '        as_bpct xp ' .
             '    where ' . $Bclause .
             '        xr.rating_id = x.tip_rating and ' .
             '        x.tip_amt > 0 and ' .
             "        u.user_login = '" . $locUser . "' and " .
             "        u.user_status = 'activated' and" .
             '        c.client_uid=u.user_id and ' .
             "        c.client_tip_history='Public' and " .
             '        xr.rating_rator = u.user_id and ' .
             '        x.created > (select abstime(' . $from . ')) and ' .
             '        x.created <= (select abstime(' . $to  . ')) and ' .
             '        xp.bpct_tip =  x.tip_id ' .
             '    group by found) t, ' .
             '    as_foundations f ' .
             'where ' .
             '    f.foundation_id = t.found ';
        //var_dump($mySQL);

        $myRc = $this->arrayFromQuery($mySQL, PGSQL_ASSOC );
        return($myRc);
    }
    //  get the beneficiaries Hall O' Fame data
    function privateReadVolunteerBeneficiaryHOF($from, $to, $user, $bennies) {
        $myRc = FALSE;

        $locUser= trim($user);

        $bennieSet= $this->generateBennieSet($bennies);
        if ($bennieSet != "") {
            $Bclause= "xp.bpct_foundation in (" . $bennieSet  . " ) and ";
        } else {
            $Bclause= "";
        }

        $mySQL =
             'select ' .
             '    f.foundation_name as name, ' .
             '    f.foundation_url as web, ' .
             '    t.count / 100 as count ' .
             'from ' .
             '    (select ' .
             '        xp.bpct_foundation as found, ' .
             '        sum((x.tip_amt * xp.bpct_percent) / 100) as count ' .
             '    from ' .
             '        as_tips x, ' .
             '        as_ratings xr, ' .
             '        as_user u, ' .
             '        as_bpct xp ' .
             '    where ' . $Bclause .
             '        xr.rating_id = x.tip_rating and ' .
             '        x.tip_amt > 0 and ' .
             "        u.user_login = '" . $locUser . "' and " .
             "        u.user_status = 'activated' and" .
             '        xr.rating_ratee = u.user_id and ' .
             '        x.created > (select abstime(' . $from . ')) and ' .
             '        x.created <= (select abstime(' . $to  . ')) and ' .
             '        xp.bpct_tip =  x.tip_id ' .
             '    group by found) t, ' .
             '    as_foundations f ' .
             'where ' .
             '    f.foundation_id = t.found ';

        $myRc = $this->arrayFromQuery($mySQL, PGSQL_ASSOC );
        return($myRc);
    }

    //  get the beneficiaries Hall O' Fame data
    function readMemberBeneficiaryHOF($from, $to, $type, $user, $fids) {
        $myRc = FALSE;

        if ($type == "patron") {
            $myRc= $this->privateReadPatronBeneficiaryHOF($from, $to, $user, $fids);
        } else if ($type =="volunteer") {
            $myRc= $this->privateReadVolunteerBeneficiaryHOF($from, $to, $user, $fids);
        }
        return($myRc);
    }


    //  returna  row associated with this mailing list
    function mlistRow($listName) {
        $myRc = FALSE;
        $myArg= trim(strtolower($listName));
        $mySQL =
             'select * ' .
             'from ' .
             '    as_mail_lists ' .
             'where ' .
             '    trim(mlist_name)=\'' . $myArg . '\'';
        //echo("<br><br>userSqlConnn::mlistRow() mySQL="); var_dump($mySQL);
        $myRc = $this->execSingleRowQuery($mySQL);
        return($myRc);
    }

    //  get the admin expert row for this mailing list
    function mlistAdmin($listName) {
        $myRc = FALSE;
        $myArg= trim(strtolower($listName));

        $mySQL =
             'select x.* ' .
             'from ' .
             '    as_mail_lists m,' .
             '    as_expert x ' .
             'where ' .
             '    x.expert_id = m.mlist_admin and ' .
             '    m.mlist_name=\'' . $myArg . '\'';

        $myRc = $this->execSingleRowQuery($mySQL);
        return($myRc);
    }

    //  get the user roe for this mailing list admin
    function mlistUser($listName) {
        $myRc = FALSE;
        $myArg= trim(strtolower($listName));

        $mySQL =
             'select u.* ' .
             'from ' .
             '    as_mail_lists m, ' .
             '    as_user u, ' .
             '    as_expert x ' .
             'where ' .
             '    u.user_id = x.expert_uid and ' .
             '    x.expert_id = m.mlist_admin and ' .
             '    m.mlist_name=\'' . $myArg . '\'';

        $myRc = $this->execSingleRowQuery($mySQL);
        return($myRc);
    }

    //  load a list of mailing list competencies
    function loadMlistComps($list) {
        $mySQL=
             'select  c.* ' .
             'from ' .
             '    as_mlist_comps mc, ' .
             '    as_competencies c, ' .
             '    as_mail_lists m  ' .
             'where  ' .
             '    mc.mc_mid = m.mlist_id and ' .
             '    mc.mc_cid = c.cmptcy_id and ' .
             '    m.mlist_name = \'' . $list . '\'';

        $myDBresults= $this->arrayFromQuery($mySQL);
        return($myDBresults);
    }

    //  build an array of mailing lists administered by a user
    //  argument is a user login_id
    function mlistByAdmin($user) {
        $mySQL=
             'select  m.* ' .
             'from ' .
             '     as_user u, ' .
             '     as_expert x, ' .
             '     as_mail_lists m  ' .
             'where  ' .
             '    m.mlist_admin= x.expert_id and ' .
             '    x.expert_uid= u.user_id and ' .
             '    u.user_login=\'' . $user . '\'';

        $myDBresults= $this->arrayFromQuery($mySQL);
        return($myDBresults);
    }
    //  build an array of all mailing lists in the table
    function mlistAll() {
        $mySQL=
             'select  * ' .
             'from ' .
             '     as_mail_lists  ';

        $myDBresults= $this->arrayFromQuery($mySQL, PGSQL_ASSOC);
        return($myDBresults);
    }
    //  build an array of all foundations
    function foundationsAll() {
        $mySQL=
             'select  * ' .
             'from ' .
             '     as_foundations  ';

        $myDBresults= $this->arrayFromQuery($mySQL, PGSQL_ASSOC);
        return($myDBresults);
    }
}
?>
