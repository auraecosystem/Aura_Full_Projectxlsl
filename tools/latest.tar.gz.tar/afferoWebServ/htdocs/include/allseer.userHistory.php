<?php
//  $Name: ORG-TEST $, $Id: allseer.userHistory.php,v 1.9 2002/12/09 19:57:40 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//
require_once("global.php");
require_once("allseer.variousFunctions.php");
require_once("allseer.UserSqlConn.php");
require_once("allseer.editPayProf.php");

define("nonMember", "Non-Member");

class userHistory
{
    function userHistory() {
        global $SERVER_NAME;
        $this->server= $SERVER_NAME;
        $this->denseReputation= "";
        $this->browserErrorDisplay= "";

        $this->dbConnection= new UserSqlConn();
        $this->ppe= new pp_editor();

        $this->competencyAry= $this->dbConnection->buildCompetencyArray();
        $this->ratingsDescrAry= $this->dbConnection->fetchRatingDescriptions();

        $this->giftingLevel=
             array_flip(
                 array(
                     "A" => 5,
                     "B" => 10,
                     "C" => 20,
                     "D" => 40,
                     "E" => 80,
                     "F" => 160,
                     "G" => 320,
                     "H" => 640,
                     "I" => 1280,
                     "J" => 2560,
                     "K" => 5120,
                     "L" => 10240,
                     "M" => 20480,
                     "N" => 40960,
                     "O" => 80000,
                     "P" => 160000,
                     "Q" => 320000,
                     "R" => 640000,
                     "S" => 1280000,
                     "T" => 2560000
                     ));

        //  these don't really need to be here for the progrsm to
        //  work; but I think that they go a long way for
        //  understanding.
        $this->userRow= array();
        $this->appliedRatings= array();
        $this->dpyCommentsAry= array();
        $this->dpyReputationAry= array();

        //  set up default values for persistent (ie session)
        //  properties.  the array maps object properties, default
        //  values and url keywords.
        $this->sessionMapAry= $sAry= array(
            array("defaultValue" => "0", "urlKey" => "test", "uhProperty" => "featureTest"),
            array("defaultValue" => "unfilter", "urlKey" => "tdf", "uhProperty" => "toggleDonorFilter"),

            array("defaultValue" => 0,          "urlKey" => "fcm", "uhProperty" => "firstDpyComment"),
            array("defaultValue" => 10,         "urlKey" => "lcm", "uhProperty" => "lastDpyComment"),
            array("defaultValue" => "4D 2A",    "urlKey" => "scm", "uhProperty" => "dpyCommentsSort"),

            array("defaultValue" => 0,          "urlKey" => "mfcm", "uhProperty" => "firstMadeDpyComment"),
            array("defaultValue" => 10,         "urlKey" => "mlcm", "uhProperty" => "lastMadeDpyComment"),
            array("defaultValue" => "4D 2A",    "urlKey" => "mscm", "uhProperty" => "dpyMadeCommentsSort")
            );

        foreach($sAry as $p) {
            $this->$p['uhProperty']= $p['defaultValue'];
        }
    }
    function featureTest() {
        $rc= (isset($this->featureTest) && $this->featureTest == "1");
        //echo("<br>fatureTest returns..."); var_dump($rc);
        return($rc);
    }

    //  check f it is okay to edit a rating
    function ratingEditIsAllowed() {
        $rc= isset($GLOBALS["ratingEditIsAllowed"]) && $GLOBALS["ratingEditIsAllowed"];
        return($rc);
    }
    //  get all of the ratings applied to this user--along with some
    //  ancillary info
    function getRatingsAppliedToUser() {
        $myRC= "OK";
        $this->appliedRatings= $this->dbConnection->fetchRatingsAppliedToUser($this->user);
        return($myRC);
    }
    //  get all of the ratings made ny this user
    function getRatingsMadeByUser() {
        $myRC= "OK";
        $this->userRatings= $this->dbConnection->fetchRatingsMadeByUser($this->user);
        return($myRC);
    }
    //  given a rating value, retrn the description for that rating
    function getRatingDescr($value) {
        $descr= "";
        $ary=& $this->ratingsDescrAry;
        reset($ary);

        foreach($ary as $r){
            if ($r['rating_val'] == $value) {
                $descr= $r['rating_descr'];
                break;
            }
        }
        return($descr);
    }
    //  given a competency_id return it's description
    function getCompetencyDescr($cid) {
        $descr= "";
        $ary=& $this->competencyAry;
        reset($ary);

        foreach($ary as $r){
            if ($r['cmptcy_id'] == $cid) {
                $descr= $r['cmptcy_descr'];
                break;
            }
        }
        return($descr);
    }
    //  return an anchor to the help page
    function helpAnchor($dpyText) {
        $anchor= "<a target=\"new\" href=\"http://{$this->server}/help.php?helpCat=UHrepsum\">" .
             $dpyText . "</a>";
        return($anchor);
    }
    //  return a comment field formatted for display
    function fmtCommentText($text) {
        $r= "&nbsp;&nbsp;";
        if (strlen($text) > 0) {
            $r .= htmlspecialchars($text, ENT_QUOTES);
            $r= nl2br(preg_replace("/\\n/", "\n&nbsp;&nbsp;", wordwrap($r,100,"\n",1)));
        }
        return($r);
    }
    //  get a rating description and format it
    function getRatingComment($ary) {
        return($this->fmtCommentText($ary['rating_descr']));
    }
    //  pretty standard fare
    function signum($x) {
        if ($x < 0) {
            return(-1);
        } else if ($x > 0) {
            return(1);
        } else {
            return(0);
        }
    }
    //  compare two comment arrays
    function commentComparator($a, $b) {
        $retval=0;
        reset($this->currentSortKeys);
        while(list($k, $v)= each($this->currentSortKeys)) {
            $col= $v[0]; $dir= $v[1];
            if ($a[$col] == $b[$col]) {
                continue;

            } else if ($a[$col] == NULL) {
                $retval= 1;

            } else if ($b[$col] == NULL) {
                $retval= -1;

            } else {
                if ($col == "4") {
                    //  this is a date column (ie mm/dd/yyyy)
                    $dateA= strtotime(preg_replace("/[, ].*/", "", $a[$col]));
                    $dateB= strtotime(preg_replace("/[, ].*/", "", $b[$col]));
                    $retval= $dateA - $dateB;

                } else {
                    $retval= strcmp($a[$col], $b[$col]);
                }
                if ($v[1] == "D") {
                    $retval= -$retval;
                }
                break;
            }
        }
        return($this->signum($retval));
    }
    //  construct a rating value array entry.  it links to a
    //  help page for the user history
    function getCommentRvEntry($ary) {
        $rValue= trim($ary['rating_value']);
        $rvEntry= $this->helpAnchor($rValue) . "&nbsp;";
        $rvEntry .= "(" . $this->getRatingDescr($rValue) ."),&nbsp;";
        return($rvEntry);
    }
    //  construct a competency array entry.
    function getCommentCompEntry($ary) {
        $cEntry= NULL;
        if (($comp= $ary['rating_category']) != NULL) {
            $cDescr= $this->getCompetencyDescr($comp);
            $cEntry= ($cDescr != "") ? $cDescr . ",&nbsp;" : "";
        }
        return($cEntry);
    }
    //  construct a tip array entry.
    function getCommentTipEntry($ary) {
        $tip= ((($ary['tip_amt'] == NULL)) ? "0" : $ary['tip_amt']) /100;
        if ((trim($ary['client_tip_history']) != "Public") || $this->alwaysMask) {
            $tip= ($tip > 0) ? "**" : 0;
        }
        $str .= ($tip != 0) ? ("\$" . $tip . ",&nbsp;") : "";

        return($str);
    }
    function stripUsecFromDTG($dtg){
        $retVal= preg_replace("/\.[0-9]*-/", "-", $dtg);
        return($retVal);
    }

    //  construct a tip date array entry.
    function getCommentTipDTGEntry($ary) {
        $dtg = strftime("%D", strtotime($this->stripUsecFromDTG($ary['created']))) . " &nbsp;";
        return($dtg);
    }

    //  construct a tip date array entry.
    function getCommentRidEntry($ary) {
        $rid= $ary['rating_rid'];
        $ridEntry= ((($rid == 0) || ($rid == NULL)) ? "V" : "P");
        return($ridEntry);
    }
    //  construct a tip date array entry.
    function getRatingEditLinks($ary, $str) {
        $rid= $ary['rating_id'];
        $escStr= urlencode($str);

        $edit= "<a target=new href=\"http://{$this->server}/rating-editor.php?rid=$rid&str=$escStr\">edit</a>";
        return("&nbsp;&nbsp;" . $edit);
    }
    //  construct a comments array
    function commentColumns($ary, $name, $linkP= TRUE) {
        $comment= array();
        $indString .= ($this->indent) ? "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" : "";

        $nString= "&nbsp;&nbsp;" . $indString;
        if ($linkP) {
            $nString .= "<a href=\"http://{$this->server}/user-history.php?u=$name\">$name</a>&nbsp;";
        } else {
            $nString .= "$name&nbsp;";
        }
        $redStr = $comment[]= $nString;

        //  rating value links to the help page for user history
        $comment[]= $this->getCommentRvEntry($ary);
        //  add competency --if it exists
        $comment[]= $this->getCommentCompEntry($ary);
        //  add tip amount, but mask it out unless tip_history is public
        $redStr.= $comment[]= $this->getCommentTipEntry($ary);
        //  date that the tip was made
        $redStr.= $comment[]= $this->getCommentTipDTGEntry($ary);
        //  append "P" for patron, "V" for volunteer
        //$redStr.= $comment[]= $this->getCommentRidEntry($ary);
        //  links to comment editor, rating deletion
        if ($this->ratingEditIsAllowed()) {
            $comment[]= $this->getRatingEditLinks($ary, $redStr);
        }
        //  break to a new line and add indentation
        $comment[]= "<br />" . $indString;
        //  add the rating comment if it exists
        $c= nl2br($this->getRatingComment($ary));
        $c= preg_replace("/(<br \/> *)+/", "<br />" . $indString , $c);

        $comment[]= $c;
        //  turn of extra indentation
        $this->indent= FALSE;
        return($comment);
    }
    
    function commentDiscrim($vAry){
        $rc= (preg_match("/reply:/", $vAry[0]) > 0) ? "volunteer" : "patron";
        return($rc);
    }
    function madeCommentDiscrim($vAry){
        $rc= (preg_match("/reply.*:/", $vAry[0]) > 0) ? "patron" : "volunteer";
        return($rc);
    }
    
    //  construct an array of lines for use in the smarty template
    //  array structures are crufty.  watch out.
    function buildSmartyLines($ary, $func) {
        $result= array();
        //  and build an array of lines for the smarty template
        while(list($k, $v)= each($ary)) {
            $lineAry= array(); $rest= $name= "";
            if(isset($v['rid'])){
                unset($v['rid']);
            }
            $rest= $name= "";
            while(list($k1, $v1)= each($v)) {
                if ($k1 == 0) {
                    $name = $v1;
                } else {
                    $rest .= $v1 != NULL ? "$v1" : "";
                }
            }
            $image= $this->$func($v);
            $result[]= array('name' => $name, 'image' => $image, 'rest' => $rest);
        }
        //var_dump($result);
        
        return($result);
    }
    
    //  get all of the ratings --along with some ancillary info
    function buildCommentsAry() {
        $myRatingsDescrAry=& $this->ratingsDescrAry;
        $inAry=& $this->appliedRatings;
        $sortAry= $ratingRids= array();
        $this->alwaysMask= FALSE;

        $ratingRids= array();
        for($i=0, $last=  count($inAry); $i < $last; $i++) {
            //  some ratings are filtered out
            if ($this->ratorFilter($inAry[$i])) continue;
            //  construct an array of comment columns
            if ($inAry[$i]['rating_rid'] != NULL) {
                $ratingRids[]= $inAry[$i];

            } else {
                $cAry= $this->commentColumns($inAry[$i], $inAry[$i]['rator_name']);
                $cAry['rid']= 'rid::' . $inAry[$i]['rating_id'];
                $sortAry[]= $cAry;
            }
        }
        //  these will be displayed threaded in the made comments
        //  table
        $this->madeRidComments= $ratingRids;

        //  now sort the array as spectified by the sort key
        $this->currentSortKeys= preg_split("/ /", $this->dpyCommentsSort);
        usort($sortAry, array($this, "commentComparator"));
        //echo("<br><br>sortAry..."); var_dump($sortAry);
        $this->builtCommentsAry= $sortAry;
    }

    function mergeRids2Comments($sortAry, $ellRids){
        $result= array();
        for ($i=0, $last= count($sortAry); $i < $last; $i++) {
            $s= $sortAry[$i];
            $r= $s['rid']; unset($s['rid']);
            $result[]= $s;
            if (isset($ellRids["$r"])) {
                $t= $ellRids["$r"];
                $result[]= $t;
            }
        }
        return($result);
    }

    function mergeCommentsRids() {
        $sortAry= $this->builtCommentsAry;
        $rAry=& $this->ridComments;
        $ellRids= array();
        for ($i=0, $last= count($rAry); $i < $last; $i++) {
            if ($this->rateeFilter($rAry[$i])) {
                $name= nonMember;
            } else {
                $name= trim($rAry[$i]['ratee_name']);
            }
            $linkP= ($name != nonMember);
            $this->indent= TRUE;
            $eAry= $this->commentColumns($rAry[$i], $this->user ."'s reply:", FALSE);
            $rIx= "rid::" . $rAry[$i]['rating_rid'];
            $ellRids["$rIx"]= $eAry;
        }
        $sortAry= $this->mergeRids2Comments($sortAry, $ellRids);
        $this->dpyCommentsAry= $this->buildSmartyLines($sortAry, "commentDiscrim");
    }
    
    //  get all of the ratings --along with some ancillary info
    function buildMadeCommentsAry() {
        $myRatingsDescrAry=& $this->ratingsDescrAry;
        $inAry=& $this->userRatings;
        $this->alwaysMask= (trim($this->clientRow['client_tip_history']) != "Public");

        $rids= array();
        for ($i=0, $last= count($inAry); $i < $last; $i++) {
            if ($inAry[$i]['rating_rid'] != NULL) {
                $rids[]= $inAry[$i];

            } else {
                if ($this->rateeFilter($inAry[$i])) {
                    $name= nonMember;
                } else {
                    $name= trim($inAry[$i]['ratee_name']);
                }
                $linkP= ($name != nonMember);

                $cAry= $this->commentColumns($inAry[$i], $name, $linkP);
                $cAry['rid']= 'rid::' . $inAry[$i]['rating_id'];
                $sortAry[]= $cAry;
            }
        }
        //  these will be displayed threaded in the comments
        //  table
        $this->ridComments= $rids;

        //  now sort the array as spectified by the sort key
        $this->currentSortKeys= preg_split("/ /", $this->dpyMadeCommentsSort);
        usort($sortAry, array($this, "commentComparator"));
        $this->builtMadeCommentsAry= $sortAry;
    }

    function mergeMadeCommentsRids() {
        ///  feature test test code
        $sortAry= $this->builtMadeCommentsAry;

        $rAry=& $this->madeRidComments;
        $ellRids= array();
        for ($i=0, $last= count($rAry); $i < $last; $i++) {
            if ($this->ratorFilter($rAry[$i])) {
                $name= nonMember;
            } else {
                $name= trim($rAry[$i]['rator_name']);
            }
            $linkP= ($name != nonMember);
            $this->indent= TRUE;
            $eAry= $this->commentColumns($rAry[$i], $name . "'s reply to " . $this->user. ":", FALSE);
            $rIx= "rid::" . $rAry[$i]['rating_rid'];
            $ellRids["$rIx"]= $eAry;
        }
        $sortAry= $this->mergeRids2Comments($sortAry, $ellRids);
        $this->dpyMadeCommentsAry= $this->buildSmartyLines($sortAry, "madeCommentDiscrim");
    }
    
    //  argment is a user rating info array.  return true if this
    //  rator is to be filtered out.
    function ratorFilter($ary) {
        $filter= FALSE;
        $name= trim($ary['rator_name']);
        $rAry=& $this->ratersAry;

        //  if the rator's account is not in an activeted state then
        //  skip
        $filter |= (trim($ary['rator_status']) != "activated");

        //  if this user is not in the raters array, return true; if
        //  this user is in the raters array but has not given or
        //  received any gifts return true depending on the value
        //  of the toggled donor flag;
        if (!$filter && !($filter |= !isset($this->ratersAry[$name]))) {
            $rAry=& $this->ratersAry[$name][0];
            $totalGifts= (0 + $rAry['given_count'] + $rAry['recvd_count']);
            $filter |= ($totalGifts == 0 && $this->toggleDonorFilter == "filter");
        }
        return($filter);
    }
    //  argment is a rating made by this user.  return true if this
    //  rator is to be filtered out.
    function rateeFilter($ary) {
        $filter= FALSE;
        $name= trim($ary['ratee_name']);
        $rAry=& $this->ratersAry;

        //  if the rator has an inactivated account then skip
        $filter |= (trim($ary['ratee_status']) != "activated");
        return($filter);
    }
    //  determine gifting level and range
    function getGiftRangeAndLevel($amt) {
        $retAry= array("range" => "N/A", "level" => "*");

        if ($amt > 0) {
            $gType= $lkey= 0;
            reset($this->giftingLevel);

            while (list($key, $val)= each($this->giftingLevel)) {
                if (($amt) <= $key) {
                    $retAry['level']= $val;
                    $rKey= $key;
                    break;
                }
                $lkey= $key;
            }
            $retAry['range']= sprintf("(\$%d-\$%d)", $lkey+1, $rKey);
        }
        return($retAry);
    }
    //  get all of the ratings --along with some ancillary info
    function patronageCommentsEntry() {
        //  calculate average rating value
        $inAry=& $this->appliedRatings;
        reset($inAry);
        $avgAccum = $pCount= 0;
        foreach($inAry as $r){
            if ($this->ratorFilter($r)) continue;

            if ($r['rating_rid'] != NULL && $r['rating_rid'] != 0 ) {
                $pCount += 1;
                $accum += $r['rating_value'];
            }
        }

        //  build the patronage comments line
        $avgAccum= ($accum > 0) ? round(($accum / $pCount)) : 0;

        $aText= ($avgAccum > 0) ? $avgAccum : "*";
        $this->denseReputation .= $aText;
        $descr= ($aText != "*") ? $this->getRatingDescr($avgAccum) : "N/A";

        $aryEntry[]= "&nbsp;&nbsp;". $this->helpAnchor($aText) . "&nbsp;";
        $aryEntry[]= $descr;
        $aryEntry[]= $pCount;
        $aryEntry[]= "Comments Received";
        return($aryEntry);
    }
    //  format the Direct gifts array entry
    function directGiftsEntry() {
        $gAry=& $this->userGifts[0];
        $this->giftsGiven= $given= (isset($gAry["given_amt"])) ? $gAry["given_amt"]/100 : 0;
        $rAry= $this->getGiftRangeAndLevel($given);

        $publicHistory= (trim($this->clientRow['client_tip_history']) == "Public");

        $gLevel= $publicHistory ? $rAry['level'] : '*';
        $this->denseReputation .= $gLevel;

        $aryEntry[]= "&nbsp;&nbsp;". $this->helpAnchor($gLevel) . "&nbsp;";
        $aryEntry[]= ($publicHistory ? $rAry['range'] : "N/A");
        $aryEntry[]= $gAry['given_count'];
        $aryEntry[]= "Gifts Made Totaling $". ($publicHistory ? $given : "**");
        return($aryEntry);
    }
    //  format the volunteer Comments entry
    function volunteerCommentsEntry() {
        //  calculate average rating value
        $inAry=& $this->appliedRatings;
        reset($inAry);
        $avgAccum = $vCount= 0;

        foreach($inAry as $r){
            if ($this->ratorFilter($r)) continue;

            if ($r['rating_rid'] == NULL && $r['rating_rid'] == 0 ) {
                $vCount += 1;
                $accum += $r['rating_value'];
            }
        }
        //  build the volunteer comments array
        $avgAccum= ($accum > 0) ? round(($accum / $vCount)) : 0;

        $aText= $avgAccum= ($accum > 0) ? $avgAccum : "*";
        $descr= ($aText != "*") ? $this->getRatingDescr($avgAccum) : "N/A";
        $this->denseReputation .= $aText;

        $aryEntry[]= "&nbsp;&nbsp;". $this->helpAnchor($aText) . "&nbsp;";
        $aryEntry[]= $descr;
        $aryEntry[]= $vCount;
        $aryEntry[]= "Comments Received";
        return($aryEntry);
    }
    //  format the Direct gifts array entry
    function othersGiftsEntry() {
        $gAry=& $this->userGifts[0];
        $this->giftsReceived= $recvd= (isset($gAry["recvd_amt"])) ? $gAry["recvd_amt"]/100 : 0;
        $rAry= $this->getGiftRangeAndLevel($recvd);

        $this->denseReputation .= $rAry['level'];
        $range= ($rAry['range'] != "") ? $rAry['range'] : "&nbsp;";

        $aryEntry[]= "&nbsp;&nbsp;". $this->helpAnchor($rAry['level']) . "&nbsp;";
        $aryEntry[]= ($rAry['range'] != "") ? $rAry['range'] : "&nbsp;";
        $aryEntry[]= $gAry['recvd_count'];
        $aryEntry[]= "Gifts Inspired Totaling $" . $recvd;
        return($aryEntry);
    }
    //  format the Direct gifts array entry
    function othersCommentsEntry() {
        reset($this->userRatings);
        foreach($this->userRatings as $r) {
            $rAccum += $r['rating_value'];
        }
        $avgRating= round($rAccum/($rCount= count($this->userRatings)));

        $aText= ($avgRating > 0) ? $avgRating : "*";
        $descr= ($aText != "*") ? $this->getRatingDescr($avgRating) : "N/A";
        $this->denseReputation .= $aText;

        $aryEntry[]= "&nbsp;&nbsp;". $this->helpAnchor($aText) . "&nbsp;";
        $aryEntry[]= $descr;
        $aryEntry[]= $rCount;
        $aryEntry[]= "Total Comments Made";
        return($aryEntry);
    }
    //  construct an array containing those attributes which
    //  are to be dispalyed the reputation box.
    function buildReputationAry() {
        $this->dpyReputationAry[]= $this->patronageCommentsEntry();
        $this->dpyReputationAry[]= $this->directGiftsEntry();
        $this->dpyReputationAry[]= $this->volunteerCommentsEntry();
        $this->dpyReputationAry[]= $this->othersGiftsEntry ();
        $this->dpyReputationAry[]= $this->othersCommentsEntry();
    }
    //  get a list of active users who have rated this user
    function getRatingUsers() {
        $myRC= "OK";
        $uAry= array();
        $list= "";

        $ary=& $this->appliedRatings;
        for($i=0; $i < count($ary); $i++) {
            $n= trim($ary[$i]['rator_name']);
            if (!placeHolderUserName($n) && !in_array($n, $uAry)) {
                $this->ratersAry[$n]= $this->dbConnection->ratersInfo(($uAry[]= $n));
            }
        }
        return($myRC);
    }
    //  modify a sort order
    function modSortOrder($str, $col) {
        //  scm is a new major column sort.  construct a new sort
        //  order for comments array
        $sortAry= preg_split("/ /", $str);

        //  if the $scm argument is already the major sort then toggle the
        //  sort order otherwise make the $scm argument the major sort
        if (strstr($sortAry[0], $col)) {
            $sortAry[0][1]= ($sortAry[0][1] == "A") ? "D" : "A";

        } else {
            while(list($k, $v)= each($sortAry)) {
                if (strstr($v, $col)) {
                    $f= $v;
                } else {
                    $res[]= $v;
                }
            }
            $f= (isset($f)) ? "$f" : "{$col}A";
            array_unshift($res, $f);

            $sortAry= $res;
        }
        $str= "";
        while(list($k, $v)= each($sortAry)) {
            $str .= (strlen($str) == 0) ? "$v" : " $v";
        }
        return($str);
    }

    ////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////
    ////                                                           /////
    ////          O B J E C T    I N I T I A I Z A T I O N         /////
    ////                                                           /////
    ////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////
    function init($sess= NULL) {
        $myRC= "OK";
        $allowedArgs= array("u", "m", "tdf", "fcm", "lcm", "scm", "mfcm", "mlcm", "mscm");
        //  this url argument is sometimes user when testing new features
        //$allowedArgs[]= "test";

        if ($_SERVER['REQUEST_METHOD'] == 'GET'){
            $urlArgs= $_GET;

        } else if ($_SERVER['REQUEST_METHOD'] == 'POST'){
            $urlArgs= $_POST;

        } else {
            $myRC= "userHistory::init() Request is not GET or POST";
        }
        foreach($allowedArgs as $a) {
            if (isset($urlArgs["$a"])) {
                $$a= $urlArgs["$a"];
            }
        }

        ////////////////////////////////////////////////////////////////
        //             load some database shit                        //
        ////////////////////////////////////////////////////////////////
        //  check that the user id argument is valid and set the user
        //  property for this object and read the user row.
        if (isset($u)) {
            $this->userRow= $this->dbConnection->fetchUserAttrs($u);

        } else if (isset($m)) {
            $this->emailRow= $this->dbConnection->fetchAltEmailRow($m);
            if (!is_array($this->emailRow)) {
                $myRC= "userUistory::init() Unknown email address '$m'";

            } else if ($this->emailRow['amail_activep'] != 't') {
                $myRC= "userUistory::init() Email address '$m' is not active";

            } else {
                $this->userRow= $this->dbConnection->fetchUserAttrsAltEmail($m);
            }
        } else {
            $myRC= "userUistory::init() either \$u or \$m must be set.";
        }

        //  make sure that the user row was read withour error
        if ($myRC == "OK" && (!is_array($this->userRow) || count($this->userRow) == 0)) {
            $myRC= "userHistory::init() Couldn't fetch user row";
        }

        //  make sure that we are error free or get out
        if ($myRC != "OK") return($myRC);

        //  set the user property for this object.  make sure that the
        //  user is active.  read the client row.
        $this->user= $this->userRow['user_login'];
        if ($myRC == "OK" && $this->userRow['user_status'] != "activated") {
            //var_dump($this->userRow);
            $myRC= "userHistory::init() User \"{$this->user}\" is not active";
            $this->browserErrorDisplay= "User \"{$this->user}\" is not active";

        } else {
            $this->clientRow= $this->dbConnection->fetchClientAttrs($this->user);
        }

        if ($myRC == "OK" && (!is_array($this->clientRow) || count($this->clientRow) == 0)) {
            $myRC= "userHistory::init() Couldm't read database row for client \"{$this->user}\"";
        }

        ////////////////////////////////////////////////////////////////
        //               do the session thang                         //
        ////////////////////////////////////////////////////////////////
        //  make sure that we are error free or get out.
        if ($myRC != "OK") return($myRC);

        if ($sess == NULL) {
            return("userUistory::init() No session has been started.");
        }
        if (isset($scm) && !strstr("42", $scm)) {
            return("userUistory::init() scm sort order is not valid");
        }
        if (isset($mscm) && !strstr("42", $mscm)) {
            return("userUistory::init() mscm sort order is not valid");
        }
        if (isset($tdf) && !in_array($tdf, array("filter", "unfilter"))) {
            return("userUistory::init() toggle donor flag is not valid");
        }

        //  get saved session variables
        $this->session= $s= $sess;
        $sAry =& $this->sessionMapAry;
        $s->start($this->user);

        reset($sAry);
        foreach($sAry as $p) {
            $uhProperty= $p['uhProperty'];
            $urlKey= $p['urlKey'];
            $this->$uhProperty= $s->is_registered($urlKey) ? $s->sdata[$urlKey] : $this->$uhProperty;
        }

        $this->firstDpyComment= (isset($fcm) ? $fcm : $this->firstDpyComment);
        $this->lastDpyComment= (isset($lcm) ? $lcm : $this->lastDpyComment);
        $this->firstMadeDpyComment= (isset($mfcm) ? $mfcm : $this->firstMadeDpyComment);
        $this->lastMadeDpyComment= (isset($mlcm) ? $mlcm : $this->lastMadeDpyComment);
        $this->toggleDonorFilter= (isset($tdf) ? $tdf : $this->toggleDonorFilter);
        $this->featureTest= (isset($test) ? $test : $this->featureTest);

        if (isset($scm)) {
            $this->dpyCommentsSort= $this->modSortOrder($this->dpyCommentsSort, $scm);
        }
        if (isset($mscm)) {
            $this->dpyMadeCommentsSort= $this->modSortOrder($this->dpyMadeCommentsSort, $mscm);
        }

        //  save session  variables
        reset($sAry);
        foreach($sAry as $p) {
            $uhProperty= $p['uhProperty'];
            $urlKey= $p['urlKey'];
            $s->sdata[$urlKey]= $this->$uhProperty;
        }
        $s->save();

        ////////////////////////////////////////////////////////////////
        //                  display fields                            //
        ////////////////////////////////////////////////////////////////
        //  set up the id string for the browser title
        $this->browserTitleString= "AFFERO PROFILE: " . $this->user;

        //  filter donor status for comment display
        $fText= "all member comments";
        $ufText= "comments by member's who have made or recieved a gift";

        if ($this->toggleDonorFilter != "filter") {
            $fText= "<b>" . $fText . "</b>";
        } else {
            $ufText= "<b>" . $ufText . "</b>";
        }
        $this->giftFilterLink= $fLink= "<a href=\"http://{$this->server}/user-history.php?u={$this->user}&tdf=unfilter\">$fText</a>";
        $this->giftUnFilterLink= $ufLink= "<a href=\"http://{$this->server}/user-history.php?u={$this->user}&tdf=filter\">$ufText</a>";
        
        $this->filterBar= "<b>Reputation Filters:</b>&nbsp;&nbsp;" . $fLink . ", " . $ufLink ;
        //echo("<br><br>\$this->filterBar"); var_dump(htmlspecialchars($this->filterBar));

        //  set up an array of pay profiles and an array of anchor
        //  tags for Smarty to display in the "Giving Options" section
        $this->ppe->init($this->user);

        $mpa=& $this->ppe->activeProfileAry;
        for($i=0; $i < count($mpa); $i++) {
            if ($mpa[$i]['active']) {
                $name= $mpa[$i]['name'];
                $this->dpyGiftOptionsAry[]=
                     "<a href=\"http://{$this->server}/" .
                     "rm.php?r={$this->user}&p={$name}\">{$name}</a>";
            }
        }

        //  get all of the ratings which apply to this user
        if (($myRC= $this->getRatingsAppliedToUser()) != "OK") {
            return($myRC);
        }
        //  get all of the ratings made by this user
        if (($myRC= $this->getRatingsMadeByUser()) != "OK") {
            return($myRC);
        }

        ////////////////////////////////////////////////////////////////
        //  "gift info" is a count of gifts given and a count of gifts//
        //  received along with the sum of gifts given and the sum of //
        //  gifts received                                            //
        //------------------------------------------------------------//
        //  get gift info on the users who have rated this user       //
        if (($myRC= $this->getRatingUsers()) != "OK") {
            return($myRC);
        }
        //  get gift info related to this user
        $this->userGifts= $this->dbConnection->ratersInfo($this->user);

        // build the reputation array
        $this->buildReputationAry();

        //  set up the id string for the Bluebar
        $this->summaryBarString= "</b>" . $this->user;
        $this->summaryBarString.= "&nbsp;&nbsp;" . $this->helpAnchor($this->denseReputation) . "<b>";
        $this->summaryBarString.= "&nbsp;&nbsp;&nbsp;&nbsp;" . "Member Since:";
        $this->summaryBarString.= "&nbsp;&nbsp;";
        $this->summaryBarString.= "</b>" . strftime("%D", strtotime($this->stripUsecFromDTG($this->userRow['created']))) . "<b>";

        ////////////////////////////////////////////////////////////////
        //    build  arrays                                           //
        ////////////////////////////////////////////////////////////////
        $this->buildCommentsAry();
        $this->buildMadeCommentsAry();

        $this->mergeCommentsRids();
        $this->commentCount= $commentCount= count($this->dpyCommentsAry);

        $first= 1;
        $last = ($commentCount < $this->lastDpyComment) ? $commentCount : $this->lastDpyComment;

        $this->commentsBarString  = "";
        if ($commentCount > 0) {
            
            $this->commentsBarUser .= $this->user;
            $this->commentsBarCount .= "(1-" . $last . " of $commentCount)&nbsp;";
        } else {
            $this->commentsBarString  .= "No Comments Made on " . $this->user;
        }

        $this->dpyCommentsTitle= "";
        $this->dpyCommentsTitle.= "&nbsp;&nbsp;Comment Left By, Value, ";
        $this->dpyCommentsTitle.= "<a href=\"http://{$this->server}/user-history.php?u={$this->user}&scm=2\">Feedback Category</a>";
        $this->dpyCommentsTitle.= ", Gift Amount, ";
        $this->dpyCommentsTitle.= "<a href=\"http://{$this->server}/user-history.php?u={$this->user}&scm=4\">Date </a> ";
        $this->dpyCommentsTitle.= "<br>&nbsp;&nbsp;Comment Text";

        //  this link goes at the bottom of the comments table
        //  when only the first 10 comments are displayed.
        if ($last < $commentCount) {
            $allText= "view all $commentCount entries...";

        } else if ($commentCount > 10) {
            $allText= "Collapse";
        }

        $this->endOfComments = "";
        if ($commentCount > 10) {
            $this->endOfComments = "&nbsp;&nbsp;";
            $this->endOfComments .= ($this->lastDpyComment < $commentCount)
                 ? "<a href=\"http://{$this->server}/user-history.php?u={$this->user}&fcm=0&lcm=$commentCount\">$allText</a>"
                 : "<a href=\"http://{$this->server}/user-history.php?u={$this->user}&fcm=0&lcm=10\">&nbsp;&nbsp;Collapse...</a>";
        }

        ////////////////////////////////////////////////////////////////
        //     build an array of comments made by user                //
        ////////////////////////////////////////////////////////////////
        $this->mergeMadeCommentsRids();
        $this->commentMadeCount= $commentMadeCount= count($this->dpyMadeCommentsAry);
        $first= 1;
        $last = ($commentMadeCount < $this->lastMadeDpyComment) ? $commentMadeCount : $this->lastMadeDpyComment;

        $this->commentsMadeBarString = "" ;
        if ($commentMadeCount > 0) {
            $this->commentsMadeBarUser = $this->user;
            $this->commentsMadeBarCount = "(1-" . $last . " of $commentMadeCount)&nbsp;";

        } else {
            $this->commentsMadeBarString  .= "No Comments Made by " . $this->user;
        }

        $this->dpyMadeCommentsTitle= "";
        $this->dpyMadeCommentsTitle.= "&nbsp;&nbsp;Comment On, Value, ";
        $this->dpyMadeCommentsTitle.= "<a href=\"http://{$this->server}/user-history.php?u={$this->user}&mscm=2\">Feedback Category</a>";
        $this->dpyMadeCommentsTitle.= ", Gift Amount, ";
        $this->dpyMadeCommentsTitle.= "<a href=\"http://{$this->server}/user-history.php?u={$this->user}&mscm=4\">Date</a> ";
        $this->dpyMadeCommentsTitle.= "<br>&nbsp;&nbsp;Comment Text";

        //  this link goes at the bottom of the comments table
        //  when only the first 10 comments are displayed.
        if ($last < $commentMadeCount) {
            $allText= "view all $commentMadeCount entries...";

        } else if ($commentMadeCount > 10) {
            $allText= "Collapse";
        }

        $this->endOfMadeComments = "";
        if ($commentMadeCount > 10) {
            $this->endOfMadeComments = "&nbsp;&nbsp;";
            $this->endOfMadeComments .= ($this->lastMadeDpyComment < $commentMadeCount)
                 ? "<a href=\"http://{$this->server}/user-history.php?u={$this->user}&mfcm=0&mlcm=$commentMadeCount\">$allText</a>"
                 : "<a href=\"http://{$this->server}/user-history.php?u={$this->user}&mfcm=0&mlcm=10\">Collapse...</a>";
        }
        return($myRC);
    }
}
