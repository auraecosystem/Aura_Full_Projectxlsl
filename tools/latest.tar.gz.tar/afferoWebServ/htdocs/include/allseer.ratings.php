<?php
//  $Name: ORG-TEST $, $Id: allseer.ratings.php,v 1.105 2002/12/13 18:07:38 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  This is a class for validating rate me fields from a form.
////
//  TODO: move all of the SQL out of this object and in to the
//        the allseer.UserSQLConn.php boject
////////////////////////////////////////////////////////////////////////
require_once("allseer.variousFunctions.php");
require_once("allseer.profileObject.php");
require_once("allseer.UserSqlConn.php");
require_once("allseer.hasher.php");
require_once("allseer.smtpMailer.php");
require_once("allseer.nuts.php");

class rateMe
{
    ////////////////////////////////////////////////////////////////////
    function rateMe () {
        global $SERVER_NAME;
        $this->server= $SERVER_NAME;

        $this->validEmailRegex = "^[0-9a-z]([-_.]?[0-9a-z])*@[0-9a-z]([-.]?[0-9a-z])*\\.[a-wyz][a-z](g|l|m|pa|t|u|v)?$";
        $this->Value = FALSE;
        $this->Categorize = FALSE;
        $this->Comment = FALSE;
        $this->Login = FALSE;
        $this->LoginId = 0;
        $this->Password = FALSE;
        $this->Email = FALSE;
        $this->Tip = FALSE;
        $this->FromForm = FALSE;
        $this->Ratee = FALSE;
        $this->RateeEmail = "";
        $this->RatingOID = FALSE;
        $this->TipOID = FALSE;

        $this->ProfileObj= new profileObject();
        $this->dbConnection= new UserSqlConn();
        $this->mailer= new smtpMailer();
        $this->validationFlag = FALSE;

        $this->Ratings= $this->initRatingsAry();
        $this->NewExpertInserted= TRUE;

        $this->ClientUserRow = array();
        $this->ClientRow = array();
        $this->ExpertUserRow = array();
        $this->ExpertRow = array();
        $this->sMessage = "INIT";
        $this->Messages = array();
    }
    ////////////////////////////////////////////////////////////////////
    //  generate the ratings array.  maybe this should be in the
    //  database
    function initRatingsAry() {
        return($this->dbConnection->fetchRatingDescriptions());
    }
    ////////////////////////////////////////////////////////////////////
    //  retrieve a user row for this expert or, if no user record
    //  exists then create one.  returns false if no user record exists
    //  and none could b created.
    function retrieveExpertUserRow ($conn) {
        //syslog(LOG_ERR, "rateMe::retrieveExpertRow() DEBUG==> Enter retrieveExpertUserRow");
        $this->NewExpertInserted= FALSE;
        $myExpertCount = 0;

        if ($this->Ratee != "") {
            $mySQL = "Select * from as_user where user_login = '$this->Ratee';";
            $conn->executeQuery($mySQL);
            $myExpertCount = $conn->getNumRows();
        }

        if ($myExpertCount == 0 && $this->RateeEmail != "") {
            $mySQL =
                 "Select u.* from as_user u, as_alt_email a " .
                 "where a.amail_email = '$this->RateeEmail' " .
                 "and a.amail_uid = u.user_id;";

            $conn->executeQuery($mySQL);
            $myExpertCount = $conn->getNumRows();

            if ($myExpertCount == 0){

                $nuts= new nuts($conn);
                $skelArgs= array();

                $skelArgs['user_login']= $myUserLogin = "Fly." . $conn->anonUserSeq($conn);
                $skelArgs['user_fwd_email']= $this->RateeEmail;
                $skelArgs['user_passwd']= "";

                if ($nuts->userSkel($skelArgs)) {
                    $mySQL = "Select * from as_user where user_fwd_email = '$this->RateeEmail'";
                    $conn->executeQuery($mySQL);
                    $myExpertCount = $conn->getNumRows();
                    $this->NewExpertInserted = ($myExpertCount == 1);
                } else {
                    syslog(LOG_ERR, "ratings::retrieveExpertUserRow()");
                }

            }
        }
        //  now, if $myExpertCount is 1 then the relevant expert row is
        //  sitting the results array for $conn if $myExpertCount is anything
        //  other than 1 then some error has occurred
        if ($myExpertCount == 1){
            $this->ExpertUserRow = $locAry= $conn->fetchNextRow(0);
            $this->Ratee = trim($this->ExpertUserRow["user_login"]);
            $this->RateeEmail = trim($this->ExpertUserRow["user_fwd_email"]);
        }
        return($myExpertCount == 1);
    }
    ////////////////////////////////////////////////////////////////////
    //  retrieve a user row for this client or, if no user record
    //  exists then create one.  returns false if no user record exists
    //  and none could b created.
    function retrieveClientUserRow ($conn) {
        $myClientCount = 0;
        $this->NewClientInserted = FALSE;

        //echo("<br>user login is..."); var_dump($this->Login);

        if ($this->Login != "") {
            $mySQL = "Select * from as_user where user_login = '$this->Login';";
            $conn->executeQuery($mySQL);
            $myClientCount = $conn->getNumRows();

        } else if ($this->Email != "") {
            $conn->fetchUserAttrsAltEmail($this->Email);
            $myClientCount = $conn->getNumRows();
        }


        if ($myClientCount == 0 && $this->Email != "") {
            $nuts= new nuts($conn);
            $skelArgs= array();

            $skelArgs['user_login']= $myUserLogin = $this->Login= ("Flo." . $conn->anonUserSeq($conn));
            $skelArgs['user_fwd_email']= $this->Email;
            $skelArgs['user_passwd']= "";

            if ($nuts->userSkel($skelArgs)) {
                $mySQL = "Select * from as_user where user_fwd_email = '$this->Email';";
                $conn->executeQuery($mySQL);
                $myClientCount = $conn->getNumRows();
                $this->NewClientInserted = ($myClientCount == 1);
            } else {
                syslog(LOG_ERR, "ratings::retrieveClientUserRow()");
            }
        }
        //  now, if $myClientCount is 1 then the relevant client row is
        //  sitting the results array for $conn if $myClientCount is anything
        //  other than 1 then some error has occurred
        if ($myClientCount == 1){
            $this->ClientUserRow = $locAry= $conn->fetchNextRow(0);
            $this->Email = $this->ClientUserRow['user_fwd_email'];
            $this->Login = $this->ClientUserRow['user_login'];
            $this->LoginId = $this->ClientUserRow['user_id'];
            $this->ClientUserRow['user_last_prof']= "client";
            $conn->updateUserAttrs($locAry, $this->ClientUserRow);
        }
        return($myClientCount == 1);
    }
    ////////////////////////////////////////////////////////////////////
    //  Insert a rating in the database
    function insertRatingRow ($conn) {
        $myCatId = "";
        $myRc= FALSE;

        if (count($this->Competencies) > 0 && isset($this->Categorize)) {
            foreach($this->Competencies as $compRow) {
                if ($compRow["cmptcy_descr"] == $this->Categorize) {
                    $myCatId = $compRow["cmptcy_id"];
                    break;
                }
            }
        }

        //  list arguments
        $rArgs= array();
        $aaKeys= array("lh", "ls");

        while(list($key, $val)= each($aaKeys)) {
            if (isset($this->argAry[$val])) {
                $rArgs[$val]= $this->argAry[$val];
            }
        }

        $mlid= "";
        if (isset($this->argAry['ll'])) {
            if (is_array(($mlAry= $conn->mlistRow($this->argAry['ll'])))) {
                $mlid= $mlAry['mlist_id'];
            }
        }

        $rArgs['mlid']= $mlid;
        $rArgs['value']= $this->Value;
        $rArgs['comment']= $this->Comment;
        $rArgs['category']= $myCatId;
        $rArgs['raterEmail']= $this->Email;
        $rArgs['rateeEmail']= $this->RateeEmail;
        $myRc= $conn->insertRating($rArgs);

        if ($myRc) {
            $this->RatingOID = $conn->getLastOid();
        }
        return($myRc);
    }
    ////////////////////////////////////////////////////////////////////
    //  Insert a gratuity in the database                             //
    //................................................................//
    //  this sql should be moved in to the UserSqlConn object         //
    ////////////////////////////////////////////////////////////////////
    function insertTipRow ($conn, $ratingOid) {
        $myRc = TRUE;

        if ($this->Tip > 0) {
            $myTipInCents = $this->Tip * 100;
            $myPid = $this->ProfileObj->profileID;

            $mySQL =
                 "insert into as_tips " .
                 "    (tip_grantor, tip_recipient, tip_profile_id, tip_amt, tip_rating, created) " .

                 "    select " .
                 "        u1.user_id, u2.user_id, '$myPid', '0', r.rating_id, now() " .

                 "    from " .
                 "         as_user u1, " .
                 "         as_user u2, " .
                 "         as_ratings r " .

                 "    where " .
                 "        u1.user_fwd_email = '$this->Email' and " .
                 "        u2.user_fwd_email = '$this->RateeEmail' and " .
                 "        r.oid = '$ratingOid'";

            $myRc = $conn->executeQuery($mySQL);
            if ($myRc) {
                $this->TipOID = $conn->getLastOid();
            } else {
                $this->sMessage = "ratings::insertTipRow() Gratuity transaction barfed ==>" . $conn->getErrorMessage();
                syslog(LOG_ERR, $this->sMessage);
                //var_dump($mySQL);
            }
        }
        return($myRc);
    }
    ////////////////////////////////////////////////////////////////////
    //  return a boolean indicating whether or not this login
    //  alreeady exists in the database
    function loginExists() {
        $mySQL = "Select * from as_user where user_login = '$this->Login';";

        // Create a new DB connection.
        $conn =& $this->dbConnection;

        // Open the connection.
        $conn->openConnection();

        // Execute the query.
        $conn->executeQuery($mySQL);

        if (($myCount = $conn->getNumRows()) == 1) {
            $this->ClientUserRow = $conn->fetchNextRow(0);
        }

        $conn->closeConnection();

        return(!!$myCount);
    }
    ////////////////////////////////////////////////////////////////////
    //  return a boolean indicating whether or not this e-mail address
    //  alreeady exists in the database
    function userEmailExists() {
        // Create a new DB connection.
        $conn =& $this->dbConnection;
        $myRc= FALSE;

        // Open the connection.
        $conn->openConnection();
        $locEmailAry= $conn->fetchAltEmailRow($this->Email);
        $locUserArray= $conn->fetchUserAttrsAltEmail($this->Email);
        if (!is_array($locUserArray) && is_array($locEmailAry) && $locEmailAry['amail_activep'] != "t") {
             $myRc= !$conn->removeAltEmail($this->Email);

        } else if (is_array($locUserArray) || is_array($locEmailAry)){
            $myRc= TRUE;
        }
        $conn->closeConnection();
        return($myRc);
    }
    ////////////////////////////////////////////////////////////////////
    //  edit check all of the form fields.  There are two sections
    //  on the screen: the rating section and the identity section.
    //  each section is capable of handling a single error message
    //  at a time.
    function validateFields() {
        $this->Messages = array();
        $this->topMessages = array();
        $this->bottomMessages = array();
        ////////////////////////////////////////////////////////////////
        //                        T I P
        if (($testTip= $this->Tip= ((integer)($this->Tip * 100))/100)) {
            global $MINIMUM_TIP, $MAXIMUM_TIP;

            if (strspn($testTip, "0123456789.") != strlen($testTip)) {
                $this->topMessages[] = $this->Messages['Tip'] = "TIP AMMOUNT MUST BE A (DECIMAL) FIGURE IN US DOLLARS";
            } else if ($testTip < $MINIMUM_TIP) {
                $this->topMessages[] = $this->Messages['Tip'] =
                     "WE'RE SORRY BUT WE DO NOT ACCEPT DONATIONS OF LESS THAN \${$MINIMUM_TIP} AT THE PRESENT TIME";
            } else if ($testTip > $MAXIMUM_TIP) {
                $this->topMessages[] = $this->Messages['Tip'] =
                     "WE'RE SORRY BUT WE DO NOT ACCEPT DONATIONS OF MORE THAN \${$MAXIMUM_TIP} AT THE PRESENT TIME";
            }
        }
        ////////////////////////////////////////////////////////////////
        //                   I D E N T I T Y
        if (($this->Login != "" || $this->Password != "") && ($this->Email != "" )) {
            $this->bottomMessages[] = $this->Messages['identity'] =
                 "YOU CAN'T BE A NEW USER AND AN EXISTING USER AT THE SAME TIME";

        } else if ($this->Login != "" || $this->Password != "") {
            ////////////////////////////////////////////////////////////////
            //         L O G I N / P A S S W O R D
            if ($this->Login == "") {
                $this->bottomMessages[] = $this->Messages['Login'] = "A LOGIN IS REQUIRED";

            } elseif (!$this->loginExists()) {
                $this->bottomMessages[] = $this->Messages['Login'] = "INVALID (<i>Please note: Username and Password fields are case sensitive</i>)";

            } elseif ($this->Password == "") {
                $this->bottomMessages[] = $this->Messages['Password'] = "A PASSWORD IS REQUIRED";

            } else if (!$this->passwdCheck()) {
                $this->bottomMessages[] = $this->Messages['Password'] = "INVALID (<i>Please note: Username and Password fields are case sensitive</i>)";
        
            } else if ($this->Login == $this->ExpertUserRow['user_login']) {
                $this->bottomMessages[] = $this->Messages['Login'] = "YOU CANNOT RATE YOURSELF";
            }
            
        } else if ($this->Email != "") {
            ////////////////////////////////////////////////////////////////
            //                E M A I L
            if ($this->Email == "") {
                $this->bottomMessages[] = $this->Messages['Email'] = "AN EMAIL ADDRESS IS REQUIRED FOR NEW USERS";

            } elseif (!eregi($this->validEmailRegex, $this->Email))  {
                $this->bottomMessages[] = $this->Messages['Email'] = "THIS EMAIL ADDRESS IS NOT VALID";

            } elseif ($this->userEmailExists()) {
                $conn =& $this->dbConnection;
                $locUserAry= $conn->fetchUserAttrsAltEmail($this->Email);
                if (is_array($locUserAry)) {
                    if ($locUserAry['user_login'] == $this->ExpertUserRow['user_login']) {
                        $this->bottomMessages[] = $this->Messages['Email'] = "YOU CANNOT RATE YOURSELF";

                    } else if ($locUserAry['user_status'] != "needs-auth") {
                        $this->bottomMessages[] = $this->Messages['Email'] = "THIS EMAIL ADDRESS IS NOT AVAILABLE";
                    }
                }

            } else if (!isset($this->Ratee) || $this->Ratee == "") {
                if (isset($this->Email) && isset($this->RateeEmail) && $this->Email == $this->RateeEmail) {
                    $this->bottomMessages[] = $this->Messages['Email'] = "YOU CANNOT RATE YOURSELF";
                }
            }
        } else {
            $this->bottomMessages[] = $this->Messages['identity'] =
                 "YOU MUST ENTER A LOGIN / PASSWORD COMBINATION OR, FOR NEW USERS, AN EMAIL ADDRESS";
        }
        $this->validationFlag = !count($this->Messages);
        return($this->validated());
    }

    ////////////////////////////////////////////////////////////////////
    function validated(){
        return($this->validationFlag);
    }

    function doRatingTrans($conn) {
        ////////////////////////////////////////////////////////////////
        //  everything after this is a database transaction.  The
        //  variable $myTransState is it's state variable.
        ////
        $myTransState = "continue";
        $myRc = FALSE;  //  TRUE only if the transaction succeeds

        //  start the transaction
        if (!$conn->executeQuery("begin work;")) {
            $myTransState = "exit";
            $this->sqlMessage = "rateMe::doRatingTrans: close site 1==>" . $conn->getErrorMessage();
            syslog(LOG_ERR, $this->sqlMessage);
        }
        //  continue... insert a rating
        if ($myTransState == "continue" && !$this->insertRatingRow($conn)) {
            $myTransState = "rollback";
            $myMessage = "rateMe::doRatingTrans: rating insert failure" . $conn->getErrorMessage();
            syslog(LOG_ERR, $myMessage);
        }
        //  continue... insert a tip
        if ($myTransState == "continue" && !$this->insertTipRow($conn, $this->RatingOID)) {
            $myTransState = "rollback";
            $sqlMessage = "rateMe::doRatingTrans: tip insert failure" . $conn->getErrorMessage();
            syslog(LOG_ERR, $this->sqlMessage);
        }
        //  end of transaction.  commit or rollback.
        if ($myTransState == "continue") {
            if ($conn->executeQuery("commit work;")) {
                $myTransState = "exit";
                $myRc = TRUE;

            } else {
                $myTransState = "rollback";
                $sqlMessage = "rateMe::doRatingTrans: transaction commit failure" . $conn->getErrorMessage();
                syslog(LOG_ERR, $this->sqlMessage);
            }
        }
        if ($myTransState == "rollback") {
            syslog(LOG_ERR, "rateMe::doRatingTrans: Transaction failure.  Rolling back");
            $conn->executeQuery("rollback");
            $myTransState = "exit";
        }
        return($myRc);
    }
    ////////////////////////////////////////////////////////////////////////
    //  functionality related to the expert table
    function retrieveExpertTableRow(){
        $conn =& $this->dbConnection;

        if (count($this->ExpertRow) == 0) {
            $this->ExpertRow= $conn->fetchExpertAttrs($this->Ratee);
        }
        return(count($this->ExpertRow) != 0);
    }
    ////////////////////////////////////////////////////////////////////////
    //  functionality related to email flags
    function expertWantsRatingEmail() {
        $myRc= FALSE;

        if ($this->retrieveExpertTableRow()) {
            $myRc= !strcmp($this->ExpertRow['expert_rate_notify'], "t");
        }
        return($myRc);
    }
    function expertWantsTipEmail() {
        $myRc= FALSE;
        if ($this->retrieveExpertTableRow()) {
            $myRc= !strcmp($this->ExpertRow['expert_tip_notify'], "t");
        }
        return($myRc);
    }
    function expertWantsRatingAndTipEmail() {
        $myRc= FALSE;
        if ($this->retrieveExpertTableRow()) {
            $myRc=
                 !strcmp($this->ExpertRow['expert_tip_notify'], "t") &&
                 !strcmp($this->ExpertRow['expert_rate_notify'], "t");
        }
        return($myRc);
    }
    ////////////////////////////////////////////////////////////////////
    //  all fields on a ratings screen have been validated.  do the
    //  requisite database updates.
    function dbInsert() {
        $conn =& $this->dbConnection;
        $conn->openConnection();
        $myRC = FALSE;

        if (!$this->retrieveClientUserRow($conn)) {
            $this->sMessage = "ratings::dbInsert() DBI couldn't read client data";
            syslog(LOG_ERR, $this->sMessage);

        } else if (!$this->retrieveExpertUserRow($conn)){
            $this->sMessage = "ratings::dbInsert() DBI couldn't read expert data <<" . $conn->getErrorMessage() . ">>";
            syslog(LOG_ERR, $this->sMessage);

        } else if (!$this->doRatingTrans($conn)){
            $this->sMessage = "ratings::dbInsert() DBI couldn't do rating transaction";
            syslog(LOG_ERR, $this->sMessage);

        } else {
            $myRC = TRUE;
        }
        $conn->closeConnection();
        return($myRC);
    }
    
    //  return a boolean indicating whether or not a client 
    //  is active
    function existingClient() {
        $rc= (trim($this->ClientUserRow['user_status']) == "activated");
        return($rc);
    }
    //  return a boolean indicating whether or not a client 
    //  is new
    function newClient() {
        $rc= (trim($this->ClientUserRow['user_status']) == "needs-auth");
        return($rc);
    }
    //  return a boolean indicating whether or not a client 
    //  should send a rating email
    function is_ratingClient() {
        $rc= ($this->existingClient() || $this->newClient());
        return($rc);
    }

    //  under certain conditions, email will be sent to the expert
    //  who has been rated on this screen or to the client who
    //  has performed the rating
    function emailNotify() {
        $myMailer =& $this->mailer;

        $expertArgAry['addy']= trim($this->RateeEmail);
        $expertArgAry['login']= trim($this->Ratee);
        $expertArgAry['client']= trim($this->Login);
        $expertArgAry['client-id']= $this->LoginId;
        $expertArgAry['client-addy']= trim($this->Email);
        $expertArgAry['ratingOID']= trim($this->RatingOID);
        $expertArgAry['comments']= $this->Comment;
        $expertArgAry['profileAry']= $this->ProfileObj->profileAry;

        foreach($this->Ratings as $r){
            if ($r['rating_val'] == $this->Value) {
                $expertArgAry['rating']= $r['rating_descr'];
                break;
            }
        }
        if (isset($this->argAry['ll'])) {
            $expertArgAry['listName']= $this->argAry['ll'];
        }
        if (isset($this->argAry['ls'])) {
            $expertArgAry['listSubject']= $this->argAry['ls'];
        }
        $expertArgAry['tip']= $this->Tip;

        ////////////////////////////////////////////////////////////////
        //                   E X P E R T
        //  this is some pretty nasty code.  I apologize --lee
        $extEmail = array();
        $haveList= (isset($expertArgAry['listName']) && $expertArgAry['listName'] != "");

        if ($this->NewExpertInserted && ($this->Tip != 0)) {
            //  there's a tip. email will be sent from the secure server
            $extEmail['func']= ($haveList) ? "newVolunteerA4" : "newVolunteerA6";

        } else if (($this->Tip != 0) && $this->expertWantsTipEmail()) {
            //  there's a tip. email will be sent from the secure server
            $extEmail['func']= ($haveList) ? "volunteerGiftAndRatingListG2" : "volunteerGiftAndRatingG1";

        } else if ($this->expertWantsRatingEmail() && $this->is_ratingClient()) {
            if ($haveList) {
                if (!$myMailer->volunteerRatingR3($expertArgAry)) {
                    $this->sMessage = "rateMe::Finalize() Couldn't notify volunteer from list";
                    syslog(LOG_ERR, $this->sMessage);
                }

            } else if (!$myMailer->volunteerRatingR2($expertArgAry)) {
                $this->sMessage = "rateMe::Finalize() Couldn't notify volunteer.  No list";
                syslog(LOG_ERR, $this->sMessage);
            }
        }
        ////////////////////////////////////////////////////////////////
        //                   C L I E N T
        if (!$this->existingClient()) {
            $mailArgs= array();
            $mailArgs['patron_addy']= trim($this->Email);
            $mailArgs['voluntr_addy']= trim($this->RateeEmail);
            $mailArgs['voluntr_login']= trim($this->Ratee);
            if (!$myMailer->newPatronA3($mailArgs)) {
                $this->sMessage = "rateMe::Finalize() Couldn't notify new client";
                syslog(LOG_ERR, $this->sMessage);
            }
        }
        if ($this->clientWantsGiftEmail()) {
            $extEmail['giftEmail']= "true";
        }

        //  now, if the extEmail array is non empty then it's func
        //  entry contains the name of a function which will be called
        //  from the secure site after a credit card authorization has
        //  passed.  so bundle up the email arguments and pass them
        //  along on the URL //echo("<br>\$extEmail...");
        //  var_dump($extEmail);
        if (count($extEmail) > 0) {
            global $HTTP_SERVER_VARS;

            $extEmail['args']= $expertArgAry;
            $extEmail['host']= $HTTP_SERVER_VARS['HTTP_HOST'];
            $this->extEmail= serialize($extEmail);
        }
        //echo("<br>\$extEmail..."); var_dump($extEmail);

    }

    ////////////////////////////////////////////////////////////////////
    //  check if an email needs to be sent to the client for this
    //  gift
    function clientWantsGiftEmail() {
        $myRc= FALSE;

        if (count($this->ClientRow) == 0) {
            $this->ClientRow= $this->dbConnection->fetchClientAttrs($this->Login);
        }

        if (is_array($this->ClientRow) && count($this->ClientRow) > 0) {
            $myRc= ($this->ClientRow['client_gift_notify'] == "t");
        }

        //echo("<br>\$this->Logi..."); var_dump($this->Login);
        //echo("<br>\$this->ClientRow..."); var_dump($this->ClientRow);

        return($myRc);
    }

    ////////////////////////////////////////////////////////////////////
    //  Call this after all form fields have been validated
    function Finalize() {
        //echo("<br>Finalize() entry");
        $myRc= TRUE;

        if (!$this->validationFlag) {
            $myRc= FALSE;
            $this->sMessage = "rateMe::Finalize() called with validationFlag == FALSE";
            syslog(LOG_ERR, $this->sMessage);

        } else {
            $this->validationFlag= FALSE;
            if ($myRc= $this->dbInsert()) {
                $this->emailNotify();

            } else {
                $this->sMessage = "rateMe::Finalize() dbInsert() failure";
                syslog(LOG_ERR, $this->sMessage);
            }
        }
        return($myRc);
    }
    ////////////////////////////////////////////////////////////////////
    //  make sure that the password is correct for this login_id
    function passwdCheck() {
        $h= new hasher;

        $conn=& $this->dbConnection;
        $myRc= $conn->passwordMatch($this->Login, $h->passwordMunge($this->Password));
        return($myRc);
    }

    //  check for valid incomming arguments on a get
    function valid_GetArgs() {
        global $m, $r;

        $myRc= TRUE;
        //  neither of $r and $m set: error
        if (!isset($r) && !isset($m)) {
            echo("<br>neither set");
            $myRc= FALSE;
        }
        //  both of $r and $m set: error
        if ($myRc && isset($r) && isset($m)) {
            echo("<br>both set");
            $myRc= FALSE;
        }
        //if $m is set, it must be a  valid email address
        if ($myRc && isset($m) ){
            include ("allseer.validator.php");
            $v= new asValidator();
            if (!$myRc= $v->is_validEmail($m)) {
                //echo("<br>{$v->ERROR}");
            }
        }
        return($myRc);
    }

    ////////////////////////////////////////////////////////////////////
    function init () {
        global $REQUEST_METHOD, $aa;

        $conn =& $this->dbConnection;
        $myRc= TRUE;
        $myMsg= "OK";

        if ($aa){
            $this->argAry= unserialize(urldecode($aa));
            //echo("<br>argAry (site 1)..."); var_dump($this->argAry);

        } else {
            $this->argAry['ll']= isset($GLOBALS['ll']) ? $GLOBALS['ll'] : "";
            $this->argAry['ls']= isset($GLOBALS['ls']) ? $GLOBALS['ls'] : "";
            $this->argAry['lh']= isset($GLOBALS['lh']) ? $GLOBALS['lh'] : "";
            $this->argAry['lp']= isset($GLOBALS['lp']) ? $GLOBALS['lp'] : "";
            $this->argAry['r']= isset($GLOBALS['r']) ? $GLOBALS['r'] : "";
            $this->argAry['m']= isset($GLOBALS['m']) ? $GLOBALS['m'] : "";
            $this->argAry['p']= isset($GLOBALS['p']) ? $GLOBALS['p'] : "";
            //echo("<br>argAry (site 2)..."); var_dump($this->argAry);
        }
        //  serialize and URL encode for forms loopback
        $this->serializedEncodedArgAry= urlencode(serialize($this->argAry));

        while (list($var, $value) = each($this->argAry)) {
            $$var= $value;
        }

        //  If this object was instantiated from an HTTP GET
        //  then check to make sure thet the user is valid and that
        //  the e-mail address is correct and all of that shit.
        $locUserAry= FALSE;
        if ($REQUEST_METHOD == "GET") {
            if (!$this->valid_GetArgs()) {
                $myMsg= "<br>Rating arguments are incorrect.<br><br>Check your email address.";
            }

            if ($myMsg == "OK" && $r != "") {
                if (!$conn->loginExists($r)) {
                    $myMsg= "ratings::init() URL 'r' argument is not a valid user";

                } else {
                    $locUserAry= $conn->fetchUserAttrs($r);
                    if (count($locUserAry) != 0) {
                        $m= $locUserAry['user_fwd_email'];

                    } else {
                        $r= "";
                    }
                }
            }

            if ($myMsg == "OK" && $r == "" && $m != "") {
                $locEmailAry= $conn->fetchAltEmailRow($m);
                $locUserAry= $conn->fetchUserAttrsAltEmail($m);
                if (!is_array($locUserAry) && is_array($locEmailAry) && $locEmailAry['amail_activep'] != "t") {
                    $conn->removeAltEmail($m);

                } else {
                    $locUserAry= $conn->fetchUserAttrsAltEmail($m);
                    if (is_array($locUserAry) && count($locUserAry) != 0) {
                        $r= $locUserAry['user_login'];
                    }
                }
            }
        }

        //  fetch user database row
        if (!$locUserAry && isset($r)) {
            $locUserAry= $conn->fetchUserAttrs($r);
        }
        if (!$locUserAry && isset($m)) {
            $locUserAry= $conn->fetchUserAttrsAltEmail($m);
        }
        //  set the expert user row object property
        if (is_array($locUserAry)) {
            $this->ExpertUserRow= $locUserAry;
            $r= $this->ExpertUserRow['user_login'];
            $m= (isset($m) && !strlen($m)) ? $m : $this->ExpertUserRow['user_fwd_email'];

        }

        //  if list arguments are set then process them here
        if ($myMsg ==  "OK" && isset($ll)) {
            $lAry['mlist']= $conn->mlistRow($ll);
            $lAry['expert']= $conn->mlistAdmin($ll);
            $lAry['user']= $conn->mlistUser($ll);
        }

        //  at least one of ratee and email must be set
         if ($myMsg ==  "OK") {
             if (!($r == "" && $m == "")) {
                 $this->Ratee = trim($r);
                 $this->RateeEmail = trim($m);

                 //  get the right user / profile
                 $profile= "notSet";

                  //echo("<br> profile sel 1 \$profile= $profile, \$user= $user");
                 if (is_array($this->ExpertUserRow)
                     && count($this->ExpertUserRow)>0
                     && $this->ExpertUserRow['user_status'] == "activated") {

                     $user= $this->ExpertUserRow['user_login'];
                     $profile= (isset($p) && $p != "") ? $p : $profile;
                     if ($profile == "notSet") {
                         $dpAry= $conn->fetchUserDefaultPayProfile($this->ExpertUserRow['user_login']);
                         if (is_array($dpAry) && count($dpAry) > 0) {
                             $profile= $dpAry[0]['name'];
                         }
                     }
                 }

                 //echo("<br> profile sel 2 \$profile= $profile, \$user= $user");
                 if (($profile == "notSet")  && isset($lp) && is_array($lAry['user'])) {
                     $profile= $lp;
                     $user= $lAry['user']['user_login'];
                 }

                 //echo("<br> profile sel 3 \$profile= $profile, \$user= $user");
                 if ($profile == "notSet") {
                     $user= "allseer//";
                     $profile= isset($p) ? $p : "default";
                 }

                 //echo("<br> profile sel 4 \$profile= $profile, \$user= $user");
                 $this->ProfileObj->setProfileName($profile);
                 $this->ProfileObj->setUserLogin($user);
                 if ($myRc= $this->ProfileObj->setProfileID()) {
                     $this->ProfileObj->consProfileAry();
                 }
                 $this->ProfileObj->setDpyProppa();

             } else {
                 $myMsg= "ratings::init() Bad URL arguments.  Either 'r' or 'm' must be present";
             }
         }

         //  set up the competncies array.  if there's omne associated with this
         //  mailing list then use it otherwise load the default array of all
         //  competencies
         if ($myMsg == "OK") {
             $localComps= (isset($ll)) ? $conn->loadMlistComps($ll) : array();
             $this->Competencies= array();
             for ($i=0, $n=count($localComps); $i < $n; $i++) {
                 if (!isset($localComps[$i]['cmptcy_active']) || $localComps[$i]['cmptcy_active'] == "t"){
                     $this->Competencies[]= $localComps[$i];
                 }
             }
         }

         // set the text which will appear on the first bluebar on the page.
         if ($this->Ratee && $this->Ratee != "" && !placeHolderUserName($this->Ratee)) {
             $this->BarString=
                  "<a href=\"http://{$this->server}/user-history.php?u=" .
                  $this->Ratee . "\">" . $this->Ratee . "</a>&nbsp;";
         } else {
             $this->BarString= $this->RateeEmail;
         }

         // set the text which will appear as the propaganda writer
         if (($dpw= $this->ProfileObj->displayProppaWriter) == "allseer//") {
             $this->proppaWriter= "Affero";

         } else {
             $this->proppaWriter= "<a href=\"http://{$this->server}/user-history.php?u=$dpw\">$dpw</a>";
         }
         return($myMsg);
    }
}
?>
