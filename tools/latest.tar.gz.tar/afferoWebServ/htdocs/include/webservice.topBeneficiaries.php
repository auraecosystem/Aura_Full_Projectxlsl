<?php
//  $Name: ORG-TEST $, $Id: webservice.topBeneficiaries.php,v 1.7 2002/12/02 22:17:36 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  This is a class for validating rate me fields from a form.
////
//  TODO: move all of the SQL out of this object and in to the
//        the allseer.UserSQLConn.php boject
////////////////////////////////////////////////////////////////////////
require_once("allseer.UserSqlConn.php");
require_once("webservice.topUserHOFArgs.php");
require_once("allseer.variousFunctions.php");

class topBeneficiaries
{
    ////////////////////////////////////////////////////////////////////
    ////    CONSRUCTOR      ////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////
    function  topBeneficiaries() {
        global $historyHost;

        $this->objectStatus= "OK";
        $this->dbConnection= new UserSqlConn();
        $this->historyHost= $GLOBALS['historyHost'];
        $this->hofArgs= new topUserHOFArgs();

        //  default values for URL arguments
        $this->type= $this->hofArgs->type;   
        $this->limit= $this->hofArgs->limit;                  
        $this->dpyDateRange= date("n/j",  strtotime("today"));
        
        ////////////////////////////////////////////////////////////////
        //  get an array of the most heavily accessed beneficiaries
        if ($this->hofArgs->bennContents == "patron" || $this->hofArgs->bennContents == "volunteer") {
            $ary= $this->dbConnection->readMemberBeneficiaryHOF($this->hofArgs->fromDate,
                                                                $this->hofArgs->toDate,
                                                                $this->hofArgs->bennContents,
                                                                $this->hofArgs->bUser['user_login'],
                                                                $this->hofArgs->foundationIds);
            if ($this->hofArgs->bennContents == "volunteer") {
                $this->tableTitle1= "Gifts Inspired by";
            } else {
                $this->tableTitle1= "Gifts Made by";
            }
            
            $u= $this->tableTitleName= $this->hofArgs->bUser['user_login'];
            $this->tableTitleLink= "http://{$historyHost}/user-history.php?u=$u";
            
            $this->tableTitle2= "<a href=\"" .$this->tableTitleLink. "\">$u</a>";
            $this->colHeading= "Amt";
            
        } else {
            $ary= $this->dbConnection->readBeneficiaryHOF();
        }
        //var_dump($ary);
        $this->benniesAry= array_slice($ary, 0, $this->limit);
        array_walk($this->benniesAry, array($this, "nameCutter"));
        reset($this->benniesAry);
        $this->tableTitle= "Top " . (($t= count($this->benniesAry)) == 0 ?  "" : "$t") . " Beneficiaries";
    }
    //  truncate foundation names
    function nameCutter(&$fline, $key) {
        $len= $this->hofArgs->orgLen;
        
        $fline['name']= $f= sprintf("%-{$len}.{$len}s", $fline['name']);
    }    
}

?>
