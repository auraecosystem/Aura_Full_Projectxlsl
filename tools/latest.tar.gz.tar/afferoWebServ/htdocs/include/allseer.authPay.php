<?php
//  $Name: ORG-TEST $, $Id: allseer.authPay.php,v 1.5 2002/11/25 17:50:49 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//
include_once("allseer.UserSqlConn.php");

class authPay
{
    function authPay() {
    }

    function init() {
    }

    //  this method updates the allseer database after a trust commerce
    //  transaction.
    //
    //  many things are passed in the value array, including a string
    //  of connection arguments.  The array is serialized and stuffed
    //  into the database.
    //
    //  this method returns a string "OK" for success otherwise a log
    //  message indicating the reason for failure.
    function dbUpdate($valueAry) {
        //system("echo \"authPay::dbUpdate Entry\" >> logdir/DEBUG$dat");
        $myRC = "OK";
        $vr=& $valueAry;
        
        $conn = new UserSqlConn();
        if (isset($vr['connectArgs']) && $conn->openConnection($vr['connectArgs'])) {
            if (!$conn->insertTCX($vr)) {
                $myRC= "authPay: insertTCX() failed";
            }
            
            $c= count($vr['serialProfAry']);
            for($i=0; $i<$c; $i++) {
                $conn->insertBPCT($vr, $vr['serialProfAry'][$i]['fid'], $vr['serialProfAry'][$i]['pct']);
            }

            $conn->closeConnection();
            
        } else {
            $myRC= "authPay: could not open a database connection";
        }
        return($myRC);
    }
}
