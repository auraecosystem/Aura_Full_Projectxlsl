<?php
//  $Name: ORG-TEST $, $Id: allseer.arrayLoader.php,v 1.15 2002/12/13 20:07:34 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  this class loads array definitions from require files if they     //
//  exist.  if tthey do not exist, then they are built and stored in  //
//  $DOCUMENT_ROOT/include/data/<name>.php                            //
////////////////////////////////////////////////////////////////////////
require_once("allseer.arrayBuilder.php");
require_once("externClasses/filecacheclass.php");

class arrayLoader
{
    var $builder;

    //  constructor
    function arrayLoader() {
        $this->builder= new arrayBuilder();
    }
////////////////////////////////////////////////////////////////////////
//                 L O C A L     F U N C T I O N S                    //
////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////
    function buildLanguageArray() {
        require_once("languageArray.php");
        return($LANGUAGES);
    }
    ////////////////////////////////////////////////////////////////////
    function buildCountryArray() {
        require_once("countryArray.php");
        return($COUNTRIES);
    }
    ////////////////////////////////////////////////////////////////////
    function buildUsStatesArray() {
        require_once("usStatesArray.php");
        return($US_STATES);
    }
    ////////////////////////////////////////////////////////////////////
    function foundCompare($a, $b) {
        return(strcmp($a["name"], $b["name"]));
    }
    
    function buildFoundationsArray() {
        $ary= $this->builder->buildFoundations();
        $first= array_shift($ary);
        
        usort($ary, array($this, "foundCompare"));
        array_unshift($ary, $first);
        return($ary);
    }
    ////////////////////////////////////////////////////////////////////
    function buildFormCompetencyArray() {
        return($this->builder->buildFormCompetencyArray());
    }
    ////////////////////////////////////////////////////////////////////
    function buildLongCompetencyArray() {
        return($this->builder->buildLongCompetencyArray());
    }
    ////////////////////////////////////////////////////////////////////
    function buildExpertHOF() {
        return($this->builder->buildExpertHOF($this->hofTime));
    }
    ////////////////////////////////////////////////////////////////////
    function buildClientHOF() {
        return($this->builder->buildClientHOF($this->hofTime));
    }
    ////////////////////////////////////////////////////////////////////
    function buildWeeksBeneficiariesHOF() {
        return($this->builder->buildWeeksBeneficiariesHOF());
    }
    
    ////////////////////////////////////////////////////////////////////
    function cacheingLoader($file, $builder, $exp) {
        global $DOCUMENT_ROOT;
        $myCache= new file_cache_class;
        $myCache->path="$DOCUMENT_ROOT/include/data/$file";
        if ($myResults= $myCache->verifycache($cached)) {
            if ($cached) {
                $myCache->reopenupdatedcache= 1;
                for ($last=0;!$last;) {
                    $myResults= $myCache->retrievefromcache($loopData, $last);
                }
                if ($myResults) {
                    $myArray= unserialize($loopData);
                    $myResults= TRUE;

                }
             } else {
                 
                if ($myArray= $myResults= $this->$builder()) {
                    $myCache->setexpirytime($exp);
                    $mySerializedArray= serialize($myArray);
                    $myCache->storedata($mySerializedArray, 1);
                }
            }
        }
        return($myResults ? $myArray : FALSE);
    }

////////////////////////////////////////////////////////////////////////
//              I N T E R F A C E    F U N C T I O N S                //
////////////////////////////////////////////////////////////////////////
    function loadLanguageArray() {
        return($this->cacheingLoader("generatedLangArray.php", "buildLanguageArray", 60*60*24));
    }
    ////////////////////////////////////////////////////////////////////
    function loadCountryArray() {
        return($this->cacheingLoader("generatedCountryArray.php", "buildCountryArray", 60*60*24));
    }
    ////////////////////////////////////////////////////////////////////
    function loadUsStatesArray() {
        return($this->cacheingLoader("generatedUsStatesArray.php", "buildUsStatesArray", 60*60*24));
    }
    ////////////////////////////////////////////////////////////////////
    function loadFoundations() {
        return($this->cacheingLoader("generatedFoundationsC.php", "buildFoundationsArray", 60*15));
    }
    ////////////////////////////////////////////////////////////////////
    function loadExpertFormCompArray() {
        return($this->cacheingLoader("generatedExpertFormCompArrayC.php", "buildFormCompetencyArray", 60*15));
    }
    ////////////////////////////////////////////////////////////////////
    function loadCompArray() {
        return($this->cacheingLoader("generatedLongCompArrayC.php", "buildLongCompetencyArray", 60*15));
    }
    ////////////////////////////////////////////////////////////////////
    function loadExpertHOF($tm) {
        global $DOCUMENT_ROOT;
        $tm= "yr";
        
        $myResults = FALSE;
        if ($tm == "wk" || $tm == "yr") {
            $file = "generated" . (($tm == "wk") ? "Weeks" : "Years") . "ExpertHOFC.php";
            $this->hofTime= $tm;
            $myResults= $this->cacheingLoader($file, "buildExpertHOF", 60*15);
        }
        return($myResults);
    }
    ////////////////////////////////////////////////////////////////////
    //  load a client hall of fame
    function loadClientHOF($tm) {
        global $DOCUMENT_ROOT;
        $tm= "yr";
        
        $myResults = FALSE;
        if ($tm == "wk" || $tm == "yr") {
            $file = "generated" . (($tm == "wk") ? "Weeks" : "Years") . "ClientHOFC.php";
            $this->hofTime= $tm;
            $myResults= $this->cacheingLoader($file, "buildClientHOF", 60*15);
        }
        return($myResults);
    }
    ////////////////////////////////////////////////////////////////////
    //  load this week's beneficiaries Hall Of Fame
    function loadWeeksBeneficiariesHOF() {
        return($this->cacheingLoader("generatedWeeksBeneficiariesHOFC.php", "buildWeeksBeneficiariesHOF", 60*15));
    }
}

?>
