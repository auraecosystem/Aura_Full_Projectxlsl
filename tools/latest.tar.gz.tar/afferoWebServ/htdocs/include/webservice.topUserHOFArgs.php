<?php
//  $Name: ORG-TEST $, $Id: webservice.topUserHOFArgs.php,v 1.10 2002/12/12 21:00:44 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  This is a class for validating rate me fields from a form.
////
//  TODO: move all of the SQL out of this object and in to the
//        the allseer.UserSQLConn.php boject
////////////////////////////////////////////////////////////////////////
require_once("allseer.UserSqlConn.php");
require_once("allseer.variousFunctions.php");


//  this is a drop in replacement for fnmatch() which, at the time of
//  this writing, is only available in the development version of
//  php.
function myFnmatch($pattern, $string)
{
    // replace every occurrence of "*" with ".*" and do a preg_match.
    $myPattern= ($t= preg_replace("/\*/", ".*", $pattern)) == NULL ? $pattern : $t;
    $myRc= (preg_match("/$myPattern/", $string) > 0);
    return($myRc);
}

class topUserHOFArgs
{
    ////////////////////////////////////////////////////////////////////
    ////    CONSRUCTOR      ////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////
    function  topUserHOFArgs() {
        $this->objectStatus= "OK";
        $this->dbConnection=& new UserSqlConn();
        $this->legalTypes= array("html", "xml");
        $this->legalTcArgs= array("values", "count", "donations");
        $this->legalRfArgs= array("text", "all");
        $this->bennContents= "foundations";
        
        //  default values for URL arguments
        $this->lists= array();
        $this->foundationIds= array();
        $this->type="html";
        $this->rFilter= "all";
        $this->orgLen=  10;
        $this->tableContents= "donations";
        $this->fromDate= strtotime("2 months ago");
        $this->toDate= strtotime("today");
        $this->limit= 10;

        if ($_SERVER['REQUEST_METHOD'] == 'GET'){
            $urlArgs= $_GET;
            //var_dump($urlArgs);
            
            if (($this->is_patronHOF() || $this->is_volunteerHOF()) && isset($urlArgs['la'])) {
                //  la argument is only used by patron and volunteer
                //  tables.  Really this should be in a derived object
                $afferoLists= $this->dbConnection->mlistAll();
                $this->mailingListNames= array();

                while (list($key, $val) = each($afferoLists)) {
                    $this->mailingListNames[]= rtrim($val['mlist_name']);
                }

                //  weed out any members of the arg list which are not
                //  in the database and do globbing
                $largs= explode(",", $urlArgs['la']);
                foreach($largs as $larg) {
                    foreach($this->mailingListNames as $name) {
                        if (myFnmatch($larg, $name)) {
                            $this->lists[]= $name;
                        }
                    }
                }
                $this->lists= array_unique($this->lists);
                //  this list name will never be matched.  if it is the only
                //  array element thena nd empty table will be
                //  generated.
                $this->lists[]= "NOSUCHGODDAMNEDLIST NAME";
            }
            
            //  beneficiary hof can accept vu= for volunteer user
            if (($this->is_beneficiaryHOF()) && isset($urlArgs['vu'])) {
                $this->bUser= $row= $this->dbConnection->fetchUserAttrs($urlArgs['vu']);
                if (!$row || count($row) == 0) {
                    unset($this->bUser);
                } else {
                    $this->bennContents= "volunteer";
                }
            }
            //  beneficiary hof can accept pu= for patron user
            if (($this->is_beneficiaryHOF()) && !isset($this->bUser) && isset($urlArgs['pu'])) {
                $this->bUser= $row= $this->dbConnection->fetchUserAttrs($urlArgs['pu']);
                if (!$row || count($row) == 0) {
                    unset($this->bUser);
                } else {
                    $this->bennContents= "patron";
                }
            }

            //  beneficiary hof can accept olen= org string length
            if (($this->is_beneficiaryHOF()) && isset($urlArgs['olen'])) {
                $this->orgLen= (is_numeric($urlArgs['olen']) && $urlArgs['olen'] > 0) ? $urlArgs['olen'] : $this->orgLen;
            }

            if ($this->is_lfArgAllowed() && isset($urlArgs['lf'])) {
                //if (($this->is_patronHOF() || $this->is_volunteerHOF()) && isset($urlArgs['lf'])) {
                //  lf argument is only used by patron and volunteer
                //  tables.  Really this should be in a derived object
                $afferoFoundations= $this->dbConnection->foundationsAll();

                //  weed out any members of the arg list which are not
                //  in the database
                $lfArgs= explode(",", $urlArgs['lf']);

                foreach($lfArgs as $arg) {
                    foreach($afferoFoundations as $f) {
                        $fn= rtrim($f['foundation_name']);
                        if (myFnmatch($arg, $fn)) {
                            $this->foundationIds[]= $f['foundation_id'];
                        }
                    }
                }
                $this->foundationIds= array_unique($this->foundationIds);
                
                //  this id will never be matched.  if it is the only
                //  array element thena nd empty table will be
                //  generated.
                $this->foundationIds[]= -1;
            }

            // tc= (table contents) for volunteers only, specify thr
            // type of data to appesr in the table
            if ($this->is_volunteerHOF() || $this->is_patronHOF() && isset($urlArgs['tc'])) {
                //  lf argument is only used by the volunteer table.
                //  Really this should be in a derived object
                $tc= strtolower($urlArgs['tc']);
                if (in_array($tc, $this->legalTcArgs)) {
                    $this->tableContents= $tc;
                }
            }
            //  rf= can only be specified with tc=
            if (($this->is_volunteerHOF() || $this->is_patronHOF()) && isset($urlArgs['tc']) && isset($urlArgs['rf'])) {
                //  lf argument is only used by patron and volunteer
                //  tables.  Really this should be in a derived object
                $rf= strtolower($urlArgs['rf']);
                if (in_array($rf, $this->legalRfArgs)) {
                    $this->rFilter= $rf;
                }
            }

            //  dates, table limit
            $this->toDate= (isset($urlArgs['to']) && ($t= strtotime($urlArgs['to'])) > 0 ) ? $t : $this->toDate;
            $this->fromDate= (isset($urlArgs['from']) && ($t= strtotime($urlArgs['from'])) > 0 ) ? $t : $this->fromDate;
            $this->limit= (isset($urlArgs['lim']) && is_numeric($t= $urlArgs['lim']) && $t >= 0) ? $t : $this->limit;
            $typeArg= (isset($urlArgs['type']) && strlen($urlArgs['type']) > 0) ? strtolower($urlArgs['type']) : $this->type;

            //  make sure that the type is legal
            $this->type= in_array($typeArg, $this->legalTypes) ? $typeArg : $this->type;

            //  if to date is prior to from date then swap them.
            if ($this->fromDate > $this->toDate) {
                $t= $this->fromDate;
                $this->fromDate= $this->toDate;
                $this->toDate= $t;
            }

            //  if either date is in the future, then substitute today
            $testToday= strtotime("today");
            $this->fromDate= ($this->fromDate > $testToday) ? $testToday: $this->fromDate;
            $this->toDate= ($this->toDate > $testToday) ? $testToday: $this->toDate;

            //  format an ascii string date range suitable for display
            //  in a table header.
            $this->dpyDateRange = date("n/j-", $this->fromDate);
            $this->dpyDateRange .= date("n/j", $this->toDate);
        }
    }

////////////////////////////////////////////////////////////////////
////    PRIVATE METHODS      ///////////////////////////////////////
////////////////////////////////////////////////////////////////////
//  take a list name argument.  return true if the list is in the
//  database
    function is_patronHOF() {
        $p= preg_match("/topPatrons/", $_SERVER['PHP_SELF']);
        return($p == 1);
    }
    function is_volunteerHOF() {
        $p= preg_match("/topVolunteers/", $_SERVER['PHP_SELF']);
        return($p == 1);
    }
    function is_beneficiaryHOF() {
        $p= preg_match("/topBeneficiaries/", $_SERVER['PHP_SELF']);
        return($p == 1);
    }
    function is_lfArgAllowed() {
        //  lf arguments are alloweed for patronsHOF and for
        //  volunteers HOF they are also allowed for beneficiaries HOF
        //  if a user argument (vu= or pu=) argument was specified.
        $b= $this->is_volunteerHOF();
        
        $myRC= ($this->is_patronHOF() || $this->is_volunteerHOF());
        $myRC |= isset($this->bUser);
        return($myRC);
    }
}
?>
