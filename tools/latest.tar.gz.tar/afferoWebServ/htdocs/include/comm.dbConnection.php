<?php
//  $Name: ORG-TEST $, $Id: comm.dbConnection.php,v 1.16 2002/10/04 16:44:44 leed Exp $
//
class dbConnection
{
	var $connection;
	var $results;
    var $oid;

    function dbConnection() {
        $this->connection = FALSE;
        $this->results = FALSE;
    }

    ////////////////////////////////////////////////////////////////////
	//  This function simply opens a connection to the database.
	//  uses the variables as defined in include/config.inc.php.
    function openConnection($argStr="") {
		global $dbhost, $dbuname, $dbpass, $dbname;

        $argStr= ($argStr == "") ? $this->dbConnectionArgs() : $argStr;
		return($this->connection = pg_pconnect("$argStr"));
	}
    
    function dbConnectionArgs(){
        global $dbhost, $dbuname, $dbpass, $dbname;
        $argstr= "dbname=$dbname host=" . gethostbyname($dbhost) . " user=$dbuname";
        return($argstr);
    }
    
	//  This function simply closes this connection to the database.
    function closeConnection() {
		pg_close($this->connection);
        $this->connection = FALSE;
	}
    ////////////////////////////////////////////////////////////////////
	//  This function executes the given query, assuming the connection has
	//  been opened.  It is not a good idea to log a message here if the
    //  query fails.  There are times when a failed database access
    //  is expected.
	function executeQuery($queryString) {
		$this->results = pg_query($this->connection, $queryString);
        return($this->results != FALSE);
	}
    ////////////////////////////////////////////////////////////////////
	//  This function returns the results object back to the caller in case
	//  the user wants to work with it directly.
	function getResults() {
		return $this->results;
	}
    ////////////////////////////////////////////////////////////////////
	//  This function returns the results object back to the caller in case
	//  the user wants to work with it directly.
	function getLastOid() {
        $this->oid = pg_last_oid($this->results);
		return ($this->oid);
	}
	//
	//  This function returns the next row in the form of an array.
	function fetchNextRow($index, $rt= PGSQL_BOTH) {
		$arr = pg_fetch_array($this->results, $index, $rt);
		return $arr;
	}
    ////////////////////////////////////////////////////////////////////
    //  return connection attributes
	function getNumRows() {
        $myCount = $this->results ? pg_num_rows($this->results) : 0;
		return ($myCount);
	}
	function getAffectedRows() {
        $myCount = $this->results ? pg_affected_rows($this->results) : 0;
		return ($myCount);
	}
 	function getErrorMessage() {
		return pg_errormessage($this->connection);
	}
	function getConnection(){
		return $this->connection;
	}
}

?>
