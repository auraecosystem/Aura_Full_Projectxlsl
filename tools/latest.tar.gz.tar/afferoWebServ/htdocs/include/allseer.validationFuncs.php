<?
//  $Name: ORG-TEST $, $Id: allseer.validationFuncs.php,v 1.2 2002/01/03 18:27:39 leed Exp $
////////////////////////////////////////////////////////////////////////
//  Default Form Field validation functions
?>
