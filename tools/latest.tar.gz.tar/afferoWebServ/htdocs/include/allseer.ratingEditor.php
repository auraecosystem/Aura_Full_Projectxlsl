<?php
//  $Name: ORG-TEST $, $Id: allseer.ratingEditor.php,v 1.3 2002/11/25 17:50:49 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  This is a class for modifying rating fields from a form and,      //
//  updating the database rating attributes apprpriately.             //
//  There are a few level of paranoia here.  the calling script       //
//  (user-history.php) will not expose links to this edit function    //
//  unless the appropriate config variable ($ratingEditIsAllowed =    //
//  true;) is set.  that config variable does not even appear in the  //
//  live comfig file.  even if the link is somehow generated on the   //
//  libe user-history page, the code for rating-edits will not be     //
//  included in the distribution rpm                                  //
////////////////////////////////////////////////////////////////////////
require_once("allseer.UserSqlConn.php");
require_once("allseer.validator.php");

class ratingEditor
{
########################################################################
##   Constructor         ###############################################
########################################################################
    function ratingEditor () {
        $this->server= $_SERVER["SERVER_NAME"];

        $this->rid= isset($_REQUEST["rid"]) ? $_REQUEST["rid"] : NULL;
        $this->str= isset($_REQUEST["str"]) ? $_REQUEST["str"] : "";
        
        $this->validationFlag= FALSE;
        $this->topBarCell1= "RATING TABLE EDITOR: [[  {$this->str}  ]]";

        $this->dbConnection = new UserSqlConn;
    }

########################################################################
##   Private Functions   ###############################################
########################################################################
    #  move HTTP POST variables into object attributes
    function readPostVariables() {
        global $HTTP_POST_VARS;
        $myPostVars= $HTTP_POST_VARS;

        //  and move the rest of the post variables into object
        //  attributes,  mainly for convenience.
        reset($myPostVars);
        while (list($var, $value) = each($myPostVars)) {
            list($attrName)= sscanf($var, "Form%s");
            if ($attrName != "") {
                $this->$attrName= $value;
                unset($myPostVars["$var"]);

            }
        }
        return(TRUE);
    }
    #  remove all traces of a rating from the database
    function removeRating() {
        $myTransState= "continue";
        $conn= $this->dbConnection;
        $rc= "OK";

        #  start the transaction
        if ($myTransState == "continue" && !$conn->openConnection()) {
            $myTransState= "exit";
            $rc = "ratingEditor::removeRating() could not open database connection exit now";
        }
        if ($myTransState == "continue" && !$conn->executeQuery("begin work;")) {
            $myTransState= "close";
            $rc = "ratingEditor::removeRating() Cant start transaction " . $conn->getErrorMessage();
        }

        #  delete all tcx records ssociated with this rating
        $deleteTCX=
             "delete from as_tc_xactions " .
             "where tcx_tip_id in " .
             "    (select tip_id " .
             "    from as_tips " .
             "    where tip_rating = '{$this->rid}')";

        if ($myTransState == "continue" && !$conn->executeQuery($deleteTCX)) {
            $rc= "ratingEditor::removeRating() Can't remove TCX rows";
            $myTransState = "rollback";
        }
        
        #  delete all bpct records ssociated with this rating
        $deleteBPCT=
             "delete from as_bpct " .
             "where bpct_tip in " .
             "    (select tip_id " .
             "    from as_tips " .
             "    where tip_rating = '{$this->rid}')";
        
        if ($myTransState == "continue" && !$conn->executeQuery($deleteBPCT)) {
            $rc= "ratingEditor::removeRating() Can't remove BPCT rows";
            $myTransState = "rollback";
        }

        #  delete all tip rows associated with this rating
        $deleteTips=
             "delete from as_tips " .
             "where tip_rating = '{$this->rid}'";

        if ($myTransState == "continue" && !$conn->executeQuery($deleteTips)) {
            $rc= "ratingEditor::removeRating() Can't remove tip rows";
            $myTransState = "rollback";

        }

        #  delete rating rows
        $deleteRatings=
             "delete from as_ratings " .
             "where  rating_id = '{$this->rid}' " .
             "    or rating_rid = '{$this->rid}'";

        if ($myTransState == "continue" && !$conn->executeQuery($deleteRatings)) {
            $rc= "ratingEditor::removeRating() Can't remove rating rows";
            $myTransState = "rollback";

        }

        //  end of transaction.  commit or rollback.
        if ($myTransState == "continue") {
            if ($conn->executeQuery("commit work;")) {
                $myTransState = "close";
                $rc = "OK";

            } else {
                $myTransState = "rollback";
            }
        }
        if ($rc != "OK") {
            syslog(LOG_ERROR, $rc);
            echo("<br><br><font color=red>$rc</font>");
        }

        if ($myTransState == "rollback") {
            $logMsg= "ratingEditor::removeRating() Transaction failure.  Rolling back";
            syslog(LOG_ERROR, $logMsg);
            
            $conn->executeQuery("rollback");
            $myTransState = "close";
        }
        //  be nice to your database server
        if ($myTransState == "close") {
            $conn->closeConnection();
        }
    }
    #  update a rating in database
    function updateRating() {
        $this->newRating= $this->rating;
        $this->newRating["rating_descr"]= $this->Comment;
        $rc= $this->dbConnection->updateRatingAttrs($this->rating, $this->newRating);
        return($rc);
    }

########################################################################
##   Interface Functions   #############################################
########################################################################
    #  edit check all of the form fields
    function validateFields() {
        $this->Messages = array();
        $this->readPostVariables();
        //  nothing is true.  everything is permitted.
        if (isset($this->Validate)) {
            $this->validationFlag= TRUE;
        }
        $v= new asValidator();
        $v->CLEAR= TRUE;
        return($this->validated());
    }
    ####################################################################
    #  retrn validation status
    function validated(){
        return($this->validationFlag);
    }
    ####################################################################
    #  initialize object properties
    function init(){
        $rc= "OK";
        // check object integrity
        if ($this->rid == NULL) {
            $rc= "ratingEditor::init() no rating id";
            return($rc);
        }
        //  read rating attributes
        if (!($this->rating= $this->dbConnection->fetchRatingAttrs($this->rid))){
            $rc= "ratingEditor::init() couldn't read rating attributes";
            return($rc);
        }
        return($rc);
    }
    ####################################################################
    #  update database as required
    function Finalize() {
        $this->validationFlag = FALSE;
        $myRC = "OK";

        $deleteFlag= (isset($this->DeleteRequest) && $this->DeleteRequest == "t");
        $comment= (isset($this->Comment)) ? $this->Comment : $this->rating["rating_desc"];

        if ($deleteFlag) {
            $this->removeRating();

        } else if ($comment != $this->rating["rating_desc"]) {
            $this->updateRating();
        }

        return($myRC);
    }
}
?>