<?php
//  $Name: ORG-TEST $, $Id: webservice.topVolunteers.php,v 1.8 2002/12/12 21:00:44 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  This is a class for validating rate me fields from a form.
////
//  TODO: move all of the SQL out of this object and in to the
//        the allseer.UserSQLConn.php boject
////////////////////////////////////////////////////////////////////////
require_once("allseer.UserSqlConn.php");
require_once("webservice.topUserHOFArgs.php");
require_once("allseer.variousFunctions.php");

class topVolunteers
{
    ////////////////////////////////////////////////////////////////////
    ////    CONSRUCTOR      ////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////
    function  topVolunteers() {
        $this->objectStatus= "OK";
        $this->dbConnection= new UserSqlConn();
        $this->historyHost= $GLOBALS['historyHost'];
        $this->hofArgs= new topUserHOFArgs();
        $this->dataHeader= "Amt";
        
        //  default values for URL arguments
        $this->lists= $this->hofArgs->lists;
        $this->fids= $this->hofArgs->foundationIds;

        $this->type= $this->hofArgs->type;   
        $this->fromDate= $this->hofArgs->fromDate;
        $this->toDate= $this->hofArgs->toDate;
        $this->limit= $this->hofArgs->limit;
        $this->dpyDateRange = $this->hofArgs->dpyDateRange;
        
        //  HOF table.
        $this->emptyTableText= "gifts";
        if ($this->hofArgs->is_patronHOF()) {
            $this->tableSubTitle= "(by funds donated)";
        } else {
            $this->tableSubTitle= "(by funds raised)";
        }
        if ($this->hofArgs->tableContents == "values") {
            $ary= $this->dbConnection->readExpertHOFvalues($this->fromDate, $this->toDate, $this->lists);
            
        } else if ($this->hofArgs->tableContents == "count") {
            $tempAry= $this->dbConnection->readExpertHOFcounts($this->fromDate,
                                                               $this->toDate,
                                                               $this->lists,
                                                               $this->fids,
                                                               $this->hofArgs->rFilter);
            $this->xAry= array();
            foreach($tempAry as $row)  {
                $this->userCountXform($row);
            }
            $ary= array();
            foreach($this->xAry as $row){
                $ary[]= array('login'=>$row['login'], 'xdat'=>count($row['rators']));
            }
            usort($ary, array($this, "countComparator"));
            $this->dataHeader= "Count";

            if ($this->hofArgs->rFilter == "text") {
                $this->tableSubTitle= "(by Commenting Members)";
                $this->emptyTableText= "comments";
                
            } else {
                $this->tableSubTitle= "(by Rating Members)";
                $this->emptyTableText= "ratings";
            }
            
            
        } else {
            $ary= $this->dbConnection->readExpertHOFdonations($this->fromDate, $this->toDate, $this->lists, $this->fids);
        }
        
        $this->volunteersAry= array_slice(array_filter($ary, array($this, "volunteersArrayFilter")), 0, $this->limit);
        $this->tableTitle= "Top " . (($t= count($this->volunteersAry)) == 0 ?  "" : "$t") . " Volunteers";
        $this->tableRows= count($this->volunteersAry);
    }

    ////////////////////////////////////////////////////////////////////
    ////    PRIVATE METHODS      ///////////////////////////////////////
    ////////////////////////////////////////////////////////////////////
    //  take a row from the volunteersAry.  return true if this row is to
    //  appear in the volunteer hall of fame
    function volunteersArrayFilter($row) {
        $myRC= !placeHolderUserName($row['login']);
        return($myRC);
    }
    
    function userCountXform($row) {
        $user= $row['user'];
        if (!isset($this->xAry["$user"])) {
            $this->xAry["$user"]= array('login' => "$user", 'rators'=> array());
        }
        
        if (!in_array($row['rator'], $this->xAry["$user"]['rators'])) {
            $this->xAry["$user"]['rators'][]= $row['rator'];
        }
    }
    function countComparator($a, $b) {
        if ($a['xdat'] == $b['xdat']) {
            $rc= 0;
        } else if ($a['xdat'] > $b['xdat']) {
            $rc= -1;
        } else {
            $rc= 1;
        }
        return($rc);
    }
}

?>
