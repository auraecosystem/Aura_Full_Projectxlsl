<?php
//  $Name: ORG-TEST $, $Id: allseer.profileObject.php,v 1.10 2002/09/02 21:34:26 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//
require_once("allseer.UserSqlConn.php");

class profileObject
{
    var $dbConnection;
    var $profileID;
    var $userLogin;
    var $profileName;
    var $profileAry;

    function profileObject() {
        $this->dbConnection= new UserSqlConn();
        $this->profileID= FALSE;
        $this->userLogin= FALSE;
        $this->profileName= FALSE;
        $this->profileAry= array();
    }

    function setUserLogin($arg){
        $this->userLogin= $arg;
        //echo("<br>profileObject::setUserLogin()..."); var_dump($this->userLogin);
    }

    function setProfileName($arg){
        $this->profileName= $arg;
        //echo("<br>profileObject::setProfileName()..."); var_dump($this->profileName);
    }

    //  set the propaganda block in displayable form
    function setDpyProppa(){
        if (trim($this->profileProppaType) == "plain") {
            $specChar= htmlspecialchars($this->profileProppa, ENT_QUOTES);
            $this->displayProppa= nl2br(wordwrap($specChar,100,"\n",1));

        } else {
            $this->displayProppa= $this->profileProppa;
        }

        $this->displayProppaWriter=
             (isset($this->profileProppaWriter) && $this->profileProppaWriter != "")
             ?  $this->profileProppaWriter
             : "&nbsp;";
        
        if (isset($this->userStatus)  && $this->userStatus != "activated") {
            $this->displayProppa= "";
        }
    }

    //  construct a profile array
    function consProfileAry(){
        $conn=& $this->dbConnection;
        $ary=& $this->profileAry;
        $ary= array();
        if ($conn && ($this->profileID || $this->setProfileID())) {
            $ary= $conn->profilePercentageAry($this->profileID);
        }
        for ($i=0; $i<count($ary); $i++){
            if (strlen($ary[$i]['url']) > 0){
                $ary[$i]['dpyTxt']= "<a target=\"new\" href=\"{$ary[$i]['url']}\">{$ary[$i]['bene']}</a>";
            } else {
                $ary[$i]['dpyTxt']= $ary[$i]['bene'];
            }
        }
        return($this->profileAry);
    }

    ////////////////////////////////////////////////////////////////////
    //  retrieve the id for the relevant profile from the database.
    function setProfileID(){
        $conn=& $this->dbConnection;
        $this->profileID= FALSE;
        $locPid= FALSE;
        //echo("<br>profileObject::setProfileID() userLogin..."); var_dump($this->userLogin);
        //echo("<br>profileObject::setProfileID() profileName..."); var_dump($this->profileName);
        //  if there is a user and a profile name.
        if ($this->userLogin && $this->profileName) {
            $locPid= $conn->fetchUserPayProfile($this->userLogin, $this->profileName);
        }
        //  try a default for the user
        if (!$locPid && $this->userLogin) {
            $tAry= $conn->fetchUserDefaultPayProfile($this->userLogin);
            if (count($tAry) == 1 && isset($tAry[0]['name'])) {
                $locPid= $conn->fetchUserPayProfile($this->userLogin, $tAry[0]['name']);
            }
        }
        //  system profile with the given name
        if (!$locPid &&  $this->profileName) {
            $tAry= $conn->fetchUserPayProfile("allseer//", $this->profileName);
            $locPid= (count($tAry) == 1 && isset($tAry[0]['id'])) ? $tAry : $locPid;
        }

        //  if no profile Id has yet been found, then use the system default
        $locPid= ($locPid) ? $locPid : $conn->fetchUserPayProfile("allseer//", "default");

        if ($locPid && isset($locPid[0]['id'])) {
            $this->profileID= $locPid[0]['id'];
        }
        if ($locPid && isset($locPid[0]['user_status'])) {
            $this->userStatus= trim($locPid[0]['user_status']);
        }
        if ($locPid && isset($locPid[0]['proppa'])) {
            $this->profileProppa= $locPid[0]['proppa'];
        }
        if ($locPid && isset($locPid[0]['proppa_writer'])) {
            $this->profileProppaWriter= $locPid[0]['proppa_writer'];
        }
        if ($locPid && isset($locPid[0]['proppa_tp'])) {
            $this->profileProppaType= $locPid[0]['proppa_tp'];
        }
        //echo("<br><br>locPid..."); var_dump($locPid[0]);
        //echo("<br><br>profileObject..."); var_dump($this);
        
        return(!!$this->profileID);
    }
}
