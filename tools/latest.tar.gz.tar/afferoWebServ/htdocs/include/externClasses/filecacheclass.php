<?php
if(!defined("METAL_LIBRARY_CACHE_FILE_CACHE_CLASS"))
{
	define("METAL_LIBRARY_CACHE_FILE_CACHE_CLASS",1);

/*
 *
 * Copyright � (C) Manuel Lemos 2001
 *
 * @(#) $Name: ORG-TEST $, $Id: filecacheclass.php,v 1.2 2002/01/03 18:28:52 leed Exp $
 *
 */

class file_cache_class
{
	/*
	 * Protected variables
	 *
	 */
	var $read_cache_file;
	var $read_cache_file_opened=0;
	var $write_cache_file;
	var $write_cache_file_opened=0;
	var $writtencachelength=0;
	
	/*
	 * Public variables
	 *
	 */
	var $path="";
	var $flush_cache_file=0;
	var $error="";
	var $reopenupdatedcache=1;
	var $headers=array();
	var $cache_buffer_length=100000;
	var $automatic_headers=1;
	
	
	/*
	 * Protected functions
	 *
	 */
	Function writecachedata(&$data)
	{
		if(((fwrite($this->write_cache_file,$data,strlen($data))!=0)))
			return 1;
		$this->error="could not write to the cache file";
		return 0;
	}
	
	Function readcachedata(&$data,$length)
	{
		if(($length<=0))
		{
			$this->error="it was specified an invalid cache data read length";
			return 0;
		}
		if((GetType($data=fread($this->read_cache_file,$length))=="string"))
			return 1;
		$this->error="could not read from the cache file";
		return 0;
	}
	
	Function readcacheline(&$line,$length)
	{
		if(($length<=0))
		{
			$this->error="it was specified an invalid cache line read length";
			return 0;
		}
		if((GetType($line=fgets($this->read_cache_file,$length))=="string"))
		{
			if((GetType($endofline=strpos($line,"\r"))=="integer"))
				$line=substr($line,0,$endofline);
			return 1;
		}
		$this->error="could not read from the cache file";
		return 0;
	}
	
	Function endofcache(&$endofcache)
	{
		if(!($this->read_cache_file_opened))
		{
			$this->error="endofcache function is not implemented";
			return 0;
		}
		$endofcache=feof($this->read_cache_file);
		return 1;
	}
	
	Function cachelength(&$length)
	{
		if(((GetType($length=@filesize($this->path))=="integer")))
			return 1;
		$this->error="could not determing cache file length";
		return 0;
	}
	
	Function cachebufferlength(&$length)
	{
		$length=$this->cache_buffer_length;
		if(($length!=0 || $this->cachelength($length)))
			return 1;
		$this->error=("could not get cache buffer length: ".$this->error);
		return 0;
	}
	
	Function readcacheheaders(&$read)
	{
		$this->headers=array();
		if(!($this->cachebufferlength($length)))
			return 0;
		for(;;)
		{
			if(!($this->readcacheline($line,$length)))
				return 0;
			if(!(strlen($line)!=0))
				break;
			if(!($this->endofcache($endofcache)))
				return 0;
			if((GetType($endofline=strpos($line,"\r"))=="integer"))
				$line=substr($line,0,$endofline);
			if(($endofcache || !GetType($space=strpos($line," "))=="integer"))
			{
				$read=0;
				return 1;
			}
			$this->headers[substr($line,0,$space)]=substr($line,($space+1),(strlen($line)-$space-1));
		}
		$read=1;
		return 1;
	}
	
	Function updatedcache(&$updated)
	{
		if(!($this->readcacheheaders($updated)))
			return 0;
		if(($updated && IsSet($this->headers["x-expires:"])))
			$updated=(strcmp($this->headers["x-expires:"],strftime("%Y-%m-%d %H:%M:%S"))>0);
		if(!($updated))
			$this->headers=array();
		return 1;
	}
	
	Function writecache(&$data,$endofcache)
	{
		if(($this->writtencachelength==0))
		{
			$rfc822now=gmstrftime("%a, %d %b %Y %H:%M:%S GMT");
			srand(time());
			if(($this->automatic_headers && (!$this->setheader("date:",$rfc822now) || !$this->setheader("etag:","\"".md5(strval(rand(0,9999)).$rfc822now)."\"") || ($endofcache && !$this->setheader("content-length:",strval(strlen($data)))))))
				return 0;
			$header=0;
			Reset($this->headers);
			for(;$header<Count($this->headers);)
			{
				$headername=Key($this->headers);
				$headerdata=($headername." ".$this->headers[$headername]."\r\n");
				if(!($this->writecachedata($headerdata)))
				{
					$this->error=("could not write to the cache headers: ".$this->error);
					return 0;
				}
				Next($this->headers);
				$header++;
			}
			$headerdata="\r\n";
			if(!($this->writecachedata($headerdata)))
			{
				$this->error=("could not write to the cache header separator: ".$this->error);
				return 0;
			}
		}
		if(!($this->writecachedata($data)))
		{
			$this->error=("could not write to the cache data: ".$this->error);
			return 0;
		}
		$this->writtencachelength=($this->writtencachelength+strlen($data));
		return 1;
	}
	
	/*
	 * Public functions
	 *
	 */
	Function verifycache(&$updated)
	{
		if(($this->read_cache_file_opened))
		{
			$this->error="the cache file is already opened for reading";
			return 0;
		}
		if((!strcmp($this->path,"")))
		{
			$this->error="it was not specified the cache file path";
			return 0;
		}
		$updated=0;
		if((file_exists($this->path)))
		{
			if(!((($this->read_cache_file=@fopen($this->path,"rb"))!=0)))
			{
				$this->error="could not open cache file for reading";
				return 0;
			}
			if(!(@flock($this->read_cache_file,1)))
			{
				fclose($this->read_cache_file);
				$this->error="could not lock shared cache file";
				return 0;
			}
			$this->read_cache_file_opened=1;
			$success=$this->cachelength($length);
			if(($success))
			{
				if(($length>0))
					$success=$this->updatedcache($updated);
			}
			if(!($success))
			{
				@flock($this->read_cache_file,3);
				fclose($this->read_cache_file);
				$this->read_cache_file_opened=0;
				return 0;
			}
			if(($updated))
				return 1;
			$success=@flock($this->read_cache_file,3);
			fclose($this->read_cache_file);
			$this->read_cache_file_opened=0;
			if(!($success))
			{
				$this->error="could not unlock the cache file";
				return 0;
			}
		}
		if(!((($this->read_cache_file=@fopen($this->path,"ab"))!=0)))
		{
			$this->error="could not open cache file for appending";
			return 0;
		}
		$this->read_cache_file_opened=1;
		if(!(@flock($this->read_cache_file,2)))
		{
			$this->error="could not lock exclusive cache file";
			@flock($this->read_cache_file,3);
			fclose($this->read_cache_file);
			$this->read_cache_file_opened=0;
			return 0;
		}
		if(!((($this->write_cache_file=@fopen($this->path,"wb"))!=0)))
		{
			@flock($this->read_cache_file,3);
			fclose($this->read_cache_file);
			$this->read_cache_file_opened=0;
			$this->error="could not open cache file for writing";
			return 0;
		}
		$this->write_cache_file_opened=1;
		return 1;
	}
	
	Function storedata(&$data,$endofcache)
	{
		if(!($this->write_cache_file_opened))
		{
			$this->error="cache file is not set for storing data";
			return 0;
		}
		$success=$this->writecache($data,$endofcache);
		if(($success))
		{
			$success=(!$endofcache || !$this->flush_cache_file || fflush($this->write_cache_file));
			if(!($success))
				$this->error="could not flush the cache file";
		}
		if(!($success))
		{
			fclose($this->write_cache_file);
			$this->write_cache_file_opened=0;
			@flock($this->read_cache_file,3);
			fclose($this->read_cache_file);
			unlink($this->path);
			$this->read_cache_file_opened=0;
			return 0;
		}
		if(!($endofcache))
			return 1;
		fclose($this->write_cache_file);
		$this->write_cache_file_opened=0;
		@flock($this->read_cache_file,3);
		fclose($this->read_cache_file);
		$this->read_cache_file_opened=0;
		if(!($this->reopenupdatedcache))
			return 1;
		if(!((($this->read_cache_file=@fopen($this->path,"rb"))!=0)))
		{
			$this->error="could not reopen cache file for reading";
			return 0;
		}
		if(!(@flock($this->read_cache_file,1)))
		{
			fclose($this->read_cache_file);
			$this->error="could not lock shared cache file";
			return 0;
		}
		$this->read_cache_file_opened=1;
		if(!($this->readcacheheaders($read)))
			return 0;
		if(!($read))
		{
			@flock($this->read_cache_file,3);
			fclose($this->read_cache_file);
			$this->read_cache_file_opened=0;
			$this->error="could not read the cache file headers";
			return 0;
		}
		return 1;
	}
	
	Function retrievefromcache(&$data,&$endofcache)
	{
		if(!($this->read_cache_file_opened))
		{
			$this->error="cache file is not set for retrieving cached data";
			return 0;
		}
		if(($this->write_cache_file_opened))
		{
			$this->error="cache file is still opened for writing";
			return 0;
		}
		$success=$this->cachebufferlength($length);
		if(($success))
			$success=($length==0 || $this->readcachedata($data,$length));
		if(!($success))
		{
			@flock($this->read_cache_file,3);
			fclose($this->read_cache_file);
			$this->read_cache_file_opened=0;
			return 0;
		}
		if(($length==0))
			$endofcache=1;
		else
		{
			if(!($this->endofcache($endofcache)))
			{
				@flock($this->read_cache_file,3);
				fclose($this->read_cache_file);
				$this->read_cache_file_opened=0;
				return 0;
			}
		}
		if(!($endofcache))
			return 1;
		@flock($this->read_cache_file,3);
		fclose($this->read_cache_file);
		$this->read_cache_file_opened=0;
		return 1;
	}
	
	Function closecache()
	{
		if(($this->read_cache_file_opened || $this->write_cache_file_opened))
		{
			@flock($this->read_cache_file,3);
			$this->read_cache_file_opened=0;
		}
		if(($this->read_cache_file_opened))
		{
			fclose($this->read_cache_file);
			$this->read_cache_file_opened=0;
		}
		if(($this->write_cache_file_opened))
		{
			fclose($this->write_cache_file);
			$this->write_cache_file_opened=0;
		}
	}
	
	Function voidcache()
	{
		if(($this->read_cache_file_opened))
		{
			$this->error="can not void cache with the file open for reading";
			return 0;
		}
		if((!strcmp($this->path,"")))
		{
			$this->error="it was not specified the cache file path";
			return 0;
		}
		if(!(file_exists($this->path)))
			return 1;
		if(!((($this->read_cache_file=@fopen($this->path,"ab"))!=0)))
		{
			$this->error="could not open the cache file for reading";
			return 0;
		}
		if(!(@flock($this->read_cache_file,2)))
		{
			fclose($this->read_cache_file);
			$this->error="could not lock exclusive cache file";
			return 0;
		}
		$success=(($this->write_cache_file=@fopen($this->path,"wb"))!=0);
		if(($success))
			fclose($this->write_cache_file);
		@flock($this->read_cache_file,3);
		fclose($this->read_cache_file);
		$this->error="could not open cache file for writing";
		unlink($this->path);
		return $success;
	}
	
	Function setheader($header,$value)
	{
		if((GetType(strpos($header," "))=="integer"))
		{
			$this->error="it was specified a header name with a space in it";
			return 0;
		}
		$lowerheader=strtolower($header);
		if((IsSet($this->headers[$lowerheader])))
		{
			$this->error="it was specified a header already defined";
			return 0;
		}
		$this->headers[$lowerheader]=$value;
		return 1;
	}
	
	Function setexpirydate($date)
	{
		if(!($this->setheader("x-expires:",$date)))
			return 0;
		if(($this->automatic_headers))
			return $this->setheader("expires:",gmstrftime("%a, %d %b %Y %H:%M:%S GMT",mktime(substr($date,11,2),substr($date,14,2),substr($date,17,2),substr($date,5,2),substr($date,8,2),substr($date,0,4))));
		return 1;
	}
	
	Function setexpirytime($time)
	{
		if(($time<=0))
		{
			$this->error="it was not specified a valid expiry time period";
			return 0;
		}
		return $this->setexpirydate(strftime("%Y-%m-%d %H:%M:%S",time()+$time));
	}
};

}
?>