<?php
  
//----------------------------------------------------------------------  
//  $Id: session.php,v 1.3 2002/09/02 21:36:16 leed Exp $
//----------------------------------------------------------------------
// sessioncookie : session management
//
// Original implementation by:
// Danny Heijl - Danny.Heijl@cevi.be, aug 1999
//
// Modified and enhanced by:
// Christoph Kassen - php@chkassen.de, nov 2000
// Download at www.chkassen.de
//
// Convert to use PostgreSQL, modify and enhanced by:
// Thomas Du - konga.geo@yahoo.com, Jan. 2000
//
// buggered severelu by r.l.doolan to fit in
// to allseer's V1 site
//
// USE THIS SOFTWARE AT YOUR OWN RISK
//
// --------------------------------------------------------------------
  
class sessioncookie
{
    var $sdata;
    var $id;
    var $dblink;
    //Constructor
    //Must be called before any output is generated 
    function sessioncookie () {
        global $php_sessid;

        //Disable caching
        header ("Expires: Mon, 26 Jul 1999 05:00:00 GMT");    // Date in the past
        header ("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");  // always modified
        header ("Cache-Control: no-cache, must-revalidate");  // HTTP/1.1
        header ("Pragma: no-cache");                          // HTTP/1.0

        //echo("<br>  sessioncookie....");
        $this->id = $php_sessid;
        $this->sdata = array();
        $this->dblink = '';
    }
 
    //Name   : connect2db
    //Description: Opens a connection to the mySQL server and selects a DB
    //Returns    : -
    //Parameter  : -
    function connect2db (){
        global $dbhost, $dbuname, $dbpass, $dbname;
        $argstr= "dbname=$dbname host=" . gethostbyname($dbhost) . " user=$dbuname";
        
        $this->dblink = @pg_connect($argstr) or die ("Could not connect to DB.\n");
    }
 
    //Name0   : start
    //Description: Starts a new session or loads previously stored values for a session
    //Returns    : -
    //Parameter  : -
    function start () {
        if(!isset($this->id)) {
            //no session id found
            //generate a new one
            srand ((double) microtime() * 1000000);
            $this->id = md5(uniqid(rand()));
            //setcookie("php_sessid", $this->id, 0);
            return;
        } else {
            //session id found
            $query = "SELECT val FROM as_sessions WHERE sid='$this->id';";
            $result = @pg_query($this->dblink, $query);
            $sessiondata = @pg_fetch_row($result, 0);
            $rest = unserialize($sessiondata[0]);
            while (@list($key, $val) = @each($rest)) {
                $GLOBALS["$key"] = $val;
                $this->sdata[$key] = $val;
            }
        }
    }

    //Name   : register
    //Description: Registers a session variable
    //Returns    : -
    //Parameter  : variablename
    function register ($var) {
        $this->sdata[$var] = $var;
    }

    //Name   : unregister
    //Description: Unregisters a session variable
    //Returns    : -
    //Parameter  : variablename
    function unregister ($var) {
        unset($this->sdata[$var]);
        unset($GLOBALS["$var"]);
    }

    //Name   : destroy
    //Description: Stops a current session
    //Returns    : -
    //Parameter  : -
    function destroy () {
        while (@list($key, $val) = @each($this->sdata)) {
            $this->unregister($key);
        }
        $this->sdata = array();
        $this->save();
        $this->id = '';
        $php_sessid = '';
        // closing database persistent connection
        pg_close($this->dblink);
        $this->dblink = '';
    }

    //Name   : isregistered
    //Description: Checks if a variable is registered in a session
    //Returns    : 1(true) or 0(false)
    //Parameter  : variablename
    function isregistered ($name) {
        return (isset($this->sdata[$name]) ? 1 : 0);
    }

    //Name   : save
    //Description: Saves the session array
    //Returns    : -
    //Parameter  : -
    function save () {
        for(@reset($this->sdata); $var = @key($this->sdata); @next($this->sdata)) {
            $ts[$var] = $GLOBALS[$var];
        }

        $ts = serialize($ts);

        $query = "UPDATE as_sessions SET val='$ts'  WHERE sid='$this->id';";
        $result = @pg_query($this->dblink, $query);
        if(@pg_cmdtuples($result) == 0) {
            $query = "INSERT INTO as_sessions (sid, val, created) VALUES ('$this->id', '$ts', now());";
            $result = @pg_query($this->dblink, $query);
        }
    }

    //Name   : gc
    //Description: Deletes sessions older than the gctime value from the database
    //Returns    : -
    //Parameter  : Time in seconds
    function gc ($gctime) {
        //$query = "DELETE FROM as_sessions WHERE changed < '$sqldate';";
        //$result = @pg_query($this->dblink, $query);
    }

} //Class end \\
?>
