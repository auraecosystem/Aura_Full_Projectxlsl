<?php
//  $Name: ORG-TEST $, $Id: allseer.clientProfile.php,v 1.28 2002/11/12 21:46:20 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  This is a class for validating client user fields from a form     //
//  and, updating the database client user information attributes     //
//  apprpriately.                                                     //
////////////////////////////////////////////////////////////////////////
require_once("allseer.UserSqlConn.php");
require_once("allseer.validator.php");

class clientProfile
{
    ////////////////////////////////////////////////////////////////////
    //  Constructor
    function clientProfile () {
        global $SERVER_NAME;
        $this->server= $SERVER_NAME;

        $this->Messages = array();
        $this->dbConnection = new UserSqlConn;
    }

########################################################################
##   Private Functions   ###############################################
########################################################################

    function deActivated(){
        $myRc= (isset($this->DeActivate) && $this->DeActivate == "t");
        return($myRc);
    }

    ////////////////////////////////////////////////////////////////////
    //  get a user row from the database for this client.  use the row
    //  to initialize form fields.
    ////
    //  TODO:  add Tip financials:  tips this month and tips this year
    ////
    function initFormFields() {
        $myRc = TRUE;

        // make sure that the login exists and read user attributes
        $conn = &$this->dbConnection;
        if (!$myRc = $conn->loginExists($this->uid)) {
            syslog(LOG_ERR, "clientProfile::initFormFields: no user login for '$this->uid'");

        } else if (!$myRc = $this->origUserRow= $myRow = $conn->fetchUserAttrs($this->uid)) {
            syslog(LOG_ERR, "clientProfile::initFormFields: can't read user data for '$this->uid'");

        } else {
            $this->First =      $myRow['user_first_nm'] ? $myRow['user_first_nm'] : FALSE;
            $this->Last =       $myRow['user_last_nm'] ? $myRow['user_last_nm'] : FALSE;
            $this->Email =      $myRow['user_fwd_email'] ? $myRow['user_fwd_email'] : FALSE;
            $this->Company =    $myRow['user_company'] ? $myRow['user_company'] : FALSE;
            $this->Address1 =   $myRow['user_address1'] ? $myRow['user_address1'] : FALSE;
            $this->Address2 =   $myRow['user_address2'] ? $myRow['user_address2'] : FALSE;
            $this->City =       $myRow['user_city'] ? $myRow['user_city'] : FALSE;
            $this->Zip =        $myRow['user_postal_cd'] ? $myRow['user_postal_cd'] : FALSE;
            $this->State =      $myRow['user_state_prov'] ? $myRow['user_state_prov'] : FALSE;
            $this->Country =    $myRow['user_country'] ? $myRow['user_country'] : FALSE;
            $this->Phone =      $myRow['user_phone'] ? $myRow['user_phone'] : FALSE;
        }
        $myUserRow= $myRow;
        
        //  read client attributes
        if ($myRc) {
            if (!$myRc= $this->origClientRow= $myRow = $conn->fetchClientAttrs($this->uid)) {
                syslog(LOG_ERR, "clientProfile::initFormFields: can't read client data for '$this->uid'");

            } else {
                $this->TipHistory =  $myRow['client_tip_history'] ? $myRow['client_tip_history'] : "Public";
                $this->RateNotify =  $myRow['client_rate_notify'] ? $myRow['client_rate_notify'] : 'f';
                $this->GiftNotify =  $myRow['client_gift_notify'] ? $myRow['client_gift_notify'] : 'f';

                if ($myClid = $myRow['client_uid']) {
                    $this->tipsMonth = 1.1 * (((float)$conn->clientMonthlyTips($myClid)) / 100);
                    $this->tipsYear  = 1.1 * (((float)$conn->clientYearlyTips($myClid)) / 100);
                }
            }
        }
        ///////////////////////////////////////////////////////////////
        //  build a list of e-mail addresses associated with this
        //  user.  make sure that the current forwarding e-mail
        //  address is first on the list.
        ////
        if ($myRc= ($myRc && $emailAry= $conn->fetchAltEmailArray($this->uid))) {
            if (count($emailAry) > 1) {
                //  only keep the active addresses.  put the forwarding
                //  email address in the first array element.
                $first= array();
                for($i=0; $i<count($emailAry); $i++) {
                    if ($emailAry[$i]['activep'] == "t") {
                        if ($emailAry[$i]['addy'] == $myUserRow['user_fwd_email']) {
                            $first[]= $emailAry[$i];

                        } else {
                            $r[]= $emailAry[$i];
                        }
                    }
                }
                $emailAry= array_merge($first, $r);
            }
            $this->emailSelectionAry= $emailAry;

        } else {
            syslog(LOG_ERR, "clientProfile::initFormFields: can't read email list for '$this->uid'");
        }

        return($myRc);
    }

    ////////////////////////////////////////////////////////////////////
    //  get data from form fields and update the appropriate data base
    //  tables.
    function updateDBFields() {
        $myRc = TRUE;
        $this->validationFlag = FALSE;
        //  Make sure that the login exists.  This is actually a
        //  sanity check.  should never get here, so bitch on
        //  the log.
        $conn = &$this->dbConnection;

        if (!$conn->loginExists($this->uid)) {
            $myRc = FALSE;
            syslog(LOG_ERR, "clientProfile::updateDBFields:  No such user '$this->uid'");

        } else {
            ////////////////////////////////////////////////////////////
            //  everything in this branch is a database transaction.  The
            //  variable $myTransState is it's state variable.
            ////
            //  move selected screen attributes into an array and use them
            //  to update the user table.
            $myTransState = "continue";
            $myRc = FALSE;  //  TRUE only if the transaction succeeds

            //  start the transaction
            if (!$conn->executeQuery("begin work;")) {
                $myTransState = "exit";
                $this->sqlMessage = "clientProfile::updateDBFields: close site 1==>" . $conn->getErrorMessage();
                syslog(LOG_ERR, $this->sqlMessage);

            }

            //  continue... read user fields
            $orig=& $this->origUserRow;
            if (!$orig && $myTransState == "continue" && !$orig = $conn->fetchUserAttrs($this->uid)) {
                $this->sqlMessage = "clientProfile::updateDBFields: fetchUserAttrs() failed" . $conn->getErrorMessage();
                $myTransState = "rollback";
                syslog(LOG_ERR, $this->sqlMessage);
            }

            //  continue... update user fields
            if ($myTransState == "continue") {
                $newRow = array();

                if ($this->Password1 && $this->Password1 != "") {
                    $h= new hasher;
                    
                    $newRow['user_passwd'] = $h->passwordMunge($this->Password1);
                }
                if ($this->deActivated()) {
                    $newRow['user_passwd'] = "//";
                    $newRow['user_status'] = "inactivated";
                }
                
                $newRow['user_first_nm'] = $this->First ? str_replace("\\", "\\\\", str_replace("'", "''", trim($this->First))) : "";
                $newRow['user_last_nm'] = $this->Last ? str_replace("\\", "\\\\", str_replace("'", "''", trim($this->Last))) : "";
                $newRow['user_company'] = $this->Company ? str_replace("\\", "\\\\", str_replace("'", "''", trim($this->Company))) : "";
                $newRow['user_address1'] = $this->Address1 ? str_replace("\\", "\\\\", str_replace("'", "''", trim($this->Address1))) : "";
                $newRow['user_address2'] = $this->Address2 ? str_replace("\\", "\\\\", str_replace("'", "''", trim($this->Address2))) : "";
                $newRow['user_city'] = $this->City ? str_replace("\\", "\\\\", str_replace("'", "''", trim($this->City))) : "";
                $newRow['user_postal_cd'] = $this->Zip ? $this->Zip : "";
                $newRow['user_state_prov'] = $this->State ? $this->State : "";
                $newRow['user_country'] = $this->Country ? $this->Country : "";
                $newRow['user_phone'] = $this->Phone ? $this->Phone : "";

                $newRow['user_fwd_email'] = $this->EmailSelected ? $this->EmailSelected : $orig['user_fwd_email'];
                
                $newRow['user_last_prof'] = "client";
                if (!($myRc= $conn->updateUserAttrs($orig, $newRow))) {
                    $this->sqlMessage = "clientProfile::updateDBFields: user attr update failure " . $conn->getErrorMessage();
                    $myTransState = "rollback";
                    syslog(LOG_ERR, $this->sqlMessage);
                }
            }

            //  continue... read client fields
            $orig=& $this->origClientRow;
            if ($myTransState == "continue") {
                if (count($orig) == 0 && !($orig= $conn->fetchClientAttrs($this->uid))) {
                    $this->sqlMessage = "clientProfile::updateDBFields: fetchClientAttrs() failed" . $conn->getErrorMessage();
                    $myTransState = "rollback";
                    syslog(LOG_ERR, $this->sqlMessage);
                }
            }

            //  continue... update the client fields
            if ($myTransState == "continue") {
                $newRow = array();
                if ($this->deActivated()) {
                    $this->RateNotify= $this->GiftNotify= 'f';
                }
                $newRow['client_tip_history'] = ($this->TipHistory == "Public") ? 'Public' : 'Private';
                $newRow['client_rate_notify'] = ($this->RateNotify == 't') ? 't' : 'f';
                $newRow['client_gift_notify'] = ($this->GiftNotify == 't') ? 't' : 'f';

                if (!($myRc= $conn->updateClientAttrs($orig, $newRow))) {
                    $this->sqlMessage = "clientProfile::updateDBFields: Client attr update failure " . $conn->getErrorMessage();
                    $myTransState = "rollback";
                    syslog(LOG_ERR, $this->sqlMessage);
                }
            }
            unset($orig);

            //  continue... update the expert fields
            //  if the account is deactivated then read the expert fields
            //  and set notifications off.
            if ($myTransState == "continue" && $this->deActivated()) {
                if ($orig= $conn->fetchExpertAttrs($this->uid)) {
                    $newRow= array();
                    $newRow['expert_rate_notify']= 'f';
                    $newRow['expert_tip_notify']= 'f';

                    if (!($myRc= $conn->updateExpertAttrs($orig, $newRow))) {
                        $this->sqlMessage = "clientProfile::updateDBFields: Expert attr update failure " . $conn->getErrorMessage();
                        $myTransState = "rollback";
                        syslog(LOG_ERR, $this->sqlMessage);
                    }
                }
            }

            //  end of transaction.  commit or rollback.
            if ($myTransState == "continue") {
                if ($conn->executeQuery("commit work;")) {
                    $myRc = TRUE;

                } else {
                    $myTransState = "rollback";
                    $this->sqlMessage = "clientProfile::updateDBFields: Transaction commit failure" . $conn->getErrorMessage();
                    syslog(LOG_ERR, $this->sqlMessage);
                }
            }
            if ($myTransState == "rollback") {
                syslog(LOG_ERR, "clientProfile::updateDBFields: Transaction failure.  Rolling back");
                $conn->executeQuery("rollback");
                $myTransState = "exit";
            }
        }
        return($myRc);
    }
    ////////////////////////////////////////////////////////////////////
    //  move HTTP POST variables into object attributes
    function readPostVariables() {
        global $HTTP_POST_VARS;
        $myPostVars= $HTTP_POST_VARS;

        $this->RateNotify= isset($myPostVars['FormRateNotify']) ? $myPostVars['FormRateNotify'] : FALSE;
        unset($myPostVars['FormRateNotify']);

        $this->GiftNotify= isset($myPostVars['FormGiftNotify']) ? $myPostVars['FormGiftNotify'] : FALSE;
        unset($myPostVars['FormGiftNotify']);

        //  get rid of some crap
        unset($myPostVars['u']);
        unset($myPostVars['FormValidate']);

        //  and move the rest of the post variables into object
        //  attributes,  mainly for convenience.
        //echo("<br>clientProfile::readPostVariables() \$HTTP_POST_VARS --post-- "); var_dump($myPostVars);
        reset($myPostVars);
        while (list($var, $value) = each($myPostVars)) {
            list($attrName)= sscanf($var, "Form%s");
            if ($attrName != "") {
                $this->$attrName= $value;
                unset($myPostVars["$var"]);
            }
        }

        //echo("<br>clientProfile::readPostVariables() \$HTTP_POST_VARS --post-- "); var_dump($myPostVars);
        return(TRUE);
    }

########################################################################
##   Interface Functions   #############################################
########################################################################
    ////////////////////////////////////////////////////////////////////
    //  edit check all of the form fields
    function validateFields() {
        $this->Messages = array();
        $this->readPostVariables();

        $v= new asValidator();
        $v->CLEAR= TRUE;

        ////////////////////////////////////////////////////////////////
        ////////////////    billing fields    //////////////////////////
        if ($this->First != $this->origUserRow['user_first_nm'] && !$v->is_user_first($this->First))  {
            $this->Messages['First'] = $this->billMessages[]= $v->ERROR;
        }

        ////////////////////////////////////////////////////////////////
        if ($this->Last != $this->origUserRow['user_last_nm'] && !$v->is_user_last($this->Last))  {
            $this->Messages['Last'] = $this->billMessages[]= $v->ERROR;
        }

        ////////////////////////////////////////////////////////////////
        if ($this->Phone != $this->origUserRow['user_phone'] && !$v->is_user_phone($this->Phone))  {
            $this->Messages['Phone'] = $this->billMessages[]= $v->ERROR;
        }

        ////////////////////////////////////////////////////////////////
        if ($this->Company != $this->origUserRow['user_company'] && !$v->is_user_company($this->Company))  {
            $this->Messages['Company'] = $this->billMessages[]= $v->ERROR;
        }

        ////////////////////////////////////////////////////////////////
        if ($this->Address1 != $this->origUserRow['user_address1'] && !$v->is_user_address($this->Address1))  {
            $this->Messages['Address1'] = $this->billMessages[]= $v->ERROR;
        }

        if ($this->Address2 != "" && !$v->is_user_address($this->Address2)) {
            $this->Messages['Address2'] = $this->billMessages[]= $v->ERROR;
        }

        ////////////////////////////////////////////////////////////////
        if ($this->City != $this->origUserRow['user_city'] && !$v->is_user_city($this->City))  {
            $this->Messages['City'] = $this->billMessages[]= $v->ERROR;
        }
        ////////////////////////////////////////////////////////////////
        if ($this->Country != $this->origUserRow['user_country'] && $this->Country== "") {
            $this->Messages['Country'] = $this->billMessages[]= "COUNTRY IS REQUIRED";
        }
        ////////////////////////////////////////////////////////////////
        if ($v->is_UnitedStates($this->Country)) {
            if (!isset($this->State) || $v->is_NoState($this->State)) {
                $this->Messages['State'] = $this->billMessages[]= "STATE IS REQUIRED";
            }
        } else {
            $this->State= $v->setNoState();
        }
        ////////////////////////////////////////////////////////////////
        if ($this->Zip != $this->origUserRow['user_postal_cd'] && $v->is_UnitedStates($this->Country) && !$v->is_user_zip($this->Zip)) {
            $this->Messages['Zip'] = $this->billMessages[]= $v->ERROR;
        }

        ////////////////////////////////////////////////////////////////
        ///////////////////    security    /////////////////////////////
        $this->pswdMessages= array();
        if (!($this->Password1 == "" && $this->Password2 == "")) {
            if ($this->Password1 != $this->Password2)  {
                $this->Messages['Password'] = $this->pswdMessages[]= "PASSWORDS MUST MATCH";

            } elseif (!eregi("^[0-9a-zA-Z_]*$", $this->Password1))  {
                $this->Messages['Password'] = $this->pswdMessages[]= "PASSWORD MUST BE LETTERS, DIGITS AND UNDERSCORE";

            } elseif (strlen($this->Password1) < 6) {
                $this->Messages['Password'] = $this->pswdMessages[]= "PASSWORD MUST BE AT LEAST 6 CHARACTERS";
            }
        }
        $this->validationFlag = (count($this->Messages) == 0);

        return($this->validated());
    }
    ////////////////////////////////////////////////////////////////////
    function validated(){
        return($this->validationFlag);
    }
    ////////////////////////////////////////////////////////////////////
    function setUserLogin($uid){
        $this->uid= $uid;
        return(TRUE);
    }
    ////////////////////////////////////////////////////////////////////
    function init_private($uid) {
        $myRC = TRUE;

        $this->uid = $uid;
             $this->BarString=
                  "<a href=\"http://{$this->server}/user-history.php?u=" .
                  $uid . "\">" . $uid . "</a>&nbsp;";
        
        $myRC = $this->initFormFields();
        return($myRC);
    }
    ////////////////////////////////////////////////////////////////////
    //
    function dbMaint() {
        $this->validationFlag = FALSE;
        $myRC = TRUE;
        $conn = &$this->dbConnection;
        $conn->openConnection();

        $myRC = $this->updateDBFields();

        $conn->closeConnection();
        return($myRC);
    }
}
?>