<?php
//  $Name: ORG-TEST $, $Id: allseer.editAltEmail.php,v 1.17 2002/09/02 21:35:41 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//
require_once("allseer.UserSqlConn.php");
require_once("allseer.arrayLoader.php");
require_once("allseer.validator.php");
require_once("allseer.smtpMailer.php");

class em_editor
{

    ////////////////////////////////////////////////////////////////////
    function em_editor() {
        $this->validationFlag = FALSE;
        $this->Messages = array();
        $this->dbConnection = new UserSqlConn;
    }

////////////////////////////////////////////////////////////////////////
//                 L O C A L     F U N C T I O N S                    //
////////////////////////////////////////////////////////////////////////
    //
    function setValidationFlag($v) {
        $this->validationFlag= !!$v;
    }

    //  return true if this email is a duplicate.  under certain
    //  circumstances, an email row might be deleted so that
    //  it is no longer a duplicate.
    function is_dbDuplicateEmail($addy) {
        $conn=& $this->dbConnection;

        $userRow= $conn->fetchUserAttrsEmail($addy);
        $emailRow= $conn->fetchAltEmailRow($addy);
        $myRc= is_array($userRow) || is_array($emailRow);

        if (!is_array($userRow) && is_array($emailRow)) {
            if ($emailRow['amail_activep'] != 't') {
                if ($conn->removeAltEmail($addy)) {
                    $myRc= FALSE;
                }
            }
        }
        return($myRc);
    }
    ////////////////////////////////////////////////////////////////////
    //  move HTTP POST variables into object attributes
    function readPostVariables() {
        global $HTTP_POST_VARS;
        $myPostVars= $HTTP_POST_VARS;

        //  find all of the checkboxes which have been ticked
        reset ($myPostVars);
        while (list ($key, $val) = each ($myPostVars)) {
            //echo( "<br>readPostVariables()  HTTP_POSTVARS[$key] => $val");
            if (!strncmp("FormRemove", $key, strlen("FormRemove"))) {
                list($i)= sscanf($key, "FormRemove_%d");
                $this->altAry[$i]['checkbox']= "CHECKED";
                unset($myPostVars[$key]);
            }
        }

        //  and move the rest of the form variables into object
        //  object attributes.
        reset($myPostVars);
        while (list($key, $val) = each($myPostVars)) {
            if(!strncmp("Form", $key, strlen("Form"))) {
                list($attr)= sscanf($key, "Form%s");
                $this->$attr= $val;
            }
        }
        return(TRUE);
    }
////////////////////////////////////////////////////////////////////////
//             I N T E R F A C E    F U N C T I  O N S                //
////////////////////////////////////////////////////////////////////////
    //  return the current state of the validation flag
    function validated(){
        return($this->validationFlag);
    }

    //  read all of the form fields and check them
    function validateFields() {
        $check = new asValidator;
        $check->CLEAR= TRUE;
        $this->readPostVariables();

        $this->Messages= array();
        $myMsgs =& $this->Messages;

        $this->altEmailMessages= array();
        $aMessages=& $this->altEmailMessages;

        ////////////////////////////////////////////////////////////////
        //echo("<br>editAltEmail::validateFields() addAltEmail..."); var_dump($this->addAltEmail);
        if ($this->addAltEmail != "") {

            if (!$check->is_email($this->addAltEmail)) {
                $myMsgs['addAltEmail']= $aMessages[]= strtoupper($check->ERROR);

            } else if ($this->is_dbDuplicateEmail($this->addAltEmail)) {
                $myMsgs['addAltEmail']=  $aMessages[]= "DUPLICATE EMAIL ADDRESS";
            }
        }

        //  make sure that the user is not trying to delete their
        //  current forwarding address
        $ema=& $this->altAry;
        reset($ema);
        while (list ($key, $val) = each ($ema)) {
            //echo("<br>altAry[$key]= "); var_dump($ema[$key]);
            if ($ema[$key]['checkbox'] == "CHECKED") {
                if ($ema[$key]['addy'] == $this->userRow['user_fwd_email']) {
                    $myMsgs['altAry']= $aMessages[]=
                         "YOU CANNOT DELETE YOUR CURRENT FORWARDING EMAIL ADDRESS";
                }
            }
        }
        //echo("<br>editAltEmail::Messages..."); var_dump($this->Messages);
        //echo("<br>editAltEmail::altEmailMessages..."); var_dump($this->altEmailMessages);
        $this->setValidationFlag((count($this->Messages) == 0));
        return($this->validated());
    }

    ////////////////////////////////////////////////////////////////////
    //  all form fields have been validated.  do the
    //  requisite database updates.
    function Finalize() {
        $this->validationFlag = FALSE;
        $myRC = FALSE;

        //  rip thru the email array copying any elements flagged
        //  for removal
        if ($conn =& $this->dbConnection && $conn->openConnection()) {

            $myTransState = "continue";   //  xaction state variable

            //  start the transaction
            if (!$conn->executeQuery("begin work;")) {
                $myTransState = "exit";
                $this->sqlMessage =
                     "editAltEmail::dbUpdate() Can't start transaction.  " .
                     $conn->getErrorMessage();
                syslog(LOG_ERR, $this->sqlMessage);
            }
            //echo("<br>editAltEmail::dbUpdate() addAltEmail..."); var_dump($this->addAltEmail);

            if ($myTransState == "continue" && $this->addAltEmail != "" ){
                //  insert a new record in the alt email table
                if (!$conn->insertAltEmail($this->userLogin, $this->addAltEmail)) {
                    $myTransState = "rollback";
                    $this->sqlMessage = "editAltEmail::dbUpdate() Can't insert alt Email  " .
                         $conn->getErrorMessage();
                    syslog(LOG_ERR, $this->sqlMessage);
                }
            }

            //  if there are email addresses to be removed from
            //  the alt email table, then do it here
            $ema=& $this->altAry;
            reset($ema);
            while (list ($key, $val) = each ($ema)) {
                //echo("<br>editAltEmail::Finalize() altAry[$key]= "); var_dump($ema[$key]);
                if ($ema[$key]['checkbox'] == "CHECKED") {
                    if (!$conn->removeAltEmail($ema[$key]['addy'])) {
                        $myTransState = "rollback";
                        $this->sqlMessage = "editAltEmail::dbUpdate() Can't delete alt Email" .
                             $conn->getErrorMessage();
                        syslog(LOG_ERR, $this->sqlMessage);
                        break;
                    }
                }
            }

            //  end of transaction.  commit or rollback.
            if ($myTransState == "continue") {
                if ($conn->executeQuery("commit work;")) {
                    $myRC = TRUE;

                } else {
                    $myTransState = "rollback";
                    $this->sqlMessage = "editAltEmail::dbUpdate() Transaction commit failure" .
                         $conn->getErrorMessage();
                    syslog(LOG_ERR, $this->sqlMessage);
                }
            }

            if ($myTransState == "rollback") {
                syslog(LOG_ERR, "editAltEmail::dbUpdate() Transaction failure.  Rolling back");
                $conn->executeQuery("rollback");
                $myTransState = "exit";
            }
            $conn->closeConnection();
        }

        //  if all is well, then send an email out for registration
        if ($myRC &&  $this->addAltEmail != "" ) {
            $myMailer= new smtpMailer;
            $emailAry= array();

            $emailAry['new-addy']= $this->addAltEmail;
            $emailAry['user']= $this->userRow['user_login'];
            $emailAry['primary-addy']= $this->userRow['user_fwd_email'];
            $myMailer->userAddEmailU3($emailAry);
        }
        return($myRC);
    }

    ////////////////////////////////////////////////////////////////////
    function init ($userLogin) {
        $this->userLogin= $userLogin;

        $conn=& $this->dbConnection;
        if (!$conn) {
            $conn= new UserSqlConn();
        }
        
        if (!$myRc= $this->userRow= $conn->fetchUserAttrs($userLogin)) {
            $this->initMessage="Couldn't read user row";

        } else if (!$myRc=  $this->altAry= $conn->fetchAltEmailArray($userLogin)) {
            $this->initMessage="Couldn't read user email array";

        } else {
            while(list($k, $v)= each($this->altAry)) {
                $conn->stripShit($this->altAry[$k]);

                $this->altAry[$k]['color']= "black";
                $this->altAry[$k]['checkbox']= " ";
            }
        }
        $escapedUID= urlencode($userLogin);
        $this->linkToUserHistory=
             "UPDATE PATRON PREFERENCES: <a href=\"user-history.php?u=$escapedUID\">$userLogin</a>";
        $this->linkToVolunteerPrefs=
             "<a href=\"expert-profile.php?u=$escapedUID\">Update Volunteer Preferences</a>";
        //var_dump($this->altAry);
        return($myRc);
    }
}
?>
