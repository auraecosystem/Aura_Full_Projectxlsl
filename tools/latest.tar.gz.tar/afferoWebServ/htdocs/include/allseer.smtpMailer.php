<?
//  $Name: ORG-TEST $, $Id: allseer.smtpMailer.php,v 1.62 2002/12/12 21:00:44 leed Exp $
////////////////////////////////////////////////////////////////////////
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
//  This class abstracts out some SQL functionality frequently
//  with user maintenance

require_once("allseer.variousFunctions.php");
require_once ("externClasses/smtp.php");
require_once("allseer.hasher.php");

class smtpMailer
{

////////////////////////////////////////////////////////////////////////
//                        C O N S T R U C T O R                       //
////////////////////////////////////////////////////////////////////////
    function smtpMailer ($server= FALSE) {
        global $HTTP_SERVER_VARS;

        $this->smtp= new smtp_class;
        $this->smtp->host_name= "mail.colo.affero.net";

        $this->HTTPhost= ($server) ? $server : $HTTP_SERVER_VARS['HTTP_HOST'];
    }

////////////////////////////////////////////////////////////////////////
//                P R I V A T E    F U N C T I O N S                  //
////////////////////////////////////////////////////////////////////////
//  return the contents of some array as a string
    function errString($var) {
        ob_start();
        print_r($var);
        $ret_str = ob_get_contents();
        ob_end_clean();
        return $ret_str;
    }

    //  dump out an array if the $dumpargsMail config variable
    //  is set and true.
    function maybeShowEmailArgs($str, $ary) {
        global $dumpargsMail;

        $ret_str = "";
        if (isset($dumpargsMail) && $dumpargsMail) {
            $ret_str=
                 "///////////////////////////////////////////////////////////////////////\n/" .
                 " $str\n" .
                 "////////////////////////////////////////////////////////////////////////\n" .
                 "\n" .
                 $this->errString($ary) .
                 "////////////////////////////////////////////////////////////////////////\n" .
                 "////////////////////////////////////////////////////////////////////////\n";
        }
        return($ret_str);
    }

    //  munger returns an artfully contructed MD5 checksum
    function munger($addy, $xtraString) {
        $hashObj= new hasher();
        $idNumber= $hashObj->emailMunge($addy, $xtraString);
        return($idNumber);
    }

    //  generate URLs for user activation
    function myServer() {
        return("http://" . $this->HTTPhost);
    }

    //  generate URLs for user activation
    function actUrl($addy, $xtraString) {
        global $HTTP_SERVER_VARS;

        return($this->myServer() . "/aa.php" .
        "?m=" . urlencode($addy) .
        "&k=" . urlencode($this->munger($addy, $xtraString)));
    }

    //  activation functions
    function actUrlClient($addy) {
        return($this->actUrl($addy, "client"));
    }
    function actUrlExpert($addy) {
        return($this->actUrl($addy, "expert"));
    }
    function actUrlEmail($addy, $user) {
        $h= new hasher();

        $url  = $this->actUrl($addy, "email");
        $url .= "&u=$user";
        $url .= "&h=" . $h->emailMunge($user);
        return($url);
    }

    //  rating functions
    function rateClientUrl($client, $expert, $oid) {
        $H= new hasher();

        $str= sprintf("%s %s %s", $client, $expert, $oid);
        $cloakedArg= base64_encode($H->cloak($str));

        return($this->myServer() . "/rc.php" .
               "?cb=" . urlencode($cloakedArg) .
               "&k=" . urlencode($this->munger($expertArgAry['login'], "")));
    }

    function emitClientRatingPhrase($xpArgs) {
        if (placeHolderUserName($xpArgs['client']) && isset($xpArgs['client-id'])) {
            $clientStr= "id=" . $xpArgs['client-id'];

        } else {
            $clientStr=  $xpArgs['client'];
        }
        $msg= $this->rateClientUrl($clientStr, $xpArgs['login'], $xpArgs['ratingOID']);
        return($msg);
    }

    //  set up parameters for the mailer
    function localSendParameters($addy, $fromAddr= "Registration@affero.net", $fromString= ""){
        //  These parameters are for smtp->send() call.
        $locSendParams= array();
        $locSendParams["recipients"]= array("$addy");
        $locSendParams["headers"][]= "To: $addy";
        $locSendParams["headers"][]= "From: $fromString $fromAddr";
        $locSendParams["from"]= "$fromAddr";
        return($locSendParams);
    }

    //  send out some email
    function sendIt($sendArgs){
        ////////////////////////////////////////////////////////////////
        //                 debugging flags                            //
        ////////////////////////////////////////////////////////////////
        //  these are set in a config file, usually
        //  config-local.xxxx.inc
        //
        //$logMail= TRUE;
        //$sendMail= FALSE;
        ////////////////////////////////////////////////////////////////
        $myRc= TRUE;
        global $logMail, $dpyMail, $sendMail;

        $sendArgs['body']= wordwrap($sendArgs['body'],62);

        if ((isset($logMail) && $logMail) || (isset($dpyMail) && $dpyMail)) {
            ob_start();
            var_dump($sendArgs);
            $logStr= ob_get_contents();
            ob_end_clean();

            //  dump it in the browser window and on the system log
            if ($dpyMail) {
                echo("<br><br>smtpMailer::sendIt()<br>"  .
                     nl2br(htmlspecialchars($logStr)) .
                     "<br>-----------------------------<br>");
            }
            if ($logMail) {
                syslog(LOG_ERR, "smtpMailer::sendIt()\$sendArgs... $logStr");
            }
        }
        if (!isset($sendMail)  || $sendMail) {
            $myRc= FALSE;
            $s= &$sendArgs;
            $m= &$this->smtp;

            if (is_object($m)) {
                if (!($myRc= $this->smtp->SendMessage($s["from"], $s["recipients"], $s["headers"], $s["body"]))) {
                    $err=  $this->smtp->error;
                    syslog(LOG_ERR, "smtpMailer::sendIt() smtp error'$err'");
                }

            } else {
                syslog(LOG_ERR, "smtpMailer::sendIt() couldn't instantiate smtp_class");
            }

        }
        return($myRc);
    }

    function wrapText($text, $wrapmargin) {
        //echo("<br>wrapText()::\$text"); var_dump($text);

        $rettext = $linebuf = "";
        $tok = split("[ \t]", $text);

        $numtok = count($tok);
        for ($i= 0; $i < $numtok; $i++) {

            $elem = $tok[$i];
            if (strlen($linebuf) + strlen($elem) + 1 > $wrapmargin){
                $rettext .= $linebuf . "\n";
                $linebuf = "";
            }

            //  Do we have a newline in this element?
            if ($pos= strrpos($elem, "\n")){
                $before = substr($elem, 0, $pos);
                $after = substr($elem, $pos);
                $rettext = $rettext . $linebuf . " " . $before . "\n";
                $linebuf = $after;

            } else {
                $linebuf .= (strlen($linebuf) > 0 ? " " : "") . $elem;
            }
        }

        $rettext .= (strlen($linebuf) == 0) ? "" : $linebuf;
        //echo("<br>wrapText()::\$rettext..."); var_dump($rettext);
        return($rettext);
    }

    ////////////////////////////////////////////////////////////////////////
    //               A R G U M E N T    A C C E S S O R S                 //
    //--------------------------------------------------------------------//
    function subjLineA4($ary) {
        //  input array in an expertArgAry
        $subj= $this->patronNameFromXArgs($ary) .
             " gave $" . $ary['tip'] . ".00  due to your contribution on " .  $ary['listName'];
        return($subj);
    }
    function patronNameFromXArgs($ary){
        return(placeHolderUserName($ary['client']) ? $ary['client-addy'] : $ary['client']);
    }
    function profileFromXArgs($ary){
        $retStr= "";
        while(list($var, $val)= each($ary['profileAry'])) {
            $retStr .= "\t" . $val['bene'] . "\n";
        }
        $retStr .= "\n";
        return($retStr);
    }
    function volunteerNameFromXArgs($ary){
        return(placeHolderUserName($ary['login']) ? $ary['addy'] : $ary['login']);
    }
    function commentsFromXArgs($ary) {
        return($this->wrapText($ary['comments'], 62));
    }
    function ratingFromXArgs($ary){
        return($ary['rating']);
    }
    //  note that patronName and patronUser are currently
    //  equivalent, but that may not necessarily be true
    //  forever
    function patronNameFromRCArgs($ary){
        return(placeHolderUserName($ary['client']) ? $ary['addy'] : $ary['client']);
    }
    function patronUserIDFromRCArgs($ary){
        return($ary['client']);
    }
    function volunteerNameFromRCArgs($ary){
        return(placeHolderUserName($ary['expert']) ? $ary['xaddy'] : $ary['expert']);
    }
    function volunteerNameFromA3Args($ary){
        return(placeHolderUserName($ary['voluntr_login']) ? $ary['voluntr_addy'] : $ary['voluntr_login']);
    }
    function ratingFromRCArgs($ary){
        return($ary['rating']);
    }
    function commentsFromRCArgs($ary){
        return($this->wrapText($ary['comments'], 62));
    }

////////////////////////////////////////////////////////////////////////
//              I N T E R F A C E    F U N C T I O N S                //
//--------------------------------------------------------------------//
    function internalNewBennie($bennieLine) {
        global $testBennieMail, $testBennieMailAddy;

        $fromAddr= "appendq@affero.net";

        $to_line= "nonprofit@affero.com";
        if (isset($testBennieMail) && $testBennieMail) {
            if (isset($testBennieMailAddy)) {
                $to_line= $testBennieMailAddy;
            }
        }

        $bennieAry= explode(" ", $bennieLine);
        $bennieDate= $bennieAry[0];

        $bennieBodyLines= explode("&", $bennieAry[1]);
        foreach($bennieBodyLines as $line) {
            $lineAry[]= explode("=", $line);
        }
        $bennieBody= sprintf("\n%s\n", $bennieDate);
        foreach($lineAry as $l) {
            $f= sprintf("    %-20.20s --- %s\n\n", $l[0], urldecode($l[1]));
            $bennieBody.= $f;
        }

        $mySendParams= array();
        $mySendParams["recipients"]= array("nonprofit@affero.com");
        $mySendParams["from"]= "$fromAddr";
        $mySendParams["headers"][]= "To: " . $to_line;
        $mySendParams["headers"][]= "From: $fromAddr";
        $mySendParams["headers"][]= "Subject: New Benificary";

        $mySendParams["body"]= sprintf("\n%s\n", $bennieBody);
        //echo("<br><br>email body"); print_r($mySendParams["body"]);

        if (isset($testBennieMail) && $testBennieMail) {
            $mySendParams["body"] .= sprintf("\n%s\n", "T E S T    T E S T    T E S T    T E S T    T E S T    ");
        }
        if (!($myRc= $this->sendIt($mySendParams))) {
            syslog(LOG_ERR, $str= "smtpMailer::internalNewBennie() --error");
        }
    }
    //  Join Screen: new User;
    function newUserA0($joinArgAry) {

        $mySendParams= $this->localSendParameters($joinArgAry['addy']);

        $aType= (isset($joinArgAry['act_type']) && $joinArgAry['act_type'] == "client") ? "client" : "expert";

        $mySendParams["headers"][]= "Subject: Affero Registration";
        $mySendParams["body"]=
             "Dear {$joinArgAry['addy']},\n" .
             "\n" .
             "To complete your registration to Affero, please go to the following URL, " .
             "and choose a Login name and password:\n\n" .
             ($aType == "client" ? $this->actUrlClient($joinArgAry['addy']) :  $this->actUrlExpert($joinArgAry['addy'])) . " \n\n" .
             "If you have received this message without having requested it, it is " .
             "because someone else accidentally attempted to join with your e-mail address.  It was " .
             "most likely an innocent mistake, and only you can activate your " .
             "account with the unique link above. If you do not want to activate your account," .
             "you can safely disregard this message.\n\n" .
             "Thanks.";

        $mySendParams["body"].= $this->maybeShowEmailArgs("newUserA0() //  Join Screen: new User", $joinArgAry);

        if (!($myRc= $this->sendIt($mySendParams))) {
            syslog(LOG_ERR, $str= "smtpMailer::newUserA0() --error");
        }
        return($myRc);
    }

    //  RateMe: New Patron From List
    function newPatronA3($clientArgAry){
        $hashObj = new hasher();

        $mySendParams= $this->localSendParameters($clientArgAry['patron_addy']);
        $mySendParams["headers"][]= "Subject: Affero Registration";

        $mySendParams["body"]=
             "Dear {$clientArgAry['patron_addy']},\n" .
             "\n" .
             "Thank you for taking the time to provide feedback on " .
             $this->volunteerNameFromA3Args ($clientArgAry) . ". " .
             "This feedback is a valuable way to let people know how you view particular " .
             "contributions in the community. If you want to provide feedback on future " .
             "interactions, you must be a registered Affero member.\n" .
             "\n" .
             "To complete your registration to Affero, please go to the following URL, " .
             "and choose a Login name and password:\n" .
             "\n" .
             $this->actUrlClient($clientArgAry['patron_addy']) . "\n" .
             "\n" .
             "If you have received this message without having requested it, it is " .
             "because someone accidentally attempted to join with your e-mail address.  It was " .
             "most likely an innocent mistake, and only you can activate your " .
             "account with the unique link above. If you do not want to activate your " .
             "account, you can safely disregard this " .
             "message.\n" .
             "\n" .
             "Thanks.\n";


        $mySendParams["body"].= $this->maybeShowEmailArgs("newPatronA3() //  RateMe: New Patron From List", $clientArgAry);

        if (!($myRc= $this->sendIt($mySendParams))) {
            syslog(LOG_ERR, $str= "smtpMailer::newPatronA3() --error");
        }
        return($myRc);
    }
    //  RateMe: New Volunteer From List with Gift and Rating
    function newVolunteerA4($expertArgAry){
        $hashObj = new hasher();

        $mySendParams= $this->localSendParameters($expertArgAry['addy'], "Notices@affero.net");
        $mySendParams["headers"][]= "Subject: " . $this->subjLineA4($expertArgAry);

        $mySendParams["body"]=
             "Dear {$expertArgAry['addy']},\n" .
             "\n" .
             "Inspired by your post on {$expertArgAry['listName']}, ";

        if (isset($expertArgAry['listSubject']) && $expertArgAry['listSubject'] != "") {
            $mySendParams["body"] .= "under the subject {$expertArgAry['listSubject']}, ";
        }

        $mySendParams["body"] .=
             $this->patronNameFromXArgs($expertArgAry) .
             " provided feedback and gave $" . $expertArgAry['tip'] . ".00 on your behalf to:\n\n" .
             $this->profileFromXArgs($expertArgAry) .
             "Because we value your time, this will be the FIRST and LAST un-requested " .
             "notice that Affero will send you at this address: " .
             "{$expertArgAry['addy']} \n" .
             "\n" .
             "If you would like to receive further notices containing details of " .
             "feedback and financial contributions made on your behalf, you can do so " .
             "by creating an account on Affero. By creating an account, you may also " .
             "request that future donations go to other non-profits of your choice. " .
             "\n" .
             "To create your account or to get further information, you can do so by " .
             "going to the following URL:\n\n" .
             $this->actUrlExpert($expertArgAry['addy']) . "\n" .
             "\n" .
             "Sincerely,\n" .
             "\n" .
             "Chris Reed\n" .
             "creed@affero.net\n";

        $mySendParams["body"].= $this->maybeShowEmailArgs("newVolunteerA4() //  RateMe: New Volunteer From List with Gift and Rating", $expertArgAry);


        if (!($myRc= $this->sendIt($mySendParams))) {
            syslog(LOG_ERR, $str= "smtpMailer:newVolunteerA4() --error");
        }
        return($myRc);
    }
    //  RateMe: New Volunteer with Rating from List
    function newVolunteerA5($expertArgAry){
        $hashObj = new hasher();

        $mySendParams= $this->localSendParameters($expertArgAry['addy'], "Notices@affero.net");
        $mySendParams["headers"][]= "Subject: One of your messages from {$expertArgAry['listName']} has been rated on Affero";

        $mySendParams["body"]=
             "Dear " . $this->volunteerNameFromXArgs($expertArgAry) . ",\n" .
             "\n" .
             "Inspired by your post on {$expertArgAry['listName']}, ";

        if (isset($expertArgAry['listSubject']) && $expertArgAry['listSubject'] != "") {
            $mySendParams["body"] .= "under the subject {$expertArgAry['listSubject']}, \n";
        }

        $mySendParams["body"] .=
             $this->patronNameFromXArgs($expertArgAry) .
             " provided feedback and " .
             " valued your contribution as {$expertArgAry['rating']}.\n" .
             "\n" .
             "You may respond to " . $this->patronNameFromXArgs($expertArgAry) .
             "'s feedback by clicking here:\n\t" .
             $this->emitClientRatingPhrase($expertArgAry) . "\n\n" .

             "Because we value your time, this will be the FIRST and LAST un-requested " .
             "notice that Affero will send you at this address: \n" .
             "{$expertArgAry['addy']} \n" .
             "\n" .
             "If you would like to receive further notices containing details of " .
             "feedback and financial contributions made on your behalf, you can do so " .
             "by creating an account on Affero. By creating an account, you may also " .
             "request that future donations go to other non-profits of your choice. " .
             "\n" .
             "To create your account or to get further information, you can do so by " .
             "going to the following URL:\n" .
             "\t" . $this->actUrlExpert($expertArgAry['addy']) . "\n" .
             "\n" .
             "Sincerely,\n" .
             "\n" .
             "Chris Reed\n" .
             "creed@affero.net\n";

        $mySendParams["body"].= $this->maybeShowEmailArgs("newVolunteerA5() //  RateMe: New Volunteer with Rating from List", $expertArgAry);


        if (!($myRc= $this->sendIt($mySendParams))) {
            syslog(LOG_ERR, $str= "smtpMailer:newVolunteerA5() --error");
        }
        return($myRc);
    }
    //  RateMe: New Volunteer with Gift and Rating and no List
    function newVolunteerA6($expertArgAry){
        $hashObj = new hasher();

        $mySendParams= $this->localSendParameters($expertArgAry['addy'], "Notices@affero.net");
        $mySendParams["headers"][]= "Subject: " . $this->patronNameFromXArgs($expertArgAry) .
             " gave $" . $expertArgAry['tip'] . ".00 on your behalf";


        $mySendParams["body"] .=
             "Dear " . $this->volunteerNameFromXArgs($expertArgAry) . ",\n" .
             "\n" .
             "Inspired by you, " . $this->patronNameFromXArgs($expertArgAry) .
             " gave $" . $expertArgAry['tip'] . ".00 on your behalf to: \n" .
             $this->profileFromXArgs($expertArgAry) .
             "Because we value your time, this will be the FIRST and LAST un-requested " .
             "notice that Affero will send you at this address: \n" .
             "{$expertArgAry['addy']} \n" .
             "\n" .
             "If you would like to receive further notices containing details of " .
             "feedback and financial contributions made on your behalf, you can do so " .
             "by creating an account on Affero. By creating an account, you may also " .
             "request that future donations go to other non-profits of your choice. " .
             "\n" .
             "To create your account or to get further information, you can do so by " .
             "going to the following URL:\n" .
             $this->actUrlExpert($expertArgAry['addy']) . "\n\n" .
             "\n" .
             "Sincerely,\n" .
             "\n" .
             "Chris Reed\n" .
             "creed@affero.net\n";

        $mySendParams["body"].= $this->maybeShowEmailArgs("newVolunteerA6() //  RateMe: New Volunteer with Gift and Rating and no List", $expertArgAry);


        if (!($myRc= $this->sendIt($mySendParams))) {
            syslog(LOG_ERR, $str= "smtpMailer::newVolunteerA6() --error");
        }
        return($myRc);
    }

    //  RateMe: Gift && Rating notofication, list is unknown
    function volunteerGiftAndRatingG1($expertArgAry){
        $hashObj = new hasher();

        $mySendParams= $this->localSendParameters($expertArgAry['addy'], "Donations@affero.net");
        $mySendParams["headers"][]= "Subject: " . $this->patronNameFromXArgs($expertArgAry) .
             " gave $" . $expertArgAry['tip'] . ".00 on your behalf";

        $mySendParams["body"] =
             "Dear " . $this->volunteerNameFromXArgs($expertArgAry) . ":\n" .
             "\n" .
             "The gift from " . $this->patronNameFromXArgs($expertArgAry) . " was dispersed to the following\n" .
             "organizations on your behalf:\n\n" .
             $this->profileFromXArgs($expertArgAry) .
             $this->patronNameFromXArgs($expertArgAry) .
             "";

        if (isset($expertArgAry['comments']) && $expertArgAry['comments'] != "") {
            $mySendParams["body"] .=
                 " also provided the following comments: \n\n" .
                 $this->commentsFromXArgs($expertArgAry) . "\n\n" .
                 "and";
        }

        $mySendParams["body"] .=
             " valued your contribution as {$expertArgAry['rating']}.\n" .
             "\n" .
             "You may respond to " . $this->patronNameFromXArgs($expertArgAry) .
             "'s feedback by going to the following URL:\n\n" .
             $this->emitClientRatingPhrase($expertArgAry) . "\n\n" .
             "You have received this message because you subscribed to it on Affero. " .
             "To stop receiving this and other messages from Affero, or to add more " .
             "messages or change your preferences, please go to this URL:\n" .
             "\n" .
             $this->myServer() . "/expert-profile.php?u=". urlencode($expertArgAry['login']) . " \n" .
             "\n" .
             "You can log in and change your preferences from there.";


        $mySendParams["body"].= $this->maybeShowEmailArgs("volunteerGiftAndRatingG1() //  RateMe: Gift && Rating", $expertArgAry);


        if (!($myRc= $this->sendIt($mySendParams))) {
            syslog(LOG_ERR, $str= "smtpMailer::volunteerGiftAndRatingG1() --error");
        }
        return($myRc);
    }

    //  RateMe: Gift & Rating notofication, list is known
    function volunteerGiftAndRatingListG2($expertArgAry){
        $hashObj = new hasher();

        $mySendParams= $this->localSendParameters($expertArgAry['addy'], "Donations@affero.net");
        $mySendParams["headers"][]= "Subject: {$expertArgAry['listName']}";

        $mySendParams["body"] =
             "Dear " . $this->volunteerNameFromXArgs($expertArgAry) . ":\n" .
             "\n" .
             "Inspired by your post on {$expertArgAry['listName']}, " . $this->patronNameFromXArgs($expertArgAry) . "\n" .
             " provided  " .
             "feedback and gave $" . $expertArgAry['tip'] . ".00 on your behalf " .
             "\n" .
             "The gift was dispersed to the following organizations:\n\n" .
             $this->profileFromXArgs($expertArgAry) .
             $this->patronNameFromXArgs($expertArgAry);

        if (isset($expertArgAry['comments']) && $expertArgAry['comments'] != "") {
            $mySendParams["body"] .=
                 " also provided the following comments: \n\n" .
                 $this->commentsFromXArgs($expertArgAry) . "\n\n" .
                 "and";
        }

        $mySendParams["body"] .=
             " valued your contribution as {$expertArgAry['rating']}.\n" .
             "\n" .
             "You may respond to " . $this->patronNameFromXArgs($expertArgAry) .
             "'s feedback by going to the following URL:\n\n" .
             $this->emitClientRatingPhrase($expertArgAry) . "\n\n" .
             "You have received this message because you subscribed to it on Affero. " .
             "To stop receiving this and other messages from Affero, or to add more " .
             "messages or change your preferences, please go to this URL:\n\n" .
             $this->myServer() . "/expert-profile.php?u=". urlencode($expertArgAry['login']) . " \n" .
             "\n" .
             "You can log in and change your preferences from there.";


        $mySendParams["body"].= $this->maybeShowEmailArgs("volunteerGiftAndRatingG2() //  RateMe: Gift & Rating notofication, list is known", $expertArgAry);

        if (!($myRc= $this->sendIt($mySendParams))) {
            syslog(LOG_ERR, $str= "smtpMailer::volunteerGiftAndRatingG2() --error");
        }
        return($myRc);
    }
    //  RateMe: Patron Gift
    ////////////////////////////////////////////////////////////////////
    //      this email is sent from  the payment processor            //
    ////////////////////////////////////////////////////////////////////

    //  RateClient: Patron Rating
    function patronRatingR1($rcClientArgAry){
        $hashObj = new hasher();

        $mySendParams= $this->localSendParameters($rcClientArgAry['addy'], "Feedback@affero.net");
        $mySendParams["headers"][]= "Subject: " . $this->volunteerNameFromRCArgs($rcClientArgAry) . " offers feedback";

        $mySendParams["body"] =
             "Dear ". $this->patronNameFromRCArgs($rcClientArgAry) .",\n\n" .

             $this->volunteerNameFromRCArgs($rcClientArgAry) ." received your feedback and found it " .
             $this->ratingFromRCArgs($rcClientArgAry) . ".\n\n";

        if (($c= $this->commentsFromRCArgs($rcClientArgAry)) != "") {
            $mySendParams["body"] .=
                 $this->volunteerNameFromRCArgs($rcClientArgAry) . " further commented: \n\n{$c}\n\n";
        }

        $mySendParams["body"] .=

             "You have received this message because you have requested to receive it on Affero. " .
             "To stop receiving this and other messages from Affero, or to add more " .
             "messages or to change your preferences, please go to this URL:\n\n" .
             $this->myServer() . "/client-profile.php?u=". urlencode($this->patronUserIDFromRCArgs($rcClientArgAry)) . " \n" .
             "\n" .
             "You can log in and change your preferences from there.";

        $mySendParams["body"].= $this->maybeShowEmailArgs("patronRatingR1() //  RateClient: Patron Rating", $rcClientArgAry);

        if (!($myRc= $this->sendIt($mySendParams))) {
            syslog(LOG_ERR, $str= "smtpMailer::patronRatingR1() --error");
        }
        return($myRc);
    }

    //  RateMe: Volunteer Rating --list is unknown
    function volunteerRatingR2($expertArgAry){
        $hashObj = new hasher();

        $mySendParams= $this->localSendParameters($expertArgAry['addy'], "Feedback@affero.net");
        $mySendParams["headers"][]= "Subject: " . $this->patronNameFromXArgs($expertArgAry) . " offers feedback";

        $mySendParams["body"] =
             "Dear " . $this->volunteerNameFromXArgs($expertArgAry) . ":\n" .
             "\n" .
             $this->patronNameFromXArgs($expertArgAry) . " has rated the contribution as " .
             $this->ratingFromXArgs($expertArgAry);

        if (($c=  $this->commentsFromXArgs($expertArgAry)) != "") {
            $mySendParams["body"] .=
                 " and provided \n" .
                 "the following comments: \n\n{$c}";
        }

        $mySendParams["body"] .=
             ".\n" .
             "\n" .
             "You may rate this patron by going to the following URL:\n\n" .
             $this->emitClientRatingPhrase($expertArgAry) . "\n\n" .
             "You have received this message because you subscribed to it on Affero. " .
             "To stop receiving this and other messages from Affero, or to add more " .
             "messages or change your preferences, please go to this URL:\n\n" .
             $this->myServer() . "/expert-profile.php?u=". urlencode($expertArgAry['login']) . " \n" .
             "\n" .
             "You can log in and change your preferences from there.\n";

        $mySendParams["body"].= $this->maybeShowEmailArgs("volunteerRatingR2() //  RateMe: Volunteer Rating", $expertArgAry);

        if (!($myRc= $this->sendIt($mySendParams))) {
            syslog(LOG_ERR, $str= "smtpMailer::volunteerRatingR2() --error");
        }
        return($myRc);
    }
    //  RateMe: Volunteer Rating --list is known
    function volunteerRatingR3($expertArgAry){
        $hashObj = new hasher();

        $mySendParams= $this->localSendParameters($expertArgAry['addy'], "Feedback@affero.net");

        $mySendParams["headers"][]= "Subject: " . $this->patronNameFromXArgs($expertArgAry) . " offers feedback";

        $mySendParams["body"]=

             "Dear " . $this->volunteerNameFromXArgs($expertArgAry) . ":\n" .
             "\n" .
             "Inspired by your post on " . $expertArgAry['listName'] . ", ";

        if (isset($expertArgAry['listSubject']) && $expertArgAry['listSubject'] != "") {
            $mySendParams["body"] .= "under the subject {$expertArgAry['listSubject']}, ";
        }

        $mySendParams["body"] .=
             $this->patronNameFromXArgs($expertArgAry) .
             " valued your contribution as {$expertArgAry['rating']}.\n" .
             "\n";
        if (($c= $this->commentsFromXArgs($expertArgAry)) != "") {
            $mySendParams["body"] .=
                 $this->patronNameFromXArgs($expertArgAry) .
                 " also provided the following comments: \n\n{$c}\n";
        }
        $mySendParams["body"] .=
             "\n" .
             "You may respond to ". $this->patronNameFromXArgs($expertArgAry) .
             "'s feedback by going to the \n" .
             "following URL:\n\n" .
             $this->emitClientRatingPhrase($expertArgAry) . "\n\n" .
             "You have received this message because you subscribed to it on Affero. " .
             "To stop receiving this and other messages from Affero, or to add more " .
             "messages or change your preferences, please go to this URL:\n\n" .
             $this->actUrlExpert($expertArgAry['addy']) . "\n";


        $mySendParams["body"].= $this->maybeShowEmailArgs("volunteerRatingR3() //  RateMe: Volunteer Rating --list is known", $expertArgAry);

        if (!($myRc= $this->sendIt($mySendParams))) {
            syslog(LOG_ERR, $str= "smtpMailer::volunteerRatingR3() --error");
        }
        return($myRc);
    }
    //  Forgot-Pass: User
    function userForgotPasswordU1($fpassArgAry){
        $hashObj = new hasher();

        $mySendParams= $this->localSendParameters($fpassArgAry['addy'], "Affero@affero.net");
        $mySendParams["headers"][]= "Subject: Affero account access";

        $mySendParams["body"]=

             "Dear {$fpassArgAry['addy']}\n" .
             "\n" .
             "We have received a request for information on the Affero account " .
             "associated with this email address: {$fpassArgAry['addy']}\n" .
             "\n" .
             "The Affero username associated with this email address is: {$fpassArgAry['user_login']}\n" .
             "\n" .
             "The password associated with user: {$fpassArgAry['user_login']} is encrypted and we do not " .
             "have the ability to retrieve it, so we have generated a new one: '{$fpassArgAry['user_passwd']}'. " .
             "You can go to the following URL and reset it to something a little more personal:\n\n" .
             $this->myServer() . "/join.php?lg=1&ln=" . urlencode($fpassArgAry['user_login']) . " \n" .
             "\n" .
             "If you have received this message without having requested it, it is because someone " .
             "else accidentally used your e-mail address to request information. It was " .
             "most likely an innocent mistake, however you need to use the new password in " .
             "this message to access your account and reset it to something more personal." .
             "\n\n" .
             "Thanks.\n";

        $mySendParams["body"].= $this->maybeShowEmailArgs("userForgotPasswordU1() //  Forgot-Pass: User", $fpassArgAry);

        if (!($myRc= $this->sendIt($mySendParams))) {
            syslog(LOG_ERR, $str= "smtpMailer::userForgotPasswordU1() --error");
        }
        return($myRc);
    }
    //  Forgot-Pass: User is inactive
    function inactiveUserForgotPasswordU2($fpassArgAry) {
        $mySendParams= $this->localSendParameters($fpassArgAry['addy']);

        $mySendParams["headers"][]= "Subject: Your Affero Membership";
        $mySendParams["body"]=
             "Dear {$fpassArgAry['addy']},\n\n" .
             "We have received a request to send you a new Affero password \n" .
             "but you have not activated your account. " .
             "To select a login name and password please go to the following URL to activate your account.\n\n" .
             $this->actUrl($fpassArgAry['addy'], $fpassArgAry['user_last_prof']) ."\n\n" .
             "If you have received this message without having requested it, it is " .
             "because someone else accidentally used your email address. It was most likely " .
             "an innocent mistake and only you can activate your account with the unique " .
             "link above. If you do not wish to activate your account, you can safely disregard this message." .
             "\n\n" .
             "Thanks";


        $mySendParams["body"].= $this->maybeShowEmailArgs("inactiveUserForgotPasswordU2() //  Forgot-Pass: User is inactive", $fpassArgAry);

        if (!($myRc= $this->sendIt($mySendParams))) {
            syslog(LOG_ERR, $str= "smtpMailer::inactiveUserForgotPasswordU2() --error");
        }
        return($myRc);
    }

    //  email-edit:
    function userAddEmailU3($addEmailArgAry){
        $hashObj = new hasher();

        $mySendParams= $this->localSendParameters($addEmailArgAry['new-addy'], "Affero@affero.net");
        $mySendParams["headers"][]= "Subject: Affero e-mail activation";

        $mySendParams["body"]=
             "Dear {$addEmailArgAry['new-addy']},\n" .
             "\n" .
             "We have received a request to add this email address to an Affero " .
             "account held under the name {$addEmailArgAry['user']} with the primary email address of " .
             "{$addEmailArgAry['primary-addy']}.\n" .
             "\n" .
             "To approve adding this email address to {$addEmailArgAry['user']}'s account, please go " .
             "to the following URL:\n\n" .
             $this->actUrlEmail($addEmailArgAry['new-addy'], $addEmailArgAry['user']) . " \n" .
             "\n" .
             "If you have received this message without having requested it, it is " .
             "because someone else accidentally attempted to add your e-mail address to their account. " .
             "It " .
             "was most likely an innocent mistake, however you are the only one that can add your email address " .
             "to your account by completing the verification process in this message." .
             "If you do not want to make this change to your account, you can safely disregard this message.\n" .
             "\n" .
             "Thanks.\n";

        $mySendParams["body"].= $this->maybeShowEmailArgs("userAddEmailU3() //  email-edit", $addEmailArgAry);

        if (!($myRc= $this->sendIt($mySendParams))) {
            syslog(LOG_ERR, $str= "smtpMailer::userAddEmailU3() --error");
        }
        return($myRc);
    }
}
?>
