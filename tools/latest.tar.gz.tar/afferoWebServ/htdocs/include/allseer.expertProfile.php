<?php
//  $Name: ORG-TEST $, $Id: allseer.expertProfile.php,v 1.42 2002/12/12 21:00:44 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  This is a class for validating expert user fields from a form     //
//  and, updating the database expert user information attributes     //
//  appropriately.                                                    //
////////////////////////////////////////////////////////////////////////
require_once("global.php");
require_once("allseer.UserSqlConn.php");
require_once("allseer.editPayProf.php");
require_once("allseer.profileRep.php");

class expertProfile
{
    ////////////////////////////////////////////////////////////////////
    function expertProfile () {
        global $SERVER_NAME;
        $this->server= $SERVER_NAME;

        $this->Messages = array();
        $this->proppaTpAry= array("plain", "html");

        $this->dbConnection = new UserSqlConn();
        $this->ppEditor= new pp_editor();

        $this->dpyProfile= new profileRep();
        $this->viewProfile= new profileRep();
    }

    ////////////////////////////////////////////////////////////////////
    //  object initialization
    function init($login) {
        $myRc = TRUE;
        $conn = &$this->dbConnection;

        ///////////////////////////////////////////////////////////////
        //  get a user row from the database and make sure that the
        //  account is active and read the expert row
        $this->uid= $login;
        $myRc= $conn->loginExists($login);
        
        $myRc= $myRc ? !!$myUserRow= $this->userRow= $conn->fetchUserAttrs($this->uid) : FALSE;
        $myRc= $myRc ? $this->userRow['user_status'] != "inactivated" : FALSE;
        $myRc= $myRc ? (!!$myExpertRow= $this->expertRow= $conn->fetchExpertAttrs($login)) : FALSE;
        if ($myRc) {
            $this->listAdminFlag= ($conn->is_listAdmin($login)) ? "yes" : "no";
            $this->BarString= "<a href=\"http://{$this->server}/user-history.php?u=" .
                  $this->uid . "\">" . $this->uid . "</a>&nbsp;";
        }
        
        ///////////////////////////////////////////////////////////////
        //  build a list of e-mail addresses associated with this
        //  user.  make sure that the current forwarding e-mail
        //  address is first on the list.
        ////
        if ($myRc= ($myRc && $emailAry= $conn->fetchAltEmailArray($login))) {
            if (count($emailAry) > 1) {
                //  only keep the active addresses.  put the forwarding
                //  email address in the first array element.
                $first= array();
                for($i=0; $i<count($emailAry); $i++) {
                    if ($emailAry[$i]['activep'] == "t") {
                        if ($emailAry[$i]['addy'] == $myUserRow['user_fwd_email']) {
                            $first[]= $emailAry[$i];

                        } else {
                            $r[]= $emailAry[$i];
                        }
                    }
                }
                $emailAry= array_merge($first, $r);
            }
            $this->emailSelectionAry= $emailAry;

            //  initialize the pay profile editor object
            $this->ppEditor->init($this->uid);

            //  if theres a 'v' attribute then set up the view profile
            //  otherwise set up default profile percentages, but no
            //  profile name.
            if ($myRc && $this->v) {
                $this->ppEditor->setView($this->v);
                $this->viewProfile->setView($login, $this->v);

                $defProfile= $conn->fetchUserDefaultPayProfile($this->uid);

                if ($defProfile[0]["name"] == $this->viewProfile->name) {
                    $this->FormSetDefault= "CHECKED";
                }
                //echo("<br><br>viewp..."); var_dump($this->viewProfile);
                
            } else {
                $this->viewProfile->array= array();
            }

            $this->viewProfile->totalPercent();
            //echo("viewp..."); var_dump($this->viewProfile);

            //  make sure that there are at least three entries in
            //  the display profile array
            while(count($this->viewProfile->array) < 3) {
                $this->viewProfile->array[]= array('pc' => 0, 'found' => "");
            }
            $this->viewProfile->pRepSort();

            //  put the default profile first
            $mpa=& $this->ppEditor->activeProfileAry;
            for($i=0; $i < count($mpa); $i++) {
                if ($mpa[$i]['pindex'] == $myExpertRow['expert_profile']) {
                    $t= array($mpa[$i]);
                    unset($mpa[$i]);
                    $mpa= array_merge($t, $mpa);
                    $this->initialDefault= $t[0]['name'];
                    break;
                }
            }
            $this->dpyProfile= $this->viewProfile;
            $this->dpyProfileSer= urlencode(serialize($this->viewProfile));

            //echo("<br>dpyp(i)..."); var_dump($this->dpyProfile);

            //  set up toggle switches for the rate and tip notification
            //  attributes
            $this->RateNotifyState= $this->expertRow['expert_rate_notify'];
            $this->TipNotifyState= $this->expertRow['expert_tip_notify'];

            //  build some HTML which the user can include in his or
            //  her sig
            global $HTTP_SERVER_VARS;

            $login= $this->userRow['user_login'];
            $profile= $this->dpyProfile->name;

            $c_html = "http://{$HTTP_SERVER_VARS['HTTP_HOST']}"
                 ."/rm.php"
                 ."?r=$login";

            $c_html .= ($profile != "") ? "&p=$profile" : "";
            $this->copyHTML =
                 "Was I helpful?&nbsp;&nbsp;Let others know:" .
                 "<br>&nbsp;" .
                 htmlspecialchars($c_html, ENT_QUOTES);

            //  build a link test for the html above.  it is identical except
            //  that it opens in a new browser window and it is not escaped.
            $t_html= "<a target=new href = "
                 ."http://{$HTTP_SERVER_VARS['HTTP_HOST']}"
                 ."/rm.php"
                 ."?r=$login";

            $t_html .= ($profile != "") ? "&p=$profile" : "";
            $t_html .= ">" .  htmlspecialchars($c_html, ENT_QUOTES) ." </a>";
            $this->testHTML = $t_html;
        }
        return($myRc);
    }

    ////////////////////////////////////////////////////////////////////
    //  move HTTP POST variables into object attributes
    function readPostVariables() {
        global $HTTP_POST_VARS;
        $myPostVars= $HTTP_POST_VARS;

        //  build a pay profile representation from form fields.  This
        //  is called the dpyProfile and it differs from the viewProfile
        //  in that it may have been modified prior to form submission
        //
        //  the viewProfile, on the other hand, is the one which the
        //  user has selected for viewing.  It was previously stored
        //  in the database at the time that this script was called.
        //
        $this->dpyProfile= unserialize(urldecode($myPostVars['dpyProfileSer']));

        $fpp=& $this->dpyProfile;
        $fpp->name= isset($myPostVars['FormProfName']) ? $myPostVars['FormProfName'] : $fpp->name;
        $fpp->proppa= isset($myPostVars['FormProfProppa']) ? $myPostVars['FormProfProppa'] : $fpp->proppa;
        $fpp->proppa_tp= isset($myPostVars['FormProfProppaType']) ? $myPostVars['FormProfProppaType'] : $fpp->proppa_tp;

        while (list($var, $value) = each($myPostVars)) {
            if (!strncmp("FormPercent", $var, strlen("FormPercent"))){
                list($i) = sscanf($var, "FormPercent%d");
                list($d) = sscanf($value, "%d%%");

                $fpp->array[$i]['pc']= $d;
                unset($myPostVars["$var"]);

            } else if (!strncmp("FormFoundation", $var, strlen("FormFoundation"))){
                list($i) = sscanf($var, "FormFoundation%d");
                $fpp->array[$i]['found']= $value;
                unset($myPostVars["$var"]);
            }
        }
        $this->dpyProfileSer= urlencode(serialize($this->dpyProfile));
        $this->dpyProfile->totalPerCent();

        //  get rid of some crap
        unset($myPostVars['u']);
        unset($myPostVars['v']);
        unset($myPostVars['FormValidate']);
        unset($myPostVars['FormProfName']);
        unset($myPostVars['FormProfProppa']);
        unset($myPostVars['FormProfProppaType']);

        //  and move the rest of the post variables into object
        //  attributes,  mainly for convenience.
        reset($myPostVars);
        while (list($var, $value) = each($myPostVars)) {
            $this->$var= $value;
        }

        //  toggle rate and tip state variables as required
        $this->RateNotifyState= $this->FormRateNotify == "t" ? "t" : "f";
        $this->TipNotifyState= $this->FormTipNotify == "t" ? "t" : "f";

        return(TRUE);
    }
    ////////////////////////////////////////////////////////////////////
    //  edit check all of the form fields
    function validateFields() {
        $this->Messages= $this->persMessages= array();
        $this->readPostVariables();

        ////////////////////////////////////////////////////////////////
        //                   payment profile
        ////////////////////////////////////////////////////////////////
        //  individual messages are associated with a screen section
        //  (persMessages array) for textual display, and they are
        //  associated with screen attributes (Messages array) to change
        //  the color of field name titles.
        $checkDupe= ($this->dpyProfile->name != $this->viewProfile->name);
        if (!$this->dpyProfile->is_empty()) {
            if (!$this->dpyProfile->valid($this->userRow['user_login'], $checkDupe)) {
                foreach($this->dpyProfile->Messages as $key => $value) {
                    if (eregi("name", $value)){
                        $this->persMessages[]= $this->Messages['prfname']= $value;

                    } else if (eregi("total.*must|non-zero|between", $value)){
                        $this->persMessages[]= $this->Messages['prfdetails']= $value;

                    } else if (eregi(".*no.*details", $value)) {
                        $this->persMessages[]= $this->Messages['prfdetails']=
                             "TO CREATE A NEW DISBURSEMENT PROFILE, PLEASE SELECT ONE PR MORE BENEFICIARIES";

                    } else if (eregi("description", $value)) {
                        $this->persMessages[]= $this->Messages['prfdescr']= $value;

                    } else {
                        $this->persMessages[]= $value;
                    }
                }
            }
        }
        ////////////////////////////////////////////////////////////////
        //                       password
        ////////////////////////////////////////////////////////////////
        if (!($this->FormPassword1 == "" && $this->FormPassword2 == "")) {
            if ($this->FormPassword1 != $this->FormPassword2)  {
                $this->Messages['Password'] = $this->pswdMessages[]= "PASSWORDS MUST MATCH";

            } elseif (!eregi("^[0-9a-zA-Z_]*$", $this->FormPassword1))  {
                $this->Messages['Password'] = $this->pswdMessages[]= "PASSWORD MUST BE LETTERS, DIGITS AND UNDERSCORE";

            } elseif (strlen($this->FormPassword1) < 6) {
                $this->Messages['Password'] = $this->pswdMessages[]= "PASSWORD MUST BE AT LEAST 6 CHARACTERS";
            }

        }
        //  clear them out if and start over there is a problem
        if (count($this->pswdMessages) != 0) {
            $this->FormPassword1 = $this->FormPassword2 = "";
        }

        //  results of validation
        $this->validationFlag = count($this->Messages) == 0;
        
        return($this->validationFlag);
    }
    ////////////////////////////////////////////////////////////////////
    function validated(){
        return($this->validationFlag);
    }
    function deActivated(){
        $myRc= (isset($this->FormDeActivate) && $this->FormDeActivate == "t");
        return($myRc);
    }

    ////////////////////////////////////////////////////////////////////
    //  everything has been validated by now.  so do any updates to
    //  the database which might be required.
    function Finalize() {
        $myRC= FALSE;
        if (!$this->validated()) {
            $this->Message = "expertProfile::Filalize: input fields are not valid";
            return(FALSE);
        }
        $$this->Message = "expertProfile::Filalize: Unspecified error";
        
        //  programmer paranoia
        $this->validationFlag = FALSE;
        $myTransState= "continue";
            
        $newExpertRow= $this->expertRow;
        $newUserRow= $this->userRow;

        //  start a transaction.
        if ($myTransState == "continue"){
            $conn = new UserSqlConn();
            if (!is_object($conn)) {
                $myTransState= "exit";
                $this->Message = "profileRep::dbUpdate: counld not new UserSqlConn";
                syslog(LOG_ERR, $this->Message);
            }
        }
        if ($myTransState == "continue" && !$conn->openConnection()) {
            $myTransState= "exit";
            $this->Message = "expertProfile::Filalize: could not open database connection exit now";
            syslog(LOG_ERR, $this->Message);
        }
        if ($myTransState == "continue" && !$conn->executeQuery("begin work;")) {
            $myTransState= "close";
            $this->Message = "expertProfile::Filalize: " . "Cant start transaction " . $conn->getErrorMessage();
            syslog(LOG_ERR, $this->Message);
        }
        
        // maybe add a new profile
        if ($myTransState == "continue") {
            if (($this->dpyProfile->name != $this->viewProfile->name) && ($this->dpyProfile->name != ""))  {
                if ($seq= $this->dpyProfile->addProfile($this->userRow['user_login'], $conn)) {
                    if ($this->expertRow['expert_profile'] == "") {
                        $newExpertRow['expert_profile'] = $seq;
                    }
                } else {
                    $this->Message= "profileRep::dbUpdate: addProfile error";
                    syslog(LOG_ERR, $this->Message);
                    $myTransState= "rollback";
                }
            } else {
                //  or maybe update the one that's there
                //echo("dydP..."); var_dump($this->dpyProfile);
                if ($this->dpyProfile->needsUpdate($this->viewProfile)) {
                    if (!$this->dpyProfile->updateProfile($conn, $this->uid)) {
                        $this->Message= "profileRep::dbUpdate: updateProfile error";
                        syslog(LOG_ERR, $this->Message);
                        $myTransState= "rollback";
                    }
                }
               if ($myTransState == "continue" && $this->dpyProfile->mustReplace($this->viewProfile)) {
                    if (!$this->dpyProfile->replaceProfileDetails($conn)) {
                        $this->Message= "profileRep::dbUpdate: replaceProfileDetailserror";
                        syslog(LOG_ERR, $this->Message);
                        $myTransState= "rollback";
                    }
                }
            }
        }
        
        if ($myTransState == "continue") { 
            //  if the default profile checkbox is set and there's a
            //  new profile name then set up a new profile as the default
            //  for this user
            $name= $this->dpyProfile->name;
            $iname= $this->initialDefault;
            
            if ($this->FormSetDefault == "t" && $name != $iname) {

                $finalPPE= new pp_editor();
                $finalPPE->init($this->uid, $conn);
                
                $cur=& $finalPPE->activeProfileAry;
                $k= count($cur);
                for($i=0; $i < $k; $i++) {
                    if ($cur[$i]['name'] == $name) {
                        $newExpertRow['expert_profile']= $cur[$i]['pindex'];
                        break;
                    }
                }
            }
            
            //  account deactivation
            if ($this->deActivated()) {
                $this->RateNotifyState= $this->TipNotifyState= 'f';
            }

            //  set rating and tip notification and email
            $newExpertRow['expert_rate_notify']= $this->RateNotifyState;
            $newExpertRow['expert_tip_notify']= $this->TipNotifyState;
            $newUserRow['user_fwd_email']= $this->FormEmailSelected;
            $newUserRow['user_last_prof']= "expert";

            //  password
            if ($this->FormPassword1 != "") {
                $h= new hasher;
                $newUserRow['user_passwd']= $h->passwordMunge($this->FormPassword1);
            }

            //  account deactivation
            if ($this->deActivated()) {
                $newUserRow['user_status']= "inactivated";
                $newUserRow['user_passwd']= "//";
            }
        }
        //  update user attrs
        if ($myTransState == "continue") {
             if (!$conn->updateUserAttrs($this->userRow, $newUserRow)) {
                 $this->Message= "profileRep::dbUpdate: updateUserAttrs error" . $conn->getErrorMessage();
                 syslog(LOG_ERR, $this->Message);
                 $myTransState= "rollback";
             }
        }

       //  update expert attrs
        if ($myTransState == "continue") {
            if (!$conn->updateExpertAttrs($this->expertRow, $newExpertRow)) {
                 $this->Message= "profileRep::dbUpdate: updateExpertAttrs error (deux)" . $conn->getErrorMessage();
                 syslog(LOG_ERR, $this->Message);
                 $myTransState= "rollback";
            }
        }

        //  end of transaction.  commit or rollback.
        if ($myTransState == "continue") {
            
            if ($conn->executeQuery("commit work;")) {
                $myTransState = "close";
                $myRC = TRUE;
                
            } else {
                $myTransState = "rollback";
                $this->Message = "expertProfile::Filalize: Transaction commit failure" . $conn->getErrorMessage();
                syslog(LOG_ERR, $this->Message);
            }
        }

        if ($myTransState == "rollback") {
            $this->Message = "expertProfile::Filalize: Transaction failure.  Rolling back";
            syslog(LOG_ERR, $this->Message);
            $conn->executeQuery("rollback");
            $myTransState = "close";
        }
        //  be nice to your database server
        if ($myTransState == "close") {
            $conn->closeConnection();
        }
        return($myRC);
    }
}
?>
