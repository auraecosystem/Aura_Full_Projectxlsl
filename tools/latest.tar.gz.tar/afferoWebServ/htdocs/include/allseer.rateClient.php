<?php
//  $Name: ORG-TEST $, $Id: allseer.rateClient.php,v 1.24 2002/11/12 23:47:52 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  This is a class for validating rate me fields from a form.
////
//  TODO: move all of the SQL out of this object and in to the
//        the allseer.UserSQLConn.php boject
////////////////////////////////////////////////////////////////////////
require_once("allseer.variousFunctions.php");
require_once("allseer.UserSqlConn.php");
require_once("allseer.smtpMailer.php");
require_once("allseer.hasher.php");

class rateClient
{
    ////////////////////////////////////////////////////////////////////
    function rateClient () {
        $this->Value = FALSE;
        $this->Comment = FALSE;
        $this->Login = FALSE;
        $this->Password = FALSE;
        $this->validationFlag = FALSE;

        $this->Messages = array();
        $this->dbConnection = new UserSqlConn;
        $this->Ratings= $this->dbConnection->fetchRatingDescriptions();

        $this->validLoginRegex = "^[0-9a-zA-Z_]*$";
        $this->validPasswordRegex = "^[0-9a-zA-Z_]*$";
    }

    //  retrieve a user row for this expert.
    //  returns false if no user record exists.
    function retrieveExpertUserData ($conn) {
        $myRc = FALSE;
        if ($myRow = $conn->fetchUserAttrs($this->Login)) {
            $myRc = TRUE;
            $this->RaterEmail = $myRow['user_fwd_email'];
        }
        return($myRc);
    }
    ////////////////////////////////////////////////////////////////////
    //  retrieve a user row for this client
    //  returns false if no user record exists.
    function retrieveClientUserData ($conn) {
        $myRc = FALSE;
        if (preg_match("/id=/", $this->ClientArg)) {
            $clid= preg_replace("/id=/", "", $this->ClientArg);
            if ($this->ClientUserRow= $myRow = $conn->fetchUserAttrsUID($clid)) {
                $myRc = TRUE;
            }
        } else if ($this->ClientUserRow= $myRow = $conn->fetchUserAttrs($this->ClientArg)) {
            $myRc = TRUE;
        }
        if ($myRc == TRUE) {
           $this->RateeEmail = $myRow['user_fwd_email'];
           $this->Client= $myRow['user_login'];
        }
        return($myRc);
    }

    ////////////////////////////////////////////////////////////////////
    //  rturn true if the ClientUserRow property is valid
    function haveClientUserRow() {
        if (!(is_array($this->ClientUserRow) && count($this->ClientUserRow) > 0)) {
            $conn =& $this->dbConnection;
            $this->retrieveClientUserData($conn);
        }
        $myRc= (is_array($this->ClientUserRow) && count($this->ClientUserRow) > 0);
        return($myRc);
    }

    ////////////////////////////////////////////////////////////////////
    //  retrn true if this client is activated
    function clientActivated() {
        $myRc= $this->haveClientUserRow() && $this->ClientUserRow['user_status'] == "activated";
        return($myRc);
    }

    ////////////////////////////////////////////////////////////////////
    //  retrieve a client row for this client
    //  returns false if no user record exists.
    function retrieveClientData ($conn) {
        $myRc= FALSE;
        if ($myRow = $conn->fetchClientAttrs($this->Client)) {
            $myRc = TRUE;
            $this->ClientRow= $myRow;
        }
        return($myRc);
    }

    ////////////////////////////////////////////////////////////////////
    //  Insert a rating in the database
    function executeRatingTransaction ($conn) {

        $rArgs= array();
        $rArgs['value']= $this->Value;
        $rArgs['comment']= $this->Comment;
        $rArgs['rid']= $this->origRating['rating_id'];
        $rArgs['raterEmail']= $this->RaterEmail;
        $rArgs['rateeEmail']= $this->RateeEmail;

        $myRc = $conn->insertRating($rArgs);
        return($myRc);
    }

    ////////////////////////////////////////////////////////////////////
    //  edit check all of the form fields
    function validateFields() {
        $this->Messages = array();
        $this->validationFlag = FALSE;

        $this->validationFlag = (count($this->Messages) == 0);

        return($this->validated);
    }

    ////////////////////////////////////////////////////////////////////
    function validated(){
        return($this->validationFlag);
    }

    ////////////////////////////////////////////////////////////////////
    //  all fields on a ratings screen have been validated.  do the
    //  requisite database updates.
    function dbInsert() {
        $conn =& $this->dbConnection;
        $conn->openConnection();
        $myRC = FALSE;

        if (!$this->validationFlag) {
            $this->dbInsertResults = FALSE;
            $this->sMessage = "<rateClient.php> Invalid Object";
            syslog(LOG_ERR, $this->sMessage);

        } else {
            $this->validationFlag = FALSE;

            if (!$this->haveClientUserRow()) {
                $this->sMessage = "<rateClient.php> DBI couldn't read client user data";
                syslog(LOG_ERR, $this->sMessage);

            } else if (!$this->ExpertUserRow = $this->retrieveExpertUserData($conn)){
                $this->sMessage = "<rateClient.php> DBI couldn't read expert user data <<" . $conn->getErrorMessage() . ">>";
                syslog(LOG_ERR, $this->sMessage);

            } else if (!$this->executeRatingTransaction($conn)){
                $this->sMessage = "<rateClient.php> DBI couldn't insert new rating <<" . $conn->getErrorMessage() . ">>";
                syslog(LOG_ERR, $this->sMessage);

            } else {
                $myRC = TRUE;
            }
        }

        $conn->closeConnection();
        return($myRC);
    }

    ////////////////////////////////////////////////////////////////////
    function clientWantsRatingEmail() {
        $myRc= FALSE;
        $conn=& $this->dbConnection;

        if ($this->retrieveClientData($conn)) {
            $myRc= !strcmp($this->ClientRow['client_rate_notify'], "t");
        }
        return($myRc);
    }

    ////////////////////////////////////////////////////////////////////
    //  make sure that the password is correct for this login_id
    function Finalize() {
        $myRc= FALSE;

        if ($myRc= $this->dbInsert()) {
            $myMailer= new smtpMailer;

            $clientArgAry= array();
            $clientArgAry['client']= $this->Client;
            $clientArgAry['addy']= $this->RateeEmail;
            $clientArgAry['expert']= $this->Login;
            $clientArgAry['xaddy']= $this->RaterEmail;

            $clientArgAry['rating']= $this->Value;
            $clientArgAry['rating']= "none";
            $clientArgAry['comments']= $this->Comment;

            foreach($this->Ratings as $r){
                if ($r['rating_val'] == $this->Value) {
                    $clientArgAry['rating']= $r['rating_descr'];
                    break;
                }
            }

            if ($this->clientActivated() && $this->clientWantsRatingEmail() && !$myMailer->patronRatingR1($clientArgAry)) {
                $this->sMessage = "<rateClient.php> Client notification error";
                syslog(LOG_ERR, $this->sMessage);
            }
        }
        return($myRc);
    }

    ////////////////////////////////////////////////////////////////////
    //  make sure that the password is correct for this login_id
    function passwdCheck() {
        return(TRUE);
    }

    ////////////////////////////////////////////////////////////////////
    function is_valid_key($key, $xprt) {
        $myRC= TRUE;

        $hashObj = new hasher();
        if ($key != $hashObj->emailMunge($xprt, "")) {
            $myRC=FALSE;
        }

        return($myRC);
    }
    ////////////////////////////////////////////////////////////////////
    function init() {
        global $cb, $k;
        $conn=& $this->dbConnection;

        $myRc = "OK";

        if (!(isset($cb) && isset($k) && $this->is_valid_key($k))) {
             $myRc = "INVALID URL ARGUMENTS";

        } else {
            $H= new hasher();

            $this->cb= $cb;
            $this->k= $k;

            $arg= $H->deCloak(base64_decode($cb));
            list($client, $expert, $oid, $trash)= split (" ", $arg, 4);

            if (!$conn->openConnection()) {
                $myRc = "DATABASE IS INACCESSABLE";

            } else {
                if (!$conn->originalRatingExists($oid)) {
                    $myRc = "ORIGINAL RATING DOES NOT EXIST";

                } else {
                    $this->origRating= $conn->fetchNextRow(0);

                    if ($conn->duplicateRatingExists($oid)) {
                        $myRc = "REFERENCED RATING ALREADY EXISTS";
                    }
                }
                $conn->closeConnection();
            }
        }
        if ($myRc == "OK") {
            $this->ClientArg= $client;
            $this->Login = $expert;
            $this->Key = $k;
        }
        if ($myRc == "OK" && !$this->haveClientUserRow()) {
            $myRc= "<rateClient.php> init() couldn't read client user data";
            syslog(LOG_ERR, $myRc);
        }
        if ($myRc == "OK") {
            $this->BarString = placeHolderUserName($this->Client)
                 ? $this->ClientUserRow['user_fwd_email']
                 : $this->Client;
        }
        return($myRc);
    }
}
?>