<?php
//  $Name: ORG-TEST $, $Id: webservice.topPatrons.php,v 1.7 2002/12/12 21:00:44 leed Exp $
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////
//  This is a class for validating rate me fields from a form.
////
//  TODO: move all of the SQL out of this object and in to the
//        the allseer.UserSQLConn.php boject
////////////////////////////////////////////////////////////////////////
require_once("allseer.UserSqlConn.php");
require_once("webservice.topUserHOFArgs.php");
require_once("allseer.variousFunctions.php");

class topPatrons
{
    ////////////////////////////////////////////////////////////////////
    ////    CONSRUCTOR      ////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////
    function  topPatrons() {
        $this->objectStatus= "OK";
        $this->dbConnection= new UserSqlConn();
        $this->historyHost= $GLOBALS['historyHost'];
        $this->hofArgs= new topUserHOFArgs();
        //  echo("<br><br> hofArgs..."); var_dump($this->hofArgs);

        //  default values for URL arguments
        $this->lists= $this->hofArgs->lists;
        $this->fids= $this->hofArgs->foundationIds;
        $this->type= $this->hofArgs->type;
        $this->fromDate= $this->hofArgs->fromDate;
        $this->toDate= $this->hofArgs->toDate;
        $this->limit= $this->hofArgs->limit;

        $this->emptyTableText= "gifts";
        $this->tableSubTitle= "(by funds donated)";
        $this->dataHeader= "Amt";
        
        $this->dpyDateRange = $this->hofArgs->dpyDateRange;
        //  HOF table.
        $ary= array();
        
        if ($this->hofArgs->tableContents == "count") {
            $tempAry= $this->dbConnection->readClientHOFcounts(
                $this->fromDate,
                $this->toDate,
                $this->lists,
                $this->hofArgs->rFilter);
            //  collect counts
            $this->xAry= array();
            foreach($tempAry as $row)  {
                $this->userCountXform($row);
            }
            //z
            reset($this->xAry);
            foreach($this->xAry as $row){
                $ary[]= array('login'=>$row['login'], 'pdat'=>count($row['ratees']));
            }
            usort($ary, array($this, "countComparator"));
            $this->dataHeader= "Count";
            $this->tableSubTitle= "(by members rated)";

        } else {
            $ary= $this->dbConnection->readClientHOF($this->fromDate, $this->toDate, $this->lists, $this->fids);
        }
        $this->patronsAry= array_slice(array_filter($ary, array($this, "patronsArrayFilter")), 0, $this->limit);
        $this->tableTitle= "Top " . (($t= count($this->patronsAry)) == 0 ?  "" : "$t") . " Patrons";
        $this->tableRows= count($this->patronsAry);
    }

    ////////////////////////////////////////////////////////////////////
    ////    PRIVATE METHODS      ///////////////////////////////////////
    ////////////////////////////////////////////////////////////////////
    //  take a row from the patronsAry.  return true if this row is to
    //  appear in the patron hall of fame
    function patronsArrayFilter($row) {
        $myRC= !placeHolderUserName($row['login']);
        return($myRC);
    }

    function userCountXform($row) {
        $user= $row['user'];
        if (!isset($this->xAry["$user"])) {
            $this->xAry["$user"]= array('login' => "$user", 'ratees'=> array());
        }

        if (!in_array($row['ratee'], $this->xAry["$user"]['ratees'])) {
            $this->xAry["$user"]['ratees'][]= $row['ratee'];
        }
    }
    function countComparator($a, $b) {
        if ($a['pdat'] == $b['pdat']) {
            $rc= 0;
        } else if ($a['pdat'] > $b['pdat']) {
            $rc= -1;
        } else {
            $rc= 1;
        }
        return($rc);
    }
}

?>
