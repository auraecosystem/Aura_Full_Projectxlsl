<?
require_once("allseer.variousFunctions.php");
//  $Name: ORG-TEST $, $Id: config-clean.inc.php,v 1.7 2002/05/03 20:32:39 leed Exp $
////////////////////////////////////////////////////////////////////////
//---------------------------------------------------------------------
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
//                             Logging
define_syslog_variables();
openlog("WWW-SERVICE-WEB", LOG_ODELAY, LOG_USER);
error_reporting(E_ALL & ~(E_WARNING | E_NOTICE));

////////////////////////////////////////////////////////////////////////
//                        Database Settings
//
//  defaults are overridden in host local config files
$dbhost = "localhost";         //   database host machine
$dbname = "database";          //   name of the database.
$dbuname = "database-user";    //   user name
$dbpass = "database-passwd";   //   password used to acce

////////////////////////////////////////////////////////////////////////
//                           Payment Related
$paySecureHost = "www.bank.com";  //https: for payments.  testing only
$curlProg= "/usr/local/bin/curl";
$payDetailDemo = "y";

$MINIMUM_TIP  = "5";
$MAXIMUM_TIP = "1000";

////////////////////////////////////////////////////////////////////////
//                     MD5 Keys and stuff like that
$HasherCloakerKey = "HasherCloakerKey";
$HasherEmailMungerKey= "HasherEmailMungerKey";
$HasherPasswordMungerKey= "HasherPasswordMungerKey";
$HasherSessionMungerKey= "HasherSessionMungerKey";
$PayDetailsMunger= "PayDetailsMunger";


////////////////////////////////////////////////////////////////////////
//                                 Misc
$sessionLogInterval= "6 hours";
$configgedForLive= FALSE;

$logMail= false;
$dpyMail= false;
$sendMail= true;
$dumpargsMail= false;

////////////////////////////////////////////////////////////////////////
//                          Branch Identifier
//  If the global $CVSBranchId is set then it's value is displayed
//  in a centered red box on the home page
if (file_exists("{$HTTP_SERVER_VARS['DOCUMENT_ROOT']}/CVS/Tag")) {
    $tagAry= file("{$HTTP_SERVER_VARS['DOCUMENT_ROOT']}/CVS/Tag");
    preg_match("/(.)(.*)/", $tagAry[0], $tagMatches);
    if (isset($tagMatches[2])) {
        if ($tagMatches[1] == "T"){
            $CVSBranchId= "Branch-- ";
            
        } else if ($tagMatches[1] == "N"){
            $CVSBranchId= "Tag-- ";
            
        } else if ($tagMatches[1] == "D"){
            $CVSBranchId= "Date-- ";
            
        } else {
            $CVSBranchId= "UNK-- ";
        }
        $CVSBranchId .= $tagMatches[2];
    }   
}
////////////////////////////////////////////////////////////////////////
//              Local (per server host) configuration
preg_match("/^([^\/.]*)/", $HTTP_SERVER_VARS["SERVER_NAME"], $splitAry);
$testHost= $splitAry[0];

//  host dependent shit.  load  a host dependent config
//  file if it exists
$localConfig= "config-local.{$testHost}.inc";
if (include_path_file_exists($localConfig)) {
    include($localConfig);
}

?>
