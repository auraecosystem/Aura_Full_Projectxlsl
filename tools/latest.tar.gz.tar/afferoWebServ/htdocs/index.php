<!--  $Id: index.php,v 1.1 2002/08/28 16:14:39 leed Exp $ -->
<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
   <meta http-equiv="PICS-Label" content="(PICS-1.1">
   <meta name="GENERATOR" content="Mozilla/4.72 [en] (X11; I; Linux 2.2.15-6mdk i686) [Netscape]">
   <title>Affero</title>
   <base target="_top">
</head>
<body>

<center>
<hr noshade size=1 width=640>
HOWDY, AND GOOD MARNIN' TO Y'ALL
</center>

</BODY>
</HTML>
