<?php
//  $Name: ORG-TEST $, $Id: global.php,v 1.1 2002/09/06 19:48:10 leed Exp $
///////////////////////////////////////////////////////////////////////
// Copyright (C) 2002 Affero, Inc.

// This file is part of The Affero Project.

// The Affero Project is free software/ you can redistribute it and/or
// modify it under the terms of the Affero General Public License as
// published by Affero, Inc./ either version 1 of the License, or
// (at your option) any later version.

// The Affero Project is distributed in the hope that it will be
// useful,but WITHOUT ANY WARRANTY/ without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// Affero General Public License for more details.

// You should have received a copy of the Affero General Public
// License in the COPYING file that comes with The Affero Project/ if
// not, write to Affero, Inc., 510 Third Street, Suite 225, San
// Francisco, CA 94107 USA.
//----------------------------------------------------------------------
function include_path_file_exists($filename) 
{ 
    $paths = explode(":", ini_get("include_path")); 
    $result = false; 

    while((!$result) && (list($key,$val)= each($paths))){ 
        $result = file_exists($val . "/" . $filename); 
    } 
    return $result; 
}

$WSERVER="red2.office.affero.com";
$localConfig= "config.slocal.php";
if (include_path_file_exists($localConfig)) {
    include_once($localConfig);
}
?>
